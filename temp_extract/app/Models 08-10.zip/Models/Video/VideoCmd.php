<?php

namespace App\Models\Video;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class VideoCmd extends Model
{
	protected $table = 'cmd_tables';
	protected $connection = 'crafty_video_mysql';
    use HasFactory;
}
