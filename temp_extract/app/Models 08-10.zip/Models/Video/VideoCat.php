<?php

namespace App\Models\Video;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class VideoCat extends Model
{
	protected $table = 'main_categories';
	protected $connection = 'crafty_video_mysql';
    use HasFactory;


    public function videoTemplates()
    {
        return $this->hasMany(VideoTemplate::class,'category_id','id');
    }

    public function subcategories()
    {
        return $this->hasMany(VideoCat::class, 'parent_category_id', 'id');
    }

    public function parentCategory()
    {
        return $this->belongsTo(VideoCat::class, 'parent_category_id', 'id');
    }

    public static function getAllCategoriesWithSubcategories()
    {
        $categories = VideoCat::where('parent_category_id',0)->get();
        foreach ($categories as $category) {
            $category->subcategories = $category->getSubcategoriesTree();
        }
        return $categories;
    }


    public static function getCategoriesWithSubcategories($category)
    {
        $categories = VideoCat::where('id',$category)->get();

        if ( empty($categories->toArray()) ) {
            $categories = VideoCat::where('id_name',$category)->get();
        }

        foreach ($categories as $category) {
            $category->subcategories = $category->getSubcategoriesTree();
        }
        return $categories;
    }

    protected function getSubcategoriesTree()
    {
        $subcategories = $this->subcategories;
        foreach ($subcategories as $subcategory) {
            $subcategory->subcategories = $subcategory->getSubcategoriesTree();
        }
        return $subcategories;
    }

}
