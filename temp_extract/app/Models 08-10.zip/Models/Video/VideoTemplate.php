<?php

namespace App\Models\Video;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class VideoTemplate extends Model
{
	protected $table = 'items';
	protected $connection = 'crafty_video_mysql';
    use HasFactory;

    public function videoCat()
    {
        return $this->belongsTo(VideoCat::class,'category_id','id');
    }
}
