<?php

namespace App\Models\Video;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class VideoType extends Model
{
	protected $table = 'template_types';
	protected $connection = 'crafty_video_mysql';
    use HasFactory;
}
