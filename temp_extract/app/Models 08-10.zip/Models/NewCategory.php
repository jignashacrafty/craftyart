<?php

namespace App\Models;

use App\Http\Controllers\Api\HelperController;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

/**
 * @method static select(string $string)
 */
class NewCategory extends Model
{
    protected $connection = 'mysql';
    use HasFactory;
    protected $fillable = [
        'string_id',
        'canonical_link',
        'cat_link',
        'category_name',
        'primary_keyword',
        'id_name',
        'tag_line',
        'meta_title',
        'h1_tag',
        'h2_tag',
        'meta_desc',
        'short_desc',
        'long_desc',
        'category_thumb',
        'banner',
        'contents',
        'faqs',
        'mockup',
        'app_id',
        'top_keywords',
        'cta',
        'sequence_number',
        'status',
        'parent_category_id',
        'emp_id',
        'seo_emp_id',
        'fldr_str',
        'child_updated_at',
    ];

    public function checkIsLive()
    {
        return $this->status === 1;
    }


    public function parentCategory($isStatus = null)
    {
        if ($isStatus != null) {
            return $this->belongsTo(NewCategory::class, 'parent_category_id', 'id')->where('status', $isStatus);
        } else {
            return $this->belongsTo(NewCategory::class, 'parent_category_id', 'id');
        }
    }


    public function getRootParentId()
    {
        $category = $this;
        while ($category->parentCategory && $category->parentCategory->{"parent_category_id"} != 0) {
            $category = $category->parentCategory;
        }
        return $category->{"parent_category_id"};
    }

    public static function getAllCategoriesWithSubcategories($isStatus = null)
    {
        if ($isStatus != null) {
            $categories = NewCategory::where('parent_category_id', 0)->where('status', $isStatus)->get();
        } else {
            $categories = NewCategory::where('parent_category_id', 0)->get();
        }
        foreach ($categories as $category) {
            $category->subcategories = $category->getSubcategoriesTree($isStatus);
        }
        return $categories;
    }
    public static function getCategoriesWithSubcategories($category, $isStatus = null)
    {
        if (is_numeric($category)) {
            if ($isStatus != null) {
                $categories = NewCategory::where('id', $category)->where('status', $isStatus)->get();
            } else {
                $categories = NewCategory::where('id', $category)->get();
            }
        } else {
            if ($isStatus != null) {
                $categories = NewCategory::where('id_name', $category)->where('status', $isStatus)->get();
            } else {
                $categories = NewCategory::where('id_name', $category)->get();
            }
        }

        foreach ($categories as $category) {
            $category->subcategories = $category->getSubcategoriesTree($isStatus);
        }
        return $categories;
    }



    public static function getCategoriesWithSubcategories2(array $childCatIds, $isStatus = null)
    {
        $subCategories = NewCategory::whereIn('id', $childCatIds)
            ->where('status', 1)
            ->get();

        $extractSubcategories = function ($subcategories) use (&$extractSubcategories) {
            return collect($subcategories)->map(function ($subcategory) use ($extractSubcategories) {
                return [
                    'id' => $subcategory['id'],
                    'category_name' => $subcategory['category_name'],
                    'category_thumb' => HelperController::$mediaUrl . $subcategory['category_thumb'],
                    'id_name' => $subcategory['id_name'],
                    'status' => $subcategory['status'],
                ];
            })->toArray();
        };
        return $extractSubcategories($subCategories);
    }

    protected function getSubcategoriesTree($isStatus = null)
    {
        $subcategories = $this->subcategories($isStatus)->get();
        foreach ($subcategories as $subcategory) {
            $subcategory->subcategories = $subcategory->getSubcategoriesTree($isStatus);
        }
        return $subcategories;
    }

    public function subcategories($isStatus = null)
    {
        if ($isStatus != null) {
            return $this->hasMany(NewCategory::class, 'parent_category_id', 'id')->where('status', $isStatus);
        } else {
            return $this->hasMany(NewCategory::class, 'parent_category_id', 'id');
        }
    }


    public function newSearchTag(): HasMany
    {
        return $this->hasMany(NewSearchTag::class, 'new_category_id', 'id');
    }

    public static function getAllIMPCategoriesWithSubcategories($isStatus = null)
    {
        if ($isStatus != null) {
            $categories = NewCategory::where('parent_category_id', 0)->where('imp', 1)->where('status', $isStatus)->get();
        } else {
            $categories = NewCategory::where('parent_category_id', 0)->where('imp', 1)->get();
        }
        foreach ($categories as $category) {
            $category->subcategories = $category->getSubcategoriesTree($isStatus);
        }
        return $categories;
    }

}