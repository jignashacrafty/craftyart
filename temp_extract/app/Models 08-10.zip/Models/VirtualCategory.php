<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class VirtualCategory extends Model
{
    protected $connection = 'mysql';
    use HasFactory;

    public function assignedSeo()
{
    return $this->belongsTo(User::class, 'seo_emp_id');
}


}