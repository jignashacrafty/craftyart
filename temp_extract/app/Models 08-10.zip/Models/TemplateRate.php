<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TemplateRate extends Model
{
    protected $table = 'template_rates';
    use HasFactory;

    protected $fillable = [
        'id',
        'name',
        'value',
        'type'
    ];

    public static function getDefaultValue(): array
    {
        return [
            'inr' => [
                'base_price' => 99,
                'page_price' => 100,
                'max_price' => 399,
                'editor_choice'=>0,
                'animation'=>0
            ],
            'usd' => [
                'base_price' => 54,
                'page_price' => 20,
                'max_price' => 10,
                'editor_choice'=>0,
                'animation'=>0
            ],
        ];
    }

    public static function getRates($name)
    {
        $rate = TemplateRate::where('name', $name)->pluck('value')->first();

        if ($rate) {
            $decodedRate = json_decode($rate, true);

            if (self::checkRateStructure(self::getDefaultValue(), $decodedRate)) {
                return $decodedRate;
            }
        }

        return self::getDefaultValue();
    }

    private static function checkRateStructure(array $default, array $data): bool
    {
        foreach ($default as $currency => $fields) {
            if (!isset($data[$currency]) || !is_array($data[$currency])) {
                return false;
            }

            foreach ($fields as $key => $value) {
                if (!array_key_exists($key, $data[$currency])) {
                    return false;
                }
            }
        }
        return true;
    }
}