<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class OfferPopUp extends Model
{
    use HasFactory;

    protected $connection = 'mysql';
    protected $table = 'offer_popup';

    protected $fillable = [
        'enable_offer',
        'duration',
        'frequency_duration',
        'force_show_duration',
        'enable_force',
    ];
}
