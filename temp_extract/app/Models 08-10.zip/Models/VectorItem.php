<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class VectorItem extends Model
{
    use HasFactory;
    protected $connection = 'mysql';
    protected $fillable = [
        'svg_category_id',
        'emp_id',
        'name',
        'thumb',
        'file',
        'width',
        'height',
        'is_premium',
        'status',
    ];


    public function svgCategory(): BelongsTo
    {
        return $this->belongsTo(VectorCategory::class,'svg_category_id');
    }




}