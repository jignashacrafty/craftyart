<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Design extends Model
{
    protected $connection = 'mysql';
    use HasFactory;

    public function getsize()
    {
        // Define the hasOne relationship
        return $this->hasOne(Size::class, 'width_ration', 'width')
            ->where('height_ration', $this->height);
    }


    public function parent()
    {
        return $this->belongsTo(Design::class, 'category_id');
    }

    public function getPaperSizeAttribute()
    {
        return $this->getsize ? $this->getsize->paper_size : 'Unknown Size';
    }

    public function newCategory()
    {
        return $this->belongsTo(NewCategory::class, 'new_category_id');
    }

}