<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TransactionLog extends Model
{
	protected $connection = 'mysql';
    use HasFactory;

    protected $fillable = [
        'plan_id',
        'user_id',
        'transaction_id',
        'currency_code',
        'price_amount',
        'paid_amount',
        'coins',
        'discount',
        'payment_method',
        'from_where',
        'isManual',
        'plan_limits',
        'type',
        'status',
        'expired_at',
    ];


    public function userData()
    {
        return $this->belongsTo(UserData::class, 'user_id', 'uid');
    }
}
