<?php

namespace App\Models;

use App\Models\Video\VideoPurchaseHistory;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Laravel\Sanctum\HasApiTokens;
use Illuminate\Notifications\Notifiable;

class UserData extends Authenticatable
{
    protected $connection = 'mysql';

    use HasApiTokens, HasFactory, Notifiable;


    public function transactionLogs()
    {
        return $this->hasMany(TransactionLog::class, 'user_id', 'uid');
    }

    public function getReviews()
    {
        return $this->hasMany(Review::class, 'user_id', 'uid');
    }

    public function templatePurchaseLogs()
    {
        return $this->hasMany(PurchaseHistory::class, 'user_id', 'uid');
    }

    public function videPurchaseLogs()
    {
        return $this->hasMany(VideoPurchaseHistory::class, 'user_id', 'uid');
    }
}
