<?php

namespace App\Models;

use App\Http\Controllers\HelperController;
use App\Http\Controllers\Utils\AutomationUtils;
use App\Models\Video\VideoTemplate;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Carbon;

/**
 * App\Models\Order
 *
 * @property int $id
 * @property string|null $user_id
 * @property string|null $plan_id
 * @property string|null $contact_no
 * @property string $razorpay_order_id
 * @property string|null $razorpay_payment_id
 * @property string|null $stripe_payment_intent_id
 * @property string|null $stripe_txn_id
 * @property string $status
 * @property string|null $amount
 * @property string|null $paid
 * @property string $currency
 * @property string $type
 * @property mixed|null $raw_notes
 * @property Carbon|null $created_at
 * @property Carbon|null $updated_at
 * @property-read UserData|null $user
 * @property Subscription|null $subscription
 * @property OfferPackage|null $offerPackage
 * @property SubPlan|null $subPlan
 * @property Design|null $designs
 * @property int $email_template_count
 * @property int $whatsapp_template_count
 * @property int $followup_call
 * @property string|null $followup_note
 * @property int $is_deleted
 * @method static Builder|Order newModelQuery()
 * @method static Builder|Order newQuery()
 * @method static Builder|Order query()
 * @method static Builder|Order whereAmount($value)
 * @method static Builder|Order whereContactNo($value)
 * @method static Builder|Order whereCreatedAt($value)
 * @method static Builder|Order whereCurrency($value)
 * @method static Builder|Order whereId($value)
 * @method static Builder|Order wherePaid($value)
 * @method static Builder|Order wherePlanId($value)
 * @method static Builder|Order whereRawNotes($value)
 * @method static Builder|Order whereRazorpayOrderId($value)
 * @method static Builder|Order whereRazorpayPaymentId($value)
 * @method static Builder|Order whereStatus($value)
 * @method static Builder|Order whereStripePaymentIntentId($value)
 * @method static Builder|Order whereStripeTxnId($value)
 * @method static Builder|Order whereType($value)
 * @method static Builder|Order whereUpdatedAt($value)
 * @method static Builder|Order whereUserId($value)
 * @method static Builder|Order whereEmailTemplateCount($value)
 * @method static Builder|Order whereFollowupCall($value)
 * @method static Builder|Order whereFollowupNote($value)
 * @method static Builder|Order whereIsDeleted($value)
 * @method static Builder|Order whereWhatsappTemplateCount($value)
 * @mixin \Eloquent
 */
class Order extends Model
{
    use HasFactory;

    protected $connection = 'mysql';
    protected $table = 'orders';

    protected $fillable = [
        'user_id',
        'plan_id',
        'contact_no',
        'razorpay_order_id',
        'razorpay_payment_id',
        'stripe_payment_intent_id',
        'stripe_txn_id',
        'status',
        'amount',
        'paid',
        'currency',
        'email_template_count',
        'whatsapp_template_count',
        'followup_call',
        'followup_note',
        'type',
        'is_deleted',
        'raw_notes'
    ];

    public function user()
    {
        return $this->belongsTo(UserData::class, 'user_id', 'uid');
    }

    /**
     * Relationship for new_sub type orders - SubPlan
     */
    public function subPlan()
    {
        return $this->belongsTo(SubPlan::class, 'plan_id', 'string_id')
            ->orWhere('id', $this->plan_id);
    }

    /**
     * Relationship for old_sub and offer type orders - Subscription
     */
    public function subscription()
    {
        return $this->belongsTo(Subscription::class, 'plan_id');
    }

    public function offerPackage()
    {
        return $this->belongsTo(OfferPackage::class, 'plan_id', 'id');
    }

    /**
     * Accessor for designs for template type orders
     */
    public function getDesignsAttribute()
    {
        if ($this->type !== 'template') {
            return collect();
        }

        $templateData = json_decode($this->plan_id, true);
        if (!is_array($templateData)) {
            return collect();
        }

        $designIds = collect($templateData)->pluck('id')->filter()->toArray();

        return Design::whereIn('string_id', $designIds)->get();
    }

    /**
     * Accessor for video templates for video type orders
     */
    public function getVideoTemplatesAttribute()
    {
        if ($this->type !== 'video') {
            return collect();
        }

        $templateData = json_decode($this->plan_id, true);
        if (!is_array($templateData)) {
            return collect();
        }

        $videoIds = collect($templateData)->pluck('id')->filter()->toArray();

        return VideoTemplate::whereIn('string_id', $videoIds)->get();
    }

    /**
     * Get formatted plan items (common interface for both designs and videos)
     */
    public function getPlanItemsAttribute()
    {
        return match($this->type) {
            'template' => $this->designs,
            'video' => $this->videoTemplates,
            default => collect()
        };
    }

    /**
     * Get contact number for the order
     */
    public function getContactNoAttribute(): ?string
    {
        if (!empty($this->contact_no)) {
            return $this->contact_no;
        }

        if ($this->user && !empty($this->user->number)) {
            return $this->user->contact_no;
        }

        return null;
    }

    public function getAutomationCommonData(): array
    {
        $planType = $this->type;
        $currency = $this->currency;

        // Check if user exists
        if (!$this->user) {
            return ['success' => false, 'message' => "User not found for order {$this->id}"];
        }

        $commonData['userData'] = [
            'name' => $this->user->name ?? '',
            'email' => $this->user->email ?? '',
            'password' => "",
        ];

        if (in_array($planType, ['template', 'video'])) {
            // Always ensure we have a collection, not null
            $planItems = $this->planItems ?? collect();

            if ($planItems->isEmpty()) {
                return ['success' => false, 'message' => "No items found for {$planType} order {$this->id}"];
            }

            $templateData = json_decode($this->plan_id, true);
            if (!is_array($templateData)) {
                return ['success' => false, 'message' => "Invalid plan data for {$planType} order {$this->id}"];
            }

            $newArray = [];
            $paymentProps = [];

            foreach ($templateData as $item) {
                $planItem = $planItems->firstWhere(
                    $planType === 'template' ? 'string_id' : 'id',
                    $item['id']
                );

                if ($planItem) {
                    $paymentProps[] = ["id" => $item['id'], "type" => $planType === 'video' ? 1 : 0];

                    if ($planType === 'template') {
                        $newArray[] = [
                            "title" => $planItem->post_name,
                            "image" => HelperController::generatePublicUrl($planItem->post_thumb),
                            "width" => $planItem->width,
                            "height" => $planItem->height,
                            "amount" => $currency == "INR" ? $item['inrAmount'] : $item['usdAmount'],
                            "link" => HelperController::getFrontendPageUrl(0, $planItem->id_name),
                        ];
                    } else { // video
                        $newArray[] = [
                            "title" => $planItem->video_name,
                            "image" => HelperController::generatePublicUrl($planItem->video_thumb),
                            "width" => $planItem->width,
                            "height" => $planItem->height,
                            "amount" => $currency == "INR" ? $item['inrAmount'] : $item['usdAmount'],
                            "link" => "",
                        ];
                    }
                }
            }

            if (empty($newArray)) {
                return ['success' => false, 'message' => "No valid items found for order {$this->id}"];
            }

            $paymentLink = HelperController::$frontendUrl . "/redirect/" . AutomationUtils::generateBuyLink($paymentProps);

            $commonData['type'] = $planType;
            $commonData['data'] = [
                "templates" => $newArray,
                "amount" => ($currency == "INR" ? "₹" : "$") . $this->amount,
            ];
            $commonData['link'] = $paymentLink;
            $commonData['paymentLink'] = $paymentLink;
            $commonData['planType'] = $planType;
            $commonData['paymentProps'] = $paymentProps;

        } elseif ($planType === 'new_sub') {
            $plan = $this->subPlan;
            if (!$plan) {
                return ['success' => false, 'message' => "New SubPlan not found for order {$this->id}"];
            }

            $paymentLink = HelperController::$frontendUrl . "payment/redirect=https://editor.craftyartapp.com/payment";

            $commonData['type'] = "plan";
            $commonData['data'] = AutomationUtils::formatNewPlanData($plan, $currency);
            $commonData['link'] = "https://editor.craftyartapp.com/payment";
            $commonData['paymentLink'] = $paymentLink;
            $commonData['plan'] = $plan;
            $commonData['planType'] = $planType;

        } elseif ($planType === 'old_sub') {
            $plan = $this->subscription;
            if (!$plan) {
                return ['success' => false, 'message' => "Subscription not found for order {$this->id}"];
            }

            if (in_array($plan->id, [23, 24, 26])) {
                $paymentLink = "https://www.craftyartapp.com/offer-package";
            } else {
                $paymentLink = HelperController::$frontendUrl . "payment/redirect=https://editor.craftyartapp.com/payment";
            }

            $commonData['type'] = "plan";
            $commonData['data'] = AutomationUtils::formatOldPlanData($plan, $currency);
            $commonData['link'] = in_array($plan->id, [23, 24, 26])
                ? "https://www.craftyartapp.com/offer-package"
                : "https://editor.craftyartapp.com/payment";
            $commonData['paymentLink'] = $paymentLink;
            $commonData['plan'] = $plan;
            $commonData['planType'] = $planType;
        } elseif ($planType === 'offer'){
            $offerSubPlan = $this->offerPackage->subPlan;
            if (!$offerSubPlan) {
                return ['success' => false, 'message' => "Offer SubPlan not found for order {$this->id}"];
            }

            $paymentLink = HelperController::$frontendUrl . "payment/redirect=https://editor.craftyartapp.com/payment";

            $commonData['type'] = "plan";
            $commonData['data'] = AutomationUtils::formatNewPlanData($offerSubPlan, $currency);
            $commonData['link'] = "https://editor.craftyartapp.com/payment";
            $commonData['paymentLink'] = $paymentLink;
            $commonData['plan'] = $offerSubPlan;
            $commonData['planType'] = $planType;
        } else {
            return ['success' => false, 'message' => "Invalid plan type provided for order {$this->id}"];
        }

        return $commonData;
    }
}