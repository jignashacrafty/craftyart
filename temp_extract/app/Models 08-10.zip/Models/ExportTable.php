<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ExportTable extends Model
{
	protected $table = 'exports';
	protected $connection = 'mysql';
    use HasFactory;
}
