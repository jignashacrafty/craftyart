<form action="{{ $action }}" method="GET" class="w-100">
    <div class="form-row justify-content-end justify-content-evntly filter-access">

        <!-- Search Box -->
        <div class="form-group col-md-2 mb-0">
            <label class="text-secondary" for="query">Search</label>
            <input type="text" name="query" id="query" class="form-control" style="width: 185px !important;"
                placeholder="Search..." value="{{ request()->input('query') }}">
        </div>


        @if ($searchableFields)
        <!-- Filter Field Dropdown -->
        <div class="form-group col-md-2 mb-0">
            <label class="text-secondary" for="sort_by">Filter Field</label>
            <select name="sort_by" id="sort_by" class="form-control">
                <option value="" disabled {{ request('sort_by') ? '' : 'selected' }}>Select Field</option>
                @foreach ($searchableFields as $field)
                <option value="{{ $field['id'] }}" {{ request('sort_by') == $field['id'] ? 'selected' : '' }}>
                {{ $field['value'] }}
                </option>
                @endforeach
            </select>
        </div>

        <!-- Sort Order Dropdown -->
        <div class="form-group col-md-2 mb-0">
            <label class="text-secondary" for="sort_order">Sort Order</label>
            <select name="sort_order" id="sort_order" class="form-control">
                <option value="desc" {{ request('sort_order') == 'desc' ? 'selected' : '' }}>Descending</option>
                <option value="asc" {{ request('sort_order') == 'asc' ? 'selected' : '' }}>Ascending</option>
            </select>
        </div>
        @endif


        <!-- Per Page Dropdown -->
        <div class="form-group col-md-1 mb-0">
            <label class="text-secondary" for="per_page">Per Page</label>
            <select name="per_page" id="per_page" class="form-control">
                @foreach ([10, 20, 50, 100, 500, 'all'] as $count)
                    <option value="{{ $count }}" {{ request('per_page') == (string) $count ? 'selected' : '' }}>
                        {{ $count }}
                    </option>
                @endforeach
            </select>
        </div>

        <!-- Apply Button -->
        <div class="form-group col-md-2 mr-3 mb-0">
            <label class="text-secondary" class="d-block invisible"></label> <!-- invisible label for alignment -->
            <button type="submit" class="btn btn-success mt-2 w-100">
                <i class="bi bi-funnel"></i> Apply
            </button>
        </div>

    </div>
</form>
