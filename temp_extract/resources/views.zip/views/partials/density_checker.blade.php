<div class="page-header">
<div class="density d-flex justify-content-between">
    <h3>{{$title}}</h3>
    <div>
        @if (isset($slug))
        <button type="button" class="btn btn-outline-info check-density-btn" data-slug="{{ $slug }}"
                data-type="{{ $type }}">
            Check Keyword Density
        </button>
        @if (!empty($primary_keyword))
        <button type="button" class="btn btn-outline-success" id="checkPrimaryKeywordBtn"
                data-slug="{{ $slug }}" data-keyword="{{ $primary_keyword }}" data-type="{{ $type }}">
            Primary Keyword Check
        </button>
        @endif
        @endif
    </div>
</div>
</div>
<div class="modal fade" id="densityResultModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-scrollable"> <!-- Optional -->
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Keyword Density</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="densityResultContent" style="max-height: 83vh; overflow-y: auto;">
                Loading...
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="primaryKeywordModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Primary Keyword Check</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="primaryKeywordResult">
                Loading...
            </div>
        </div>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>
<script  type="text/javascript">
    $(document).on('click', '.check-density-btn', function() {
        const slug = $(this).data('slug');
        const type = $(this).data('type');

        $.ajax({
            url: "{{ route('density.check.slug') }}",
            method: "POST",
            data: {
                _token: '{{ csrf_token() }}',
                slug: slug,
                type: type
            },
            beforeSend: function() {
                $('#densityResultContent').html('<div class="text-center">Loading...</div>');
                $('#densityResultModal').modal('show');
            },
            success: function(html) {
                $('#densityResultContent').html(html);
            },
            error: function() {
                $('#densityResultContent').html(
                    '<div class="text-danger">Failed to fetch keyword density.</div>');
            }
        });
    });

    // $('#checkPrimaryKeywordBtn').on('click', function() {
    $(document).on('click', '#checkPrimaryKeywordBtn', function() {
        let slug = $(this).data('slug');
        let keyword = $(this).data('keyword');
        let type = $(this).data('type');


        if (!slug || !keyword || !type) {
            alert("Slug or Primary Keyword missing.");
            return;
        }

        $.ajax({
            url: "{{ route('density-checker.primary-check') }}",
            method: "POST",
            data: {
                _token: "{{ csrf_token() }}",
                slug: slug,
                type: type,
                keyword: keyword
            },
            beforeSend: function() {
                $('#primaryKeywordResult').html('Loading...');
                $('#primaryKeywordModal').modal('show');
            },
            success: function(res) {
                $('#primaryKeywordResult').html(res.html);
            },
            error: function(xhr) {
                $('#primaryKeywordResult').html(
                    '<div class="text-danger">Error occurred while checking.</div>');
            }
        });
    });
</script>