@inject('roleManager', 'App\Http\Controllers\Utils\RoleManager')
<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>Laravel</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

    <link rel="stylesheet" type="text/css" href="{{ asset('assets/vendors/styles/core.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/vendors/styles/icon-font.min.css') }}">
    <link rel="stylesheet" type="text/css"
        href="{{ asset('assets/plugins/datatables/css/dataTables.bootstrap4.min.css') }}">
    <link rel="stylesheet" type="text/css"
        href="{{ asset('assets/plugins/datatables/css/responsive.bootstrap4.min.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/vendors/styles/style.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/vendors/styles/loader.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/plugins/switchery/switchery.min.css') }}">
</head>

<body class="antialiased">

    @include('layouts.header')

    <div class="main-container">
        <div id="loading_screen" style="display: none;">
            <div id="loader-wrapper">
                <div id="loader"></div>
                <div class="loader-section section-left"></div>
                <div class="loader-section section-right"></div>
            </div>
        </div>
        <div class="pd-ltr-20 xs-pd-20-10">
            <div class="min-height-200px">
                <div class="card-box mb-30">
                    <div class="pb-20">
                        <span id="result"></span>
                        <div id="DataTables_Table_0_wrapper" class="dataTables_wrapper dt-bootstrap4 no-footer">

                            <div class="row">
                                <div class="col-sm-12 col-md-3">
                                    <!-- Add Religion Button -->
                                    <div class="pd-20">
                                        @if ($roleManager::onlySeoAccess(Auth::user()->user_type))
                                            <a href="javascript:void(0)" class="btn btn-primary"
                                                onclick="openAddModal()">
                                                Add Religion
                                            </a>
                                        @endif
                                    </div>
                                </div>

                                @php
                                    $isAdmin = Auth::user()->user_type;
                                @endphp
                                <input class="d-none" type="text" id="isAdmin" value="{{ $isAdmin }}">


                                <div class="col-sm-12 col-md-9">
                                    <div class="col-sm-12">
                                        <div class="pt-20">
                                            <form action="{{ route('religions.index') }}" method="GET">
                                                <div class="form-group">
                                                    <div id="DataTables_Table_0_filter" class="dataTables_filter">
                                                        <label>Search:<input type="text" class="form-control"
                                                                name="query" placeholder="Search here....."
                                                                value="{{ request()->input('query') }}"></label>
                                                        <button type="submit" class="btn btn-primary">Search</button>
                                                    </div>
                                                </div>
                                            </form>

                                        </div>
                                    </div>
                                </div>

                                <form id="create_relegion_action" action="{{ route('religions.create') }}"
                                    method="GET" style="display: none;">
                                    <input type="text" id="passingAppId" name="passingAppId">
                                    @csrf
                                </form>

                                <div class="col-sm-12 table-responsive">
                                    <table id="relegion_table" class="table table-striped">
                                        <thead>
                                            <tr>
                                                <th>Id</th>
                                                <th>Relegion</th>
                                                <th>User</th>
                                                <th>Status</th>
                                                <th class="datatable-nosort">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody id="relegion_table">
                                            @foreach ($religions as $religion)
                                                <tr style="background-color: #efefef;">
                                                    <td class="table-plus">{{ $religion->id }}</td>
                                                    <td class="table-plus">{{ $religion->religion_name }}</td>
                                                    <td class="table-plus">
                                                        {{ $roleManager::getUploaderName($religion->emp_id) }}
                                                    </td>
                                                    <td class="table-plus">
                                                        {{ $religion->status ? 'Active' : 'UnActive' }}</td>
                                                    <td>
                                                        <button class="dropdown-item btn-edit"
                                                            data-id="{{ $religion->id }}"
                                                            data-religion="{{ $religion->religion_name }}"
                                                            data-id-name="{{ $religion->id_name }}"
                                                            data-status="{{ $religion->status }}">
                                                            <i class="dw dw-edit2"></i> Edit
                                                        </button>
                                                        @if ($roleManager::isAdminOrSeoManager(Auth::user()->user_type))
                                                            <button class="dropdown-item"
                                                                onclick="delete_click('{{ $religion->id }}')"><i
                                                                    class="dw dw-delete-3"></i> Delete</button>
                                                        @endif
                                                    </td>
                                                </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>

                                <div class="row">
                                    <div class="col-sm-12 col-md-5">
                                        <div class="dataTables_info" id="DataTables_Table_0_info" role="status"
                                            aria-live="polite"></div>
                                    </div>
                                    <div class="col-sm-12 col-md-7">
                                        <div class="dataTables_paginate paging_simple_numbers"
                                            id="DataTables_Table_0_paginate">
                                            <ul class="pagination">
                                                {{ $religions->appends(request()->input())->links('pagination::bootstrap-4') }}
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal fade" id="delete_model" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel"
            aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <input type="text" id="delete_id" name="delete_id" style="display: none;">
                    <div class="modal-header">
                        <h4 class="modal-title" id="myLargeModalLabel">Delete</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    </div>
                    <div class="modal-body">
                        <p> Are you sure you want to delete? </p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">No, Cancel</button>
                        <button type="button" class="btn btn-primary" onclick="delete_click()">Yes, Delete</button>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade seo-all-container" id="religion_modal" tabindex="-1"
            role="dialog" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="religion_modal_title">Add Religion</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    </div>
                    <div class="modal-body">
                        <form id="religionForm">
                            @csrf
                            <input type="hidden" name="id" id="religion_id">

                            <div class="form-group">
                                <label>Religion Name</label>
                                <input type="text" class="form-control" name="religion_name" id="religion_name"
                                    required>
                            </div>

                            <div class="form-group">
                                <label>ID Name</label>
                                <input type="text" class="form-control" name="id_name" id="id_name" required>
                            </div>

                            <div class="form-group">
                                <label>Status</label>
                                <select class="form-control" name="status" id="status">
                                    <option value="1">Active</option>
                                    <option value="0">Disabled</option>
                                </select>
                            </div>

                            <div id="result"></div>
                            <button type="button" class="btn btn-primary btn-block"
                                id="submitReligionForm">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>


        <script src="{{ asset('assets/vendors/scripts/core.js') }}"></script>
        <script src="{{ asset('assets/vendors/scripts/script.min.js') }}"></script>
        <script src="{{ asset('assets/vendors/scripts/process.js') }}"></script>
        <script src="{{ asset('assets/vendors/scripts/layout-settings.js') }}"></script>
        <script src="{{ asset('assets/js/role_access.js') }}"></script>
        <script src="{{ asset('assets/plugins/datatables/js/jquery.dataTables.min.js') }}"></script>
        <script src="{{ asset('assets/plugins/datatables/js/dataTables.bootstrap4.min.js') }}"></script>
        <script src="{{ asset('assets/plugins/datatables/js/dataTables.responsive.min.js') }}"></script>
        <script src="{{ asset('assets/plugins/datatables/js/responsive.bootstrap4.min.js') }}"></script>
        <script src="{{ asset('assets/plugins/switchery/switchery.min.js') }}"></script>
        <script src="{{ asset('assets/vendors/scripts/advanced-components.js') }}"></script>
        <script src="https://unpkg.com/xlsx/dist/xlsx.full.min.js"></script>
        <script>
            // Converts string to Title Case
            const toTitleCase = str =>
                str.replace(/\b\w+/g, txt => txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase());

            // Converts string to snake_case
            const toSnakeCase = str =>
                str.trim().toLowerCase().replace(/\s+/g, '-');

            // Auto-generate ID name when typing
            $(document).on("input", "#religion_name", function() {
                const title = toTitleCase($(this).val());
                const idName = toSnakeCase(title);
                $(this).val(title);
                $("#id_name").val(idName);
            });

            // Open Add Modal
            function openAddModal() {
                $('#religion_modal_title').text("Add Religion");
                $('#submitReligionForm').text("Save");
                $('#religionForm')[0].reset();
                $('#religion_id').val('');
                $('#result').html('');
                $('#religion_modal').modal({
                    backdrop: 'static',
                    keyboard: false
                });
            }

            // Open Edit Modal
            $(document).on("click", ".btn-edit", function() {
                $('#religion_modal_title').text("Edit Religion");
                $('#submitReligionForm').text("Update");
                $('#result').html('');

                $('#religion_id').val($(this).data("id"));
                $('#religion_name').val($(this).data("religion"));
                $('#id_name').val($(this).data("id-name"));
                $('#status').val($(this).data("status"));

                $('#religion_modal').modal({
                    backdrop: 'static',
                    keyboard: false
                });
            });

            // Submit Add/Update
            $(document).on("click", "#submitReligionForm", function() {
                const id = $("#religion_id").val();
                const formData = {
                    religion_name: $("#religion_name").val(),
                    id_name: $("#id_name").val(),
                    status: $("#status").val(),
                    religion_id: id,
                    _token: $('meta[name="csrf-token"]').attr("content")
                };

                $.ajax({
                    url: "{{ route('religions.submit') }}",
                    type: "POST",
                    data: formData,
                    success: function(data) {
                        if (data.status) {

                            setTimeout(() => {
                                $('#religion_modal').modal('hide');
                                location.reload();
                            }, 1000);
                        } else {
                            alert(data.error);

                        }
                    },
                    error: function(xhr) {
                        let message = 'Something went wrong.';
                        if (xhr.responseJSON && xhr.responseJSON.message) {
                            message = xhr.responseJSON.message;
                        } else if (xhr.responseText) {
                            message = xhr.responseText;
                        }
                        alert(message);

                    }
                });
            });




            function set_delete_id($id) {
                $("#delete_id").val($id);
            }

            function delete_click(id) {

                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                    }
                });

                var url = "{{ route('religions.destroy', ':id') }}";
                url = url.replace(":id", id);

                $.ajax({
                    url: url,
                    type: 'DELETE',
                    beforeSend: function() {
                        // $('#delete_model').modal('toggle');
                        var loading_screen = document.getElementById("loading_screen");
                        loading_screen.style.display = "block";
                    },
                    success: function(data) {
                        var loading_screen = document.getElementById("loading_screen");
                        loading_screen.style.display = "none";
                        if (data.error) {
                            window.alert('error==>' + data.error);
                        } else {
                            location.reload();
                        }
                    },
                    error: function(error) {
                        var loading_screen = document.getElementById("loading_screen");
                        loading_screen.style.display = "none";
                        window.alert(error.responseText);
                    },
                    cache: false,
                    contentType: false,
                    processData: false
                })
            }
        </script>
</body>

</html>
