/<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Laravel</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap"
          rel="stylesheet">

    <link rel="stylesheet" type="text/css" href="{{asset('assets/vendors/styles/core.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('assets/vendors/styles/icon-font.min.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('assets/vendors/styles/style.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('assets/vendors/styles/loader.css')}}">
</head>
<body class="antialiased">

@include('layouts.header')

<div class="main-container">
    <div id="loading_screen" style="display: none;">
        <div id="loader-wrapper">
            <div id="loader"></div>
            <div class="loader-section section-left"></div>
            <div class="loader-section section-right"></div>
        </div>
    </div>

    <div class="pd-ltr-20 xs-pd-20-10">
        <div class="min-height-200px">
            <div class="pd-20 card-box mb-30">
                <form method="post" id="dynamic_form" enctype="multipart/form-data">

                    <span id="result"></span>

                    @csrf

                    <div class="form-group">
                        <h6>Sticker Thumbs</h6>
                        <input type="file" class="form-control-file form-control height-auto" id="stk_item_thumb" name="stk_item_thumb[]" multiple
                        accept="image/*" required>
                    </div>

                    <div class="form-group">
                        <h6>Sticker Images</h6>
                        <input type="file" class="form-control-file form-control height-auto" id="stk_item" name="stk_items[]" multiple
                        accept="image/*" required>
                    </div>

                    <div class="form-group">
                        <h6>Select Category</h6>
                        <div class="col-sm-20">
                            <select id="category_id" class="selectpicker form-control" data-style="btn-outline-primary" name="category_id" required>
                                <option value="" disabled="true" selected="true">== Select Category ==</option>
                                @foreach($datas['stkCatArray'] as $cat)
                                    <option value="{{ $cat->id }}">{{ $cat->stk_category_name }}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <h6>Sticker Type</h6>
                        <div class="col-sm-20">
                            <select id="sticker_type" class="selectpicker form-control" data-style="btn-outline-primary" name="sticker_type">
                                @foreach($datas['sticker_mode'] as $sticker)
                                    <option value="{{ $sticker->value }}">{{ $sticker->type }}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <h6>Premium Item</h6>
                        <div class="col-sm-20">
                            <select id="is_premium" class="selectpicker form-control" data-style="btn-outline-primary" name="is_premium">
                                <option value="0">FALSE</option>
                                <option value="1">TRUE</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <h6>Status</h6>
                        <div class="col-sm-20">
                            <select class="selectpicker form-control" data-style="btn-outline-primary" id="status" name="status">
                                <option value="1">LIVE</option>
                                <option value="0">NOT LIVE</option>
                            </select>
                        </div>
                    </div>

                    <div>
                        <input class="btn btn-primary" type="submit" name="submit">
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<script src="{{asset('assets/vendors/scripts/core.js')}}"></script>
<script src="{{asset('assets/vendors/scripts/script.min.js')}}"></script>

<script>
    $('#dynamic_form').on('submit', function (event) {
        event.preventDefault();

        count = 0;

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
            }
        });

        var formData = new FormData(this);

        $.ajax({
            url: 'submit_sticker_item',
            type: 'POST',
            data: formData,
            beforeSend: function () {
                var loading_screen = document.getElementById("loading_screen");
                loading_screen.style.display = "block";
            },
            success: function (data) {
                hideFields();
                if (data.error) {
                    var error_html = '';
                    for (var count = 0; count < data.error.length; count++) {
                        error_html += '<p>' + data.error[count] + '</p>';
                    }
                    $('#result').html('<div class="alert alert-danger">' + error_html + '</div>');
                } else {
                    $('#result').html('<div class="alert alert-success">' + data.success + '</div>');
                }
                setTimeout(function () {
                    $('#result').html('');
                }, 3000);
            },
            error: function (error) {
                hideFields();
                window.alert(error.responseText);
            },
            cache: false,
            contentType: false,
            processData: false
        })
    });

    function hideFields() {

        $("#stk_item_thumb").val('');
        $("#stk_item").val('');
        $("#status").val('');

        var loading_screen = document.getElementById("loading_screen");
        loading_screen.style.display = "none";

    }


</script>
</body>
</html>
