@inject('helperController', 'App\Http\Controllers\HelperController')
<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>Laravel</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap"
          rel="stylesheet">

    <link rel="stylesheet" type="text/css"
          href="{{asset('assets/plugins/bootstrap-tagsinput/bootstrap-tagsinput.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('assets/vendors/styles/core.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('assets/vendors/styles/icon-font.min.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('assets/vendors/styles/style.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('assets/vendors/styles/loader.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('assets/vendors/styles/custom.css')}}">

</head>
<body class="antialiased">

@include('layouts.header')

<div class="main-container">

    <div id="loading_screen" style="display: none;">
        <div id="loader-wrapper">
            <div id="loader"></div>
            <div class="loader-section section-left"></div>
            <div class="loader-section section-right"></div>
        </div>
    </div>

    <div class="pd-ltr-20 xs-pd-20-10">
        <div class="min-height-200px">

            <div class="page-header">
                <div class="row">
                    <div class="col-md-6 col-sm-12">
                        <div class="title">
                            Size Thumb
                        </div>
                    </div>
                </div>
            </div>

            <div class="pd-20 card-box mb-30">
                <form method="post" id="createSizeForm">
                    <span id="result"></span>
                    @csrf
                    <div class="row">
                        <div class="col-md-6 col-sm-12">
                            <div class="form-group">
                                <h6>Size Name</h6>
                                <input id="post_name" class="form-control-file form-control" name="size_name" required>
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-12">
                            <div class="form-group">
                                <h6>ID Name</h6>
                                <input id="idName" class="form-control-file form-control" name="id_name" required>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6 col-sm-12">
                            <div class="form-group">
                                <h6>Width Ration</h6>
                                <input class="form-control" id="widthRation" type="text" name="width_ration" required="" step="any">
                            </div>
                        </div>

                        <div class="col-md-6 col-sm-12">
                            <div class="form-group">
                                <h6>Height Ration</h6>
                                <input class="form-control" id="heightRation" type="text" name="height_ration" required="" step="any">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        {{-- <div class="col-md-6 col-sm-12">
                            <div class="form-group">
                                <h6>Units</h6>
                                <select class="form-control" name="unit" id="unitInput">
                                    <option value="px">PX</option>
                                    <option value="inch">Inch</option>
                                </select>
                            </div>
                        </div> --}}


                        <div class="col-md-6 col-sm-12" style="height: 46px;margin-bottom:38px;">
                            <div class="form-group category-dropbox-wrap">
                                <h7>Select New Category</h7>
                                <div class="input-subcategory-dropbox unset-bottom-border" id="parentCategoryInput" style="border-bottom: 1px solid #ced4da;"><span>== none ==</span> <i style="font-size:18px" class="fa down-arrow-dropbox">&#xf107;</i></div>
                                    <div class="custom-dropdown parent-category-input">
                                        <input type="text" id="categoryFilter" class="form-control-file form-control" placeholder="Search categories">
                                        <ul class="dropdown-menu-ul filter-wrap-list">
                                            <li class="category none-option">== none ==</li>
                                            @foreach ($allNewCategories as $category)
                                                @php
                                                    $classBold = (!empty($category['subcategories']) && isset($category['subcategories'][0])) ? "has-children" : "has-parent";
                                                    $selected = (isset($dataArray['item']['new_category_id']) && $dataArray['item']['new_category_id'] == $category['id']) ? "selected" : "";
                                                @endphp
                                                <li class="category {{$classBold}} {{$selected}}" data-id="{{$category['id']}}" data-catname="{{$category['category_name']}}">
                                                    <span>{{ $category['category_name'] }}</span>
                                                    @if (!empty($category['subcategories']))
                                                        <ul class="subcategories">
                                                            @foreach ($category['subcategories'] as $subcategory)
                                                                @include('partials.subcategory-filter-optgroup', ['subcategory' => $subcategory,'sub_category_id' => $subcategory['id'],'sub_category_name' => $subcategory['category_name']])
                                                            @endforeach
                                                        </ul>
                                                    @endif
                                                </li>
                                            @endforeach
                                        </ul>
                                    </div>
                                    <div class="popup-container" id="newCategoryRequiredPopup">
                                        <p><span class="required-icon">!</span>Please select a new category.</p>
                                    </div>
                                    <input type="hidden" name="new_category_id" value="0">

                            </div>
                        </div>
                        <div class="col-md-6 col-sm-12">
                            <div class="form-group">
                                <h6>Status</h6>
                                <select id="status" class="selectpicker form-control" data-style="btn-outline-primary" name="status">
                                    <option value="1">Active</option>
                                    <option value="0">Disable</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div>
                        <input class="btn btn-primary" type="submit" name="submit">
                    </div>
                </form>
            </div>
        </div>
    </div>

</div>
<script src="{{asset('assets/vendors/scripts/core.js')}}"></script>
<script src="{{asset('assets/vendors/scripts/script.min.js')}}"></script>
<script src="{{asset('assets/vendors/scripts/advanced-components.js')}}"></script>
<script src="{{asset('assets/plugins/bootstrap-tagsinput/bootstrap-tagsinput.js')}}"></script>
<script>

    $('.bg_type_id').change(function () {
        if ($(this).val() === '0' || $(this).val() === '1') {
            $('.back_image').attr('required', '');
            var x = document.getElementById("back_image_field");
            x.style.display = "block";

            $('.color_code').removeAttr('required');
            var x1 = document.getElementById("color_code_field");
            x1.style.display = "none";

        } else {
            $('.color_code').attr('required', '');
            var x = document.getElementById("color_code_field");
            x.style.display = "block";

            $('.back_image').removeAttr('required');
            var x1 = document.getElementById("back_image_field");
            x1.style.display = "none";

        }
    });


    $('#createSizeForm').on('submit', function (event) {
        event.preventDefault();
        count = 0;
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
            }
        });

        var formData = new FormData(this);

        $.ajax({
            url: "{{route('sizes.store')}}",
            type: 'POST',
            dataType: 'json',
            data: formData,
            beforeSend: function () {
                var loading_screen = document.getElementById("loading_screen");
                loading_screen.style.display = "block";
            },
            success: function (data) {
                if (data.error) {
                    $('#result').html('<div class="alert alert-danger">' + data.error + '</div>');
                } else {
                    $('#result').html('<div class="alert alert-success">' + data.success + '</div>');
                    window.location.href = "{{route('sizes.index')}}";
                }
                hideFields();
                setTimeout(function () {
                    $('#result').html('');
                }, 3000);

            },
            error: function (error) {

                hideFields();
                window.alert(error.responseText);
            },
            cache: false,
            contentType: false,
            processData: false
        })
    });

    $(document).on('click', '#remove_bg_info', function () {
        $(this).closest(".row").remove();
    });

    $(document).on('click', '#add_text_info', function () {
        dynamic_text_field();
    });

    $(document).on('click', '#remove_text_info', function () {
        $(this).closest(".row").remove();
    });

    $(document).on('click', '#add_component_info', function () {
        dynamic_component_field();
    });

    $(document).on('click', '#remove_component_info', function () {
        $(this).closest(".row").remove();
    });

    function hideFields() {
        $('#createSizeForm')[0].reset();
        var loading_screen = document.getElementById("loading_screen");
        loading_screen.style.display = "none";
    }

     /* New Category */

     $(document).on('click','#parentCategoryInput',function(){
        $("#newCategoryRequiredPopup").hide();
        if( $('.parent-category-input').hasClass('show') ){
            $('.parent-category-input').removeClass('show');
        }else{
            $(".parent-category-input").addClass('show');
        }
    });

    $(document).on("click", ".category", function(event) {
        $(".category").removeClass("selected");
        $(".subcategory").removeClass("selected");
        var id = $(this).data('id');
        $("input[name='new_category_id']").val(id);
        $("#parentCategoryInput span").html($(this).data('catname'));
        $('.parent-category-input').removeClass('show');
        $(this).addClass("selected");
        loadNewSearchKeywords(id);
    });

    $(document).on("click", ".subcategory", function(event) {
        event.stopPropagation();
        $(".category").removeClass("selected");
        $(".subcategory").removeClass("selected");
        var id = $(this).data('id');
        var parentId = $(this).data('pid');
        $("input[name='new_category_id']").val(id);
        $('.parent-category-input').removeClass('show');
        $("#parentCategoryInput span").html($(this).data('catname'));
        $(this).addClass("selected");
        loadNewSearchKeywords(id);
    });

    if ( $("#new_category_id").val() !== "" && $("#new_category_id").val() !== "0" ) {
        loadNewSearchKeywords($("#new_category_id").val());
    }
    $(document).on('click', function(e) {
        if (!$(e.target).closest('.form-group.category-dropbox-wrap').length) {
            $('.custom-dropdown.parent-category-input.show').removeClass('show');
        }
    });

    $(document).on("click","li.category.none-option",function(){
        $("input[name='new_category_id']").val("0");
        $('.parent-category-input').removeClass('show');
        $("#parentCategoryInput span").html('== none ==');
    });

    $('#categoryFilter').on('input', function() {
        var filterValue = $(this).val().toLowerCase();
        $('.category, .subcategory').each(function() {
            var text = $(this).text().toLowerCase();
            if (text.indexOf(filterValue) > -1) {
                $(this).show();
            } else {
                $(this).hide();
            }
        });
    });
    jQuery.noConflict();

</script>

</body>
</html>
