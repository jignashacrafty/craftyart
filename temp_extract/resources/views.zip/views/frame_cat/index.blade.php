@inject('roleManager', 'App\Http\Controllers\Utils\RoleManager')

<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>Laravel</title>
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

    <link rel="stylesheet" type="text/css" href="{{ asset('assets/vendors/styles/core.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/vendors/styles/icon-font.min.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/vendors/styles/style.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/vendors/styles/custom.css') }}">
    <style>
        .sort-arrow {
            margin-left: 0px;
        }

        .sort-arrow.active {
            color: #1739d1ec;
        }

        .sort-arrow {
            font-family: 'dropways';
            font-size: 14px;
            color: grey;
        }

        .sort-asc::before {
            content: "\eabb";
        }

        .sort-desc::before {
            content: "\eaba";
        }

        .sort-asc.active::before,
        .sort-desc.active::before {
            color: #1b00ff;
        }

        span.sort-arrow.sort-desc {
            margin-left: -7px;
        }

        .form-row input.form-control {
            width: 297px;
        }

        .pd-20.f-left {
            float: left;
        }

        .form-row.f-right {
            padding: 20px;
            float: right;
        }

        .row ul.pagination {
            margin-bottom: 10px;
            float: right;
            margin-right: 20px;
        }
    </style>
</head>

<body class="antialiased">
@include('layouts.header')
<div class="main-container designer-access-container">
    <div class="pd-ltr-20 xs-pd-20-10">
        <div class="min-height-200px">
            <div class="card-box mb-30">
                <div class="row justify-content-between pb-30 pt-30">
                    <div class="col-md-3">
                        @if ($roleManager::onlyDesignerAccess(Auth::user()->user_type))
                            <button type="button" class="btn btn-primary ml-4 mt-4" id="addNewFrameCatBtn">
                                + Add Frame Category
                            </button>
                        @endif
                    </div>

                    <div class="col-md-9">
                        @include('partials.filter_form ', [
                        'action' => route('frame_categories.index'),
                        ])
                    </div>
                </div>

                <table id="shap_category_table" class="table table-striped">
                    <thead>
                    <tr>
                        <th>Id</th>
                        <th>User</th>
                        <th>Name</th>
                        <th>Category Thumb</th>
                        <th>Sequence Number</th>
                        <th>Status</th>
                        <th >Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach ($allCategories as $framesCat)
                    <tr>
                        <td class="table-plus">{{ $framesCat->id }}</td>
                        <td>{{ $roleManager::getUploaderName($framesCat->emp_id) }}
                        <td>{{ $framesCat->name }}</td>
                        <td><img src="{{ \App\Http\Controllers\Utils\ContentManager::getStorageLink($framesCat->thumb) }}"
                                 style="max-width: 100px; max-height: 100px; width: auto; height: auto"/>
                        </td>
                        <td>{{ $framesCat->sequence_number }}</td>
                        @if ($framesCat->status == '1')
                        <td>LIVE</td>
                        @else
                        <td>NOT LIVE</td>
                        @endif

                        <td>
                            <button class="dropdown-item edit-frame-category-btn"
                                    data-id="{{ $framesCat->id }}">
                                <i class="dw dw-edit2"></i> Edit
                            </button>
                            @if ($roleManager::isAdminOrDesignerManager(Auth::user()->user_type))
                            <a class="dropdown-item" href="#"
                               onclick="deleteFrameCategory({{ $framesCat['id'] }})">
                                <i class="dw dw-delete-3"></i> Delete
                            </a>
                            @endif
                        </td>
                    </tr>
                    @endforeach
                    </tbody>
                </table>
                @include('partials.pagination', ['items' => $allCategories])
            </div>
        </div>
    </div>
</div>

<div class="modal fade designer-access-container" id="add_frame_category_model" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" style="max-width: 676px;">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add/Edit Frame Category</h5>
                <button type="button" class="close" data-dismiss="modal">×</button>
            </div>

            <div class="modal-body">
                <form method="POST" id="frame_cate_form" enctype="multipart/form-data">
                    <input type="hidden" name="id" id="frame_category_id">

                    <div class="form-group">
                        <h6>Frame Category Name</h6>
                        <input class="form-control" type="text" id="name"
                               name="name" required>
                    </div>

                    <div class="form-group">
                        <h6>Parent Category</h6>
                        <select class="form-control" name="parent_category_id" id="parent_category_id">
                            <option value="0">== none ==</option>
                            @foreach ($allCategories as $category)
                            <option value="{{ $category->id }}">{{ $category->name }}</option>
                            @if (!empty($category->subcategories))
                            @foreach ($category->subcategories as $sub)
                            <option value="{{ $sub->id }}">-- {{ $sub->name }}</option>
                            @endforeach
                            @endif
                            @endforeach
                        </select>
                    </div>

                    <div class="form-group">
                        <h6>Frame Category Thumb</h6>
                        <input type="file" class="form-control-file form-control dynamic-file" id="thumb_file"
                               data-accept=".jpg, .jpeg, .webp, .svg" accept="image/*" data-imgstore-id="thumb"
                               data-nameset="true">
                    </div>

                    <div class="form-group">
                        <h6>Sequence Number</h6>
                        <input class="form-control" type="text" id="sequence_number" name="sequence_number"
                               required>
                    </div>

                    <div class="form-group">
                        <h6>Status</h6>
                        <select class="form-control" id="status" name="status">
                            <option value="1">LIVE</option>
                            <option value="0">NOT LIVE</option>
                        </select>
                    </div>

                    <div class="text-right">
                        <button type="submit" class="btn btn-primary" id="frame_form_submit">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
    const STORAGE_URL = "{{ env('STORAGE_URL') }}";
    // *Debug
    const storageUrl = "{{ config('filesystems.storage_url') }}";
</script>
<script src="{{ asset('assets/vendors/scripts/core.js') }}"></script>
<script src="{{ asset('assets/vendors/scripts/script.min.js') }}"></script>
<script src="{{ asset('assets/js/dynamicfile.js') }}"></script>
<script src="{{ asset('assets/js/role_access.js') }}"></script>
<script>
    function deleteFrameCategory(id) {
        event.preventDefault();
        if (confirm('Are you sure you want to delete this frame category?')) {
            $.ajax({
                url: "{{ route('frame_categories.destroy', ':id') }}".replace(':id', id),
                type: 'DELETE',
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function (response) {
                    window.location.reload();
                },
                error: function (xhr) {
                    alert('Failed to delete frame category. Please try again later.');
                }
            });
        }
    }

    $(document).ready(function () {
        $('#addNewFrameCatBtn').on('click', function () {
            resetFrameCategoryForm();
            $('#add_frame_category_model').modal('show');
        });

        $(document).on('click', '.edit-frame-category-btn', function () {
            const id = $(this).data('id');
            $.get("{{ url('frame_categories') }}/" + id + "/edit")
                .done(function (data) {
                    $('#frame_category_id').val(data.id);
                    $('#name').val(data.name);
                    $('#parent_category_id').val(data.parent_category_id);
                    $('#sequence_number').val(data.sequence_number);
                    $('#status').val(data.status);

                    const imageUrl = getStorageLink(data.thumb);
                    $('#thumb_file').attr('data-value', imageUrl);
                    dynamicFileCmp();
                    $('#result').html('');

                    $('#add_frame_category_model').modal('show');
                })
                .fail(function (jqXHR, textStatus, errorThrown) {
                    alert("Failed to load frame category. Please try again.");
                });
        });

        $('#frame_cate_form').on('submit', function (e) {
            e.preventDefault();
            const form = this;
            const formData = new FormData(form);
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.post({
                url: `{{ route('frame_categories.store') }}`,
                data: formData,
                contentType: false,
                processData: false,
                success: res => res.status ? location.reload() : alert(res.error),
                error: xhr => alert(xhr.responseText)
            });
        });


        function resetFrameCategoryForm() {
            $('#frame_cate_form')[0].reset();
            resetDynamicFileValue("thumb_file")
            $('#frame_category_id').val('');
        }
    });
</script>
</body>

</html>
