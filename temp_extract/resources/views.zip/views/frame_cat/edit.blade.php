<span id="result"></span>
<div class="form-group">
    <h6>Category Name</h6>
    <input class="form-control" type="textname" name="name" value="{{$frameCategory->name}}" required>
</div>
<div class="form-group category-dropbox-wrap">
    <h6>Parent Category</h6>
    @php
        $parentCatName = \App\Http\Controllers\HelperController::getParentCatName($frameCategory->parent_category_id, \App\Models\FrameCategory::query(), 'name');
    @endphp
    <div class="input-subcategory-dropbox" id="parentCategoryInput"><span>
            @if (isset($parentCatName) && $parentCatName != '')
                {{ $parentCatName }}
            @else
                {{"== none =="}}
            @endif
        </span> <i style="font-size:18px" class="fa down-arrow-dropbox">&#xf107;</i></div>
    <div class="custom-dropdown parent-category-input">
        <ul class="dropdown-menu-ul">
            <li class="category none-option">== none ==</li>
            @foreach ($allCategories as $category)
                                    @php
                                        $classBold = (!empty($category['subcategories']) && isset($category['subcategories'][0])) ? "has-children" : "has-parent";
                                        $selected = (isset($frameCategory->parent_category_id) && $frameCategory->parent_category_id == $category['id']) ? "selected" : "";
                                    @endphp
                                    <li class="category {{$classBold}} {{$selected}}" data-id="{{$category['id']}}"
                                        data-catname="{{$category['name']}}">
                                        <span>{{ $category['name'] }}</span>
                                        @if (!empty($category['subcategories']))
                                            <ul class="subcategories">
                                                @foreach ($category['subcategories'] as $subcategory)
                                                    @include('partials.subframecategory-optgroup', ['subcategory' => $subcategory, 'sub_category_id' => $subcategory['id'], 'sub_category_name' => $subcategory['name']])
                                                @endforeach
                                            </ul>
                                        @endif
                                    </li>
            @endforeach
        </ul>
    </div>
</div>
<input type="hidden" name="parent_category_id"
    value="{{isset($frameCategory->parent_category_id) ? $frameCategory->parent_category_id : '0'}}">
<div class="form-group">
    <h6>Category Thumb</h6>
    <input type="file" class="form-control-file form-control height-auto" name="frame_category_thumb"><br />
    <img src="{{ config('filesystems.storage_url') }}{{$frameCategory->thumb}}" width="100" />
    <input class="form-control" type="textname" id="cat_thumb_path" name="thumb" value="{{$frameCategory->thumb}}"
        style="display: none">
</div>

<div class="form-group">
    <h6>Sequence Number</h6>
    <input class="form-control" type="textname" name="sequence_number" value="{{$frameCategory->sequence_number}}"
        required>
</div>
<div class="form-group">
    <h6>Status</h6>
    <div class="col-sm-20">
        <select class="selectpicker form-control" data-style="btn-outline-primary" name="status" id="status">
            @if($frameCategory->status == 1)
                <option value="1" selected>LIVE</option>
                <option value="0">NOT LIVE</option>
            @else
                <option value="1">LIVE</option>
                <option value="0" selected>NOT LIVE</option>
            @endif
        </select>
    </div>
</div>
<div>
    <input type="hidden" name="frame_cate_id" id="frameCateId"
        value="{{isset($frameCategory->id) ? $frameCategory->id : ''}}">
    <input class="btn btn-primary" type="submit" name="submit">
</div>