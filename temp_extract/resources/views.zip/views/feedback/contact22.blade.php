@inject('helperController', 'App\Http\Controllers\HelperController')
<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="{{ csrf_token() }}" />

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

        <link rel="stylesheet" type="text/css" href="{{asset('assets/vendors/styles/core.css')}}">
        <link rel="stylesheet" type="text/css" href="{{asset('assets/vendors/styles/icon-font.min.css')}}">
        <link rel="stylesheet" type="text/css" href="{{asset('assets/plugins/datatables/css/dataTables.bootstrap4.min.css')}}">
        <link rel="stylesheet" type="text/css" href="{{asset('assets/plugins/datatables/css/responsive.bootstrap4.min.css')}}">
        <link rel="stylesheet" type="text/css" href="{{asset('assets/vendors/styles/style.css')}}">
        <link rel="stylesheet" type="text/css" href="{{asset('assets/vendors/styles/loader.css')}}">
    </head>
    <body class="antialiased">

        @include('layouts.header')

        <div class="main-container">
            <div id="loading_screen" style="display: none;">
                <div id="loader-wrapper">
                    <div id="loader"></div>
                    <div class="loader-section section-left"></div>
                    <div class="loader-section section-right"></div>
                </div>
            </div>

            <div class="pd-ltr-20 xs-pd-20-10">
                <div class="min-height-200px">
                    <div class="card-box mb-30">
                        <div class="pd-20">
                          
                        </div>
                        <div class="pb-20">

                            <table class="data-table table stripe hover nowrap">
                                <thead>
                                    <tr>
                                        <th>Index</th>
                                        <th>User ID</th>
                                        <th>Created At</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($contactArray as $contactRow)
                                    <tr>
                                        <td class="table-plus">{{$contactRow->id}}</td>
                                        
                                        <td>{{$contactRow->user_id}}</td>

                                        <td>{{$contactRow->created_at}}</td>

                                        <td>
                                            <Button class="dropdown-item" onclick="show_click('{{$contactRow->id}}')">Show</Button>
                                        </td>
                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div
            class="modal fade"
            id="show_contact_model"
            tabindex="-1"
            role="dialog"
            aria-labelledby="myLargeModalLabel"
            aria-hidden="false">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                   <div class="modal-header">
                        <h5 class="modal-title" id="myLargeModalLabel">Contact</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    </div>

                    <div class="modal-body" id="contact_model">
                    </div>

                </div>
            </div>
        </div>

        <script src="{{asset('assets/vendors/scripts/core.js')}}"></script>
        <script src="{{asset('assets/vendors/scripts/script.min.js')}}"></script>
        <script src="{{asset('assets/vendors/scripts/process.js')}}"></script>
        <script src="{{asset('assets/vendors/scripts/layout-settings.js')}}"></script>
        <script src="{{asset('assets/plugins/datatables/js/jquery.dataTables.min.js')}}"></script>
        <script src="{{asset('assets/plugins/datatables/js/dataTables.bootstrap4.min.js')}}"></script>
        <script src="{{asset('assets/plugins/datatables/js/dataTables.responsive.min.js')}}"></script>
        <script src="{{asset('assets/plugins/datatables/js/responsive.bootstrap4.min.js')}}"></script>
        <!-- Datatable Setting js -->
        <script src="{{asset('assets/vendors/scripts/datatable-setting.js')}}"></script>


        <script>
            function show_click(id) {
                $("#contact_model").empty();

                $.ajax({
                    url: 'getContact/'+id,
                    type: 'GET',
                    beforeSend: function () {
                        var loading_screen = document.getElementById("loading_screen");
                        loading_screen.style.display = "block";
                    },
                    success: function (data) {
                        setTimeout(function () {
                            hideFields();
                            $('#show_contact_model').modal('toggle');
                            if (data.error) {
                                window.alert(data.error);
                            } else {
                                html = '<div class="form-group"><div class="input-group custom"><textarea class="form-control" readonly>'+data.success+'</textarea> </div> </div>';
                                $("#contact_model").append(html);
                            }
                        }, 500);

                    },
                    error: function (error) {

                        hideFields();
                        window.alert(error.responseText);
                    },
                    cache: false,
                    contentType: false,
                    processData: false
                })
            }

            function hideFields() {
                var loading_screen = document.getElementById("loading_screen");
                loading_screen.style.display = "none";
            }

        </script>

    </body>
</html>
