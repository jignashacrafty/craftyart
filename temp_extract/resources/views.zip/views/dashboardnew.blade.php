<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Laravel</title>
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

        <link rel="stylesheet" type="text/css" href="{{asset('assets/vendors/styles/core.css')}}">
        <link rel="stylesheet" type="text/css" href="{{asset('assets/vendors/styles/icon-font.min.css')}}">
        <link rel="stylesheet" type="text/css" href="{{asset('assets/plugins/datatables/css/dataTables.bootstrap4.min.css')}}">
        <link rel="stylesheet" type="text/css" href="{{asset('assets/plugins/datatables/css/responsive.bootstrap4.min.css')}}">
        <link rel="stylesheet" type="text/css" href="{{asset('assets/vendors/styles/style.css')}}">
        <link rel="stylesheet" type="text/css" href="{{asset('assets/vendors/styles/custom.css')}}">

        <style>
            table.main-row-tb {
                width: 100%;
                border: 1px solid #00000024;
                border-radius: 7px;
                padding: 5px 5px;
                display: table;
                text-align: center;
            }

            table.main-row-tb thead {
                background-color: #70c8e19e;
                color: #fff;
            }

            table.row-col-tb {
                width: 100%;
                text-align: center;
            }

            table.row-col-tb tr {
                border: 1px solid #dee2e663;
            }
            .row-col-tb tr td:first-child {
                font-weight: 550;
                font-size: 15px;
            }
            table.main-row-tb.single tr td:first-child {
                font-weight: 600;
            }
            d-flex.flex-wrap.align-items-center {
                border: 1px solid #eaecec;
                border-radius: 11px;
            }

            .card {
                border-radius: 10px;
                width: 100%;
                padding: unset;
                height: auto;
            }

            .card-header {
                position: relative;
                display: flex;
                -webkit-box-orient: vertical;
                -webkit-box-direction: normal;
                flex-direction: column;
                min-width: 0;
                word-wrap: break-word;
                background-color: #f8f9fa;
                background-clip: border-box;
                border-bottom: 1px solid #e9ecef;
            }
            .card-header:first-child{
                border: 1px solid rgb(0 0 0 / 3%);
                border-radius: 0 0 20px 20px;
                border-bottom: 1px solid #e9ecef;
            }
            .card-body {
                width: 100%;
            }
        </style>
    </head>
    <body class="antialiased">

        @include('layouts.header')

        <style>
            .card {
                border-radius: 10px;
            }
            .card-header {
                background-color: #f8f9fa;
                padding: 1rem;
                border-bottom: 1px solid #e3e7eb;
                width: 100%;
            }
            .col {
                width: 20%;
                max-width: 10%;
            }
        </style>
        <div class="main-container">
            <div class="row row-cols-1 row-cols-md-3 g-4">
                <div class="col">
                  <div class="card">
                    <h5 class="card-title my-2">Categories</h5>
                    <div class="card-header">
                      <h5 class="card-title">All Data</h5>
                    </div>
                    <div class="card-body">
                      <ul>
                        <li><strong>Total: </strong>{{$datas['cat']}}</li>
                        <li><strong>Live: </strong>{{$datas['cat_live']}}</li>
                        <li><strong>UnLive: </strong>{{$datas['cat_unlive']}}</li>
                      </ul>
                    </div>
                    <div class="card-header">
                        <h5 class="card-title">User Data</h5>
                      </div>
                      <div class="card-body">
                        <ul>
                            <li><strong>Total: </strong>{{$datas['user_cat']}}</li>
                            <li><strong>Live: </strong>{{$datas['user_cat_live']}}</li>
                            <li><strong>UnLive: </strong>{{$datas['user_cat_unlive']}}</li>
                          </ul>
                      </div>
                  </div>
                </div>
                <div class="col">
                    <div class="card">
                      <h5 class="card-title my-2">Templates</h5>
                      <div class="card-header">
                        <h5 class="card-title">All Data</h5>
                      </div>
                      <div class="card-body">
                        <ul>
                          <li><strong>Total: </strong>{{$datas['all_item']}}</li>
                          <li><strong>Live: </strong>{{$datas['all_item_live']}}</li>
                          <li><strong>UnLive: </strong>{{$datas['all_item_unlive']}}</li>
                        </ul>
                      </div>
                      <div class="card-header">
                          <h5 class="card-title">User Data</h5>
                        </div>
                        <div class="card-body">
                          <ul>
                              <li><strong>Total: </strong>{{$datas['item']}}</li>
                              <li><strong>Live: </strong>{{$datas['item_live']}}</li>
                              <li><strong>UnLive: </strong>{{$datas['item_unlive']}}</li>
                            </ul>
                        </div>
                    </div>
                  </div>
            </div>


        </div>

        <script src="{{asset('assets/vendors/scripts/core.js')}}"></script>
        <script src="{{asset('assets/vendors/scripts/script.min.js')}}"></script>

        <script>
            $('#dynamic_form').on('submit', function (event) {
                event.preventDefault();
                count = 0;
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                    }
                });

                var formData = new FormData(this);
                $.ajax({
                    url: 'update_cache_ver',
                    type: 'POST',
                    data: formData,
                    beforeSend: function () {
                        var loading_screen = document.getElementById("loading_screen");
                        loading_screen.style.display = "block";
                    },
                    success: function (data) {
                        hideFields();
                        if (data.error) {
                            var error_html = '';
                            for (var count = 0; count < data.error.length; count++) {
                                error_html += '<p>' + data.error[count] + '</p>';
                            }
                            $('#result').html('<div class="alert alert-danger">' + error_html + '</div>');
                        } else {
                            $('#result').html('<div class="alert alert-success">' + data.success + '</div>');
                        }
                        setTimeout(function () {
                            $('#result').html('');
                        }, 3000);
                    },
                    error: function (error) {
                        hideFields();
                        window.alert(error.responseText);
                    },
                    cache: false,
                    contentType: false,
                    processData: false
                })
            });

            function hideFields() {
                var loading_screen = document.getElementById("loading_screen");
                loading_screen.style.display = "none";

            }

        </script>
    </body>
</html>
