<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>Laravel</title>

    <link rel="stylesheet" type="text/css" href="{{ asset('assets/vendors/styles/core.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/vendors/styles/icon-font.min.css') }}">
    <link rel="stylesheet" type="text/css"
        href="{{ asset('assets/plugins/datatables/css/dataTables.bootstrap4.min.css') }}">
    <link rel="stylesheet" type="text/css"
        href="{{ asset('assets/plugins/datatables/css/responsive.bootstrap4.min.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/vendors/styles/style.css') }}">
    <link rel="stylesheet" href="//code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css">
    <link rel="stylesheet" type="text/css"
        href="{{ asset('assets/plugins/bootstrap-tagsinput/bootstrap-tagsinput.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/vendors/styles/loader.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/plugins/switchery/switchery.min.css') }}">

</head>
<style>
    .bootstrap-tagsinput {
        width: 465px !important;
    }

    .bootstrap-tagsinput .tag {
        display: inline-block;
        transition: all 0.2s ease-in-out;
        margin: 2px;
        padding: 5px 10px;
        border-radius: 5px;
        background-color: #007bff;
        color: white;
    }

    /* Highlighting the tag when dragging */
    .bootstrap-tagsinput .tag.sorting {
        box-shadow: 0 0 10px rgba(0, 123, 255, 0.5);
        /* transform: scale(1.1); */
    }

    #relatedKeyword .bootstrap-tagsinput.ui-sortable,
    #newKeywordsCols .bootstrap-tagsinput.ui-sortable {
        width: 100%;
    }

    .select2-selection {
        box-shadow: 0 0 10px rgba(0, 123, 255, 0.5);
        display: grid !important;
        padding: 10px !important;
    }

    .select2-selection__choice {
        /* display: inline-block; */
        transition: all 0.2s ease-in-out;
        margin: 2px;
        padding: 5px 10px;
        border-radius: 5px;
        background-color: #007bff;
        color: white;
    }

    .custom-modal-width {
        max-width: 700px !important;
        width: 100% !important;
    }
</style>

<body class="antialiased">
    @include('layouts.header')

    <div class="main-container">
        <div class="pd-ltr-20 xs-pd-20-10">
            <div class="min-height-200px">
                <div class="card-box mb-30">
                    <div class="row justify-content-between pb-30 pt-30">
                        <!-- Left: Add Button -->
                        <div class="col-md-3">
                            <a href="#" class="btn btn-primary ml-4 mt-4" data-toggle="modal"
                                data-target="#add_promocode" id="openAddModal">
                                Add Promo
                            </a>
                        </div>

                        <!-- Right: Filter Form -->
                        <div class="col-md-9">
                            @include('partials.filter_form', [
                                'action' => route('promocode.index'),
                            ])
                        </div>
                    </div>

                    {{-- <div class="col-sm-12 table-responsive"> --}}
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Id</th>
                                <th>Promo Code</th>
                                <th>Discount</th>
                                <th>Status</th>
                                <th>Expiry Date</th>
                                <th>Discount Upto</th>
                                <th>Minimum Purchase</th>
                                <th class="datatable-nosort">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($promoCodes as $promoCode)
                                <tr style="background-color: #efefef;">
                                    <td>{{ $promoCode->id }}</td>
                                    <td>{{ $promoCode->promo_code }}</td>
                                    <td>{{ $promoCode->disc }}%</td>
                                    <td>
                                        @if ($promoCode->status == 1)
                                            <span class="badge badge-success">Active</span>
                                        @else
                                            <span class="badge badge-danger">Inactive</span>
                                        @endif
                                    </td>
                                    <td>{{ $promoCode->expiry_date }}</td>
                                    <td>₹{{ $promoCode->disc_upto_inr }} /
                                        ${{ $promoCode->disc_upto_usd }}</td>
                                    <td>₹{{ $promoCode->min_cart_inr }} /
                                        ${{ $promoCode->min_cart_usd }}</td>
                                    <td>
                                        <button class="dropdown-item edit-btn" data-id="{{ $promoCode->id }}">
                                            <i class="dw dw-edit2"></i> Edit
                                        </button>
                                        <button class="dropdown-item delete-btn" data-id="{{ $promoCode->id }}">
                                            <i class="dw dw-delete-3"></i> Delete
                                        </button>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                    {{-- </div> --}}
                    @include('partials.pagination', ['items' => $promoCodes])
                </div>
            </div>
        </div>
    </div>

    {{-- @include('color.create'); --}}
    <div class="modal fade" id="add_promocode" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-dialog-centered custom-modal-width">
            <div class="modal-content">
                <form id="addForm">
                    @csrf
                    <input type="hidden" name="id" id="promo_id">
                    <div class="modal-header">
                        <h5 class="modal-title">Add / Edit Promo Code</h5>
                        <button type="button" class="close" onclick="closeModal()" data-dismiss="modal">×</button>
                    </div>
                    <div class="modal-body">
                        <!-- Promo Code -->
                        <div class="form-group">
                            <label>Promo Code</label>
                            <input type="text" class="form-control" name="promo_code" id="promo_code" required>
                        </div>

                        <div class="form-group">
                            <label>Select User</label>
                            <select id="user_id" name="user_id[]" class="form-control border" multiple="multiple"></select>
                        </div>


                        <div class="form-group">
                            <label>Type</label>
                            <select class="form-control" name="type" id="type">.
                                <option value="0" selected>Both</option>
                                <option value="1">Individual</option>
                                <option value="2">Subscription</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label>Discount</label>
                            <input type="number" class="form-control" name="disc" id="disc" required>
                        </div>

                        <div class="form-group">
                            <label>Status</label>
                            <select class="form-control" name="status" id="status">
                                <option value="1">Active</option>
                                <option value="2">Inactive</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label>Expiry Date</label>
                            <input type="date" class="form-control" name="expiry_date" id="expiry_date">
                        </div>

                        <div class="row">
                            <div class="col-6">
                                <label>Discount Upto INR</label>
                                <input type="number" min="0" class="form-control" name="disc_upto_inr"
                                    id="disc_upto_inr">
                            </div>
                            <div class="col-6">
                                <label>Minimum Purchase INR</label>
                                <input type="number" min="0" class="form-control" name="min_cart_inr"
                                    id="min_cart_inr">
                            </div>
                            <div class="col-6">
                                <label>Discount Upto USD</label>
                                <input type="number" min="0" class="form-control" name="disc_upto_usd"
                                    id="disc_upto_usd">
                            </div>
                            <div class="col-6">
                                <label>Minimum Purchase USD</label>
                                <input type="number" min="0" class="form-control" name="min_cart_usd"
                                    id="min_cart_usd">
                            </div>
                        </div>
                    </div>

                    <div class="modal-footer">
                        <div id="result" class="mr-auto"></div>
                        <button type="submit" class="btn btn-primary" id="btnSubmitForm">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <script src="{{ asset('assets/vendors/scripts/core.js') }}"></script>
    <script src="{{ asset('assets/vendors/scripts/script.min.js') }}"></script>
    <script src="{{ asset('assets/plugins/bootstrap-tagsinput/bootstrap-tagsinput.js') }}"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

    <script>
        let promoCodes = @json($promoCodes);

        $(document).ready(function() {
            $('#user_id').select2({
                placeholder: 'Search email...',
                width: '100%',
                minimumInputLength: 1,
                ajax: {
                    url: "{{ route('get_users_by_email') }}",
                    dataType: 'json',
                    delay: 250,
                    data: function(params) {
                        return {
                            q: params.term
                        };
                    },
                    processResults: function(data) {
                        return {
                            results: data
                        };
                    },
                    cache: true
                }
            });


            // Open modal with cleared form
            $('#openAddModal').click(function() {
                $('#addForm')[0].reset();
                $('#promo_id').val('');
                $('#user_id').empty().val(null).trigger('change');
            });

            $('.edit-btn').click(function() {
                const data = $(this).data();
                const promo = promoCodes.data.find(p => p.id === data.id);
                if (!promo) return alert("Promo code not found");
                $('#promo_id').val(promo.id);
                $('#promo_code').val(promo.promo_code);
                $('#type').val(promo.type);
                $('#disc').val(promo.disc);
                $('#status').val(promo.status);
                $('#expiry_date').val(promo.expiry_date);
                $('#disc_upto_inr').val(promo.disc_upto_inr);
                $('#min_cart_inr').val(promo.min_cart_inr);
                $('#disc_upto_usd').val(promo.disc_upto_usd);
                $('#min_cart_usd').val(promo.min_cart_usd);
                const userData = JSON.parse(promo.user_id);
                $('#user_id').empty().val(null).trigger('change');
                if (Array.isArray(userData) && userData.length > 0) {
                    $.ajax({
                        url: "{{ route('get_users_by_ids') }}",
                        method: "GET",
                        data: {
                            user_ids: userData
                        },
                        success: function(response) {
                            if (Array.isArray(response) && response.length > 0) {
                                response.forEach(user => {
                                    const option = new Option(
                                        `${user.id} - ${user.email}`, user.uid, true,
                                        true);
                                    $('#user_id').append(option);
                                });
                                $('#user_id').val(userData).trigger('change');
                            }
                        },
                        error: function(xhr, status, error) {}
                    });
                }
                $('#add_promocode').modal('show');
            });

            $('#addForm').on('submit', function(e) {
                e.preventDefault();
                const formData = new FormData(this);
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });

                $.ajax({
                    url: "{{ route('promocode.store') }}",
                    method: 'POST',
                    data: formData,
                    contentType: false,
                    processData: false,
                    beforeSend: () => {
                        $('#result').html('<div class="text-info">Processing...</div>');
                    },
                    success: (res) => {
                        $('#result').html('');
                        if (res.error) {
                            $('#result').html('<div class="text-danger">' + res.error +
                                '</div>');
                        } else if (res.success) {
                            $('#result').html('<div class="text-success">' + res.success +
                                '</div>');
                            setTimeout(() => location.reload(), 1000);
                        }
                    },
                    error: (xhr) => {
                        $('#result').html('');
                        alert('Something went wrong: ' + xhr.responseText);
                    }
                });
            });

        });

        $(document).on("click", ".delete-btn", function() {
            var id = $(this).data("id");

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                }
            });
            var url = "{{ route('promocode.destroy', ':id') }}".replace(":id", id);
            if (confirm("Are you sure you want to delete this review?")){
            $.ajax({
                url: url,
                type: 'DELETE',
                beforeSend: function() {
                    $("#loading_screen").show();
                },
                success: function(response) {
                    $("#loading_screen").hide();
                    location.reload();
                },
                error: function(xhr) {
                    $("#loading_screen").hide();
                    alert("Error: " + xhr.responseText);
                }
            });}
        });

    </script>
</body>

</html>
