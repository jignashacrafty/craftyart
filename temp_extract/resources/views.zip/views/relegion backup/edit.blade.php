@inject('helperController', 'App\Http\Controllers\HelperController')
<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>Laravel</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap"
          rel="stylesheet">

    <link rel="stylesheet" type="text/css"
          href="{{asset('assets/plugins/bootstrap-tagsinput/bootstrap-tagsinput.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('assets/vendors/styles/core.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('assets/vendors/styles/icon-font.min.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('assets/vendors/styles/style.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('assets/vendors/styles/loader.css')}}">

</head>
<body class="antialiased">

@include('layouts.header')

<div class="main-container">

    <div id="loading_screen" style="display: none;">
        <div id="loader-wrapper">
            <div id="loader"></div>
            <div class="loader-section section-left"></div>
            <div class="loader-section section-right"></div>
        </div>
    </div>

    <div class="pd-ltr-20 xs-pd-20-10">
        <div class="min-height-200px">

            <div class="page-header">
                <div class="row">
                    <div class="col-md-6 col-sm-12">
                        <div class="title">
                            Size Thumb
                        </div>
                    </div>
                </div>
            </div>

            <div class="pd-20 card-box mb-30">
                <form method="PUT" action="{{route('sizes.update',$size->id)}}" id="editSizeForm">
                    @csrf
                    <span id="result"></span>

                    <div class="row">
                        <div class="col-md-3 col-sm-12">
                            <div class="form-group">
                                <h6>Size Name</h6>
                                <input id="sizeName" class="form-control-file form-control" name="size_name" value="{{$size->size_name}}" required>
                            </div>
                        </div>

                        <div class="col-md-3 col-sm-12">
                            <div class="form-group">
                                <h6>ID Name</h6>
                                <input id="idName" class="form-control-file form-control" name="id_name" value="{{$size->id_name}}" required>
                            </div>
                        </div>

                        <div class="col-md-3 col-sm-12">
                            <div class="form-group">
                                <h6>Width Ration</h6>
                                <input class="form-control" id="widthRation" type="text" name="width_ration" required="" value="{{$size->width_ration}}" step="any">

                            </div>
                        </div>

                        <div class="col-md-2 col-sm-12">
                            <div class="form-group">
                                <h6>Height Ration</h6>
                                <input class="form-control" id="heightRation" type="text" name="height_ration" required="" value="{{$size->height_ration}}" step="any">
                            </div>
                        </div>
                        <div class="col-md-2 col-sm-12">
                            <div class="form-group">
                                <h6>Units</h6>
                                <select class="form-control" name="unit" id="unitInput">
                                    <option value="px" {{ $size->unit == "px" ? 'selected' : '' }}>PX</option>
                                    <option value="inch" {{ $size->unit == "inch" ? 'selected' : '' }}>Inch</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div>
                        <input type="hidden" name="id" value="{{$size->id}}">
                        <input class="btn btn-primary" type="submit" name="submit">
                    </div>
                </form>
            </div>
        </div>
    </div>

</div>
<script src="{{asset('assets/vendors/scripts/core.js')}}"></script>
<script src="{{asset('assets/vendors/scripts/script.min.js')}}"></script>
<script src="{{asset('assets/vendors/scripts/advanced-components.js')}}"></script>
<script src="{{asset('assets/plugins/bootstrap-tagsinput/bootstrap-tagsinput.js')}}"></script>
<script>

    $('.bg_type_id').change(function () {
        if ($(this).val() === '0' || $(this).val() === '1') {
            $('.back_image').attr('required', '');
            var x = document.getElementById("back_image_field");
            x.style.display = "block";

            $('.color_code').removeAttr('required');
            var x1 = document.getElementById("color_code_field");
            x1.style.display = "none";

        } else {
            $('.color_code').attr('required', '');
            var x = document.getElementById("color_code_field");
            x.style.display = "block";

            $('.back_image').removeAttr('required');
            var x1 = document.getElementById("back_image_field");
            x1.style.display = "none";

        }
    });


    $('#editSizeForm').on('submit', function (event) {
        event.preventDefault();
        count = 0;
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
            }
        });

        var formData = new FormData(this);
        let id = $("input[name='id']").val();
        var url = "{{ route('sizes.update', ['size' => ':id']) }}".replace(':id', id);

        $.ajax({
            url: url,
            type: 'PUT',
            dataType: 'json',
            data: {
                "size_name":$("#sizeName").val(),
                "id_name":$("#idName").val(),
                "width_ration":$("#widthRation").val(),
                "height_ration":$("#heightRation").val(),
                "unit":$("#unitInput").val(),
                "id":$("input[name='id']").val(),
            },
            beforeSend: function () {
                var loading_screen = document.getElementById("loading_screen");
                loading_screen.style.display = "block";
            },
            success: function (data) {
                if (data.error) {
                    $('#result').html('<div class="alert alert-danger">' + data.error + '</div>');
                } else {
                    $('#result').html('<div class="alert alert-success">' + data.success + '</div>');
                }
                 hideFields();
                setTimeout(function () {
                    $('#result').html('');
                }, 3000);

            },
            error: function (error) {

                hideFields();
                window.alert(error.responseText);
            }
        })
    });

    $(document).on('click', '#remove_bg_info', function () {
        $(this).closest(".row").remove();
    });

    $(document).on('click', '#add_text_info', function () {
        dynamic_text_field();
    });

    $(document).on('click', '#remove_text_info', function () {
        $(this).closest(".row").remove();
    });

    $(document).on('click', '#add_component_info', function () {
        dynamic_component_field();
    });

    $(document).on('click', '#remove_component_info', function () {
        $(this).closest(".row").remove();
    });

    function hideFields() {
        // $('#editSizeForm')[0].reset();
        var loading_screen = document.getElementById("loading_screen");
        loading_screen.style.display = "none";
    }

</script>

</body>
</html>
