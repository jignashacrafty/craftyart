@inject('helperController', 'App\Http\Controllers\HelperController')
<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="{{ csrf_token() }}">
        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

        <link rel="stylesheet" type="text/css" href="{{asset('assets/vendors/styles/core.css')}}">
        <link rel="stylesheet" type="text/css" href="{{asset('assets/vendors/styles/icon-font.min.css')}}">
        <link rel="stylesheet" type="text/css" href="{{asset('assets/plugins/datatables/css/dataTables.bootstrap4.min.css')}}">
        <link rel="stylesheet" type="text/css" href="{{asset('assets/plugins/datatables/css/responsive.bootstrap4.min.css')}}">
        <link rel="stylesheet" type="text/css" href="{{asset('assets/vendors/styles/style.css')}}">
        <link rel="stylesheet" type="text/css" href="{{asset('assets/vendors/styles/loader.css')}}">
        <link rel="stylesheet" type="text/css" href="{{asset('assets/plugins/switchery/switchery.min.css')}}">
    </head>
    <body class="antialiased">

        @include('layouts.header')

        <div class="main-container">
            <div id="loading_screen" style="display: none;">
                <div id="loader-wrapper">
                    <div id="loader"></div>
                    <div class="loader-section section-left"></div>
                    <div class="loader-section section-right"></div>
                </div>
            </div>
            <div class="pd-ltr-20 xs-pd-20-10">
                <div class="min-height-200px">
                    <div class="card-box mb-30">
                        <div class="pb-20">
                            <span id="result"></span>
                            <div id="DataTables_Table_0_wrapper" class="dataTables_wrapper dt-bootstrap4 no-footer">

                                <div class="row">
                                    <div class="col-sm-12 col-md-3">
                                        <div class="pd-20">
                                            <a href="#" class="btn btn-primary" data-backdrop="static" data-toggle="modal" data-target="#add_relegion_model" type="button">
                                                Add Relegion </a>
                                        </div>
                                    </div>

                                    @php
                                        $isAdmin = Auth::user()->user_type;
                                    @endphp
                                    <input class="d-none" type="text" id="isAdmin" value="{{$isAdmin}}">


                                    <div class="col-sm-12 col-md-9">
                                        <div class="col-sm-12">
                                            <div class="pt-20">
                                                <form action="{{ route('religions.index') }}" method="GET">
                                                    <div class="form-group">
                                                        <div id="DataTables_Table_0_filter" class="dataTables_filter">
                                                            <label>Search:<input type="text" class="form-control" name="query" placeholder="Search here....." value="{{ request()->input('query') }}"></label> <button type="submit" class="btn btn-primary">Search</button>
                                                        </div>
                                                    </div>
                                                </form>

                                            </div>
                                        </div>
                                     </div>

                                <form id="create_relegion_action" action="{{route('religions.create')}}" method="GET" style="display: none;">
                                    <input type="text" id="passingAppId" name="passingAppId">
                                       @csrf
                                </form>

                                <div class="col-sm-12 table-responsive">
                                    <table id="relegion_table" class="table table-striped">
                                        <thead>
                                            <tr>
                                                <th>Id</th>
                                                <th>Relegion</th>
                                                <th>User</th>
                                                <th>Status</th>
                                                <th class="datatable-nosort">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody id="relegion_table">
                                            @foreach ($religions as $religion)
                                            <tr style="background-color: #efefef;">
                                                <td class="table-plus">{{$religion->id}}</td>
                                                <td class="table-plus">{{$religion->religion_name}}</td>
                                                <td class="table-plus">{{ \App\Http\Controllers\HelperController::getUploaderName($religion->emp_id) }}</td>
                                                <td class="table-plus">{{ ($religion->status) ? "Active" : "UnActive" }}</td>
                                                <td>
                                                    <Button class="dropdown-item btn-edit" data-id="{{$religion->id}}" data-status="{{$religion->status}}" data-religion="{{$religion->religion_name}}" data-id-name="{{$religion->id_name}}" data-backdrop="static" data-toggle="modal" data-target="#edit_religions_model" ><i class="dw dw-edit2"></i> Edit</Button>
                                                    @if ( $helperController::getUserType(Auth::user()->user_type) == "Admin" || $helperController::getUserType(Auth::user()->user_type) == "Manager" )
                                                        <button class="dropdown-item" onclick="delete_click('{{$religion->id}}')"><i class="dw dw-delete-3" ></i> Delete</button>
                                                    @endif
                                                </td>
                                            </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>

                                <div class="row">
                                    <div class="col-sm-12 col-md-5">
                                        <div class="dataTables_info" id="DataTables_Table_0_info" role="status" aria-live="polite"></div>
                                    </div>
                                    <div class="col-sm-12 col-md-7">
                                        <div class="dataTables_paginate paging_simple_numbers" id="DataTables_Table_0_paginate">
                                            <ul class="pagination">
                                                {{ $religions->appends(request()->input())->links('pagination::bootstrap-4') }}
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div
            class="modal fade"
            id="delete_model"
            tabindex="-1"
            role="dialog"
            aria-labelledby="myLargeModalLabel"
            aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <input type="text" id="delete_id" name="delete_id" style="display: none;">
                    <div class="modal-header">
                        <h4 class="modal-title" id="myLargeModalLabel">Delete</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    </div>
                    <div class="modal-body">
                        <p> Are you sure you want to delete? </p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">No, Cancel</button>
                        <button type="button" class="btn btn-primary" onclick="delete_click()">Yes, Delete</button>
                    </div>
                </div>
            </div>
        </div>

        {{-- @include('color.create'); --}}
        <div class="modal fade" id="add_relegion_model" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="false">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="myLargeModalLabel">Add Relegion</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    </div>
                    <div class="modal-body">
                        <form method="post" id="addReligionForm">
                            @csrf
                            <div class="form-group">
                                <h7>Religon</h7>
                                <div class="input-group custom">
                                    <input type="text" class="form-control" placeholder="Enter Religon" id="religionName" name="religion_name" required="" />
                                </div>
                            </div>
                            <div class="form-group">
                                <h7>ID Name</h7>
                                <div class="input-group custom">
                                    <input type="text" class="form-control" placeholder="Enter ID Name" id="religionIDName" name="id_name" required="" />
                                </div>
                            </div>
                            <div class="form-group">
                                <h6>Status</h6>
                                <select id="status" class="selectpicker form-control" data-style="btn-outline-primary" name="status">
                                    <option value="1">Active</option>
                                    <option value="0">Disable</option>
                                </select>
                            </div>
                            <div class="row">
                                <div class="col-sm-12">
                                    <input class="btn btn-primary btn-block" id="btnSubmitForm" type="button" name="submit" value="Submit">
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <div
            class="modal fade"
            id="edit_religions_model"
            tabindex="-1"
            role="dialog"
            aria-labelledby="myLargeModalLabel"
            aria-hidden="false">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                   <div class="modal-header">
                        <h5 class="modal-title" id="myLargeModalLabel">Edit Religion</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    </div>

                    <div class="modal-body" id="update_model">
                    </div>

                </div>
            </div>
        </div>

        <script src="{{asset('assets/vendors/scripts/core.js')}}"></script>
        <script src="{{asset('assets/vendors/scripts/script.min.js')}}"></script>
        <script src="{{asset('assets/vendors/scripts/process.js')}}"></script>
        <script src="{{asset('assets/vendors/scripts/layout-settings.js')}}"></script>
        <script src="{{asset('assets/plugins/datatables/js/jquery.dataTables.min.js')}}"></script>
        <script src="{{asset('assets/plugins/datatables/js/dataTables.bootstrap4.min.js')}}"></script>
        <script src="{{asset('assets/plugins/datatables/js/dataTables.responsive.min.js')}}"></script>
        <script src="{{asset('assets/plugins/datatables/js/responsive.bootstrap4.min.js')}}"></script>
        <script src="{{asset('assets/plugins/switchery/switchery.min.js')}}"></script>
        <script src="{{asset('assets/vendors/scripts/advanced-components.js')}}"></script>
        <script src="https://unpkg.com/xlsx/dist/xlsx.full.min.js"></script>

        <script>
            $(document).ready(function(){
                $(document).on("click","#update_click",function(){
                    count = 0;
                    $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                        }
                    });
                    let id = $("input[name='religion_id']").val();
                    var url = "{{ route('religions.update', ['religion' => ':id']) }}".replace(':id', id);
                    $.ajax({
                        url: url,
                        type: 'PUT',
                        dataType: 'json',
                        data: {
                            "religion_name" : $("input[name='edit_religion_name']").val(),
                            "id_name" : $("input[name='edit_id_name']").val(),
                            "status" : $("#editStatus").val(),
                        },
                        beforeSend: function () {
                            var loading_screen = document.getElementById("loading_screen");
                            loading_screen.style.display = "block";
                        },
                        success: function (data) {
                            if (data.error) {
                                $('#result').html('<div class="alert alert-danger">' + data.error + '</div>');
                            } else {
                                $('#result').html('<div class="alert alert-success">' + data.success + '</div>');
                                $("#edit_religions_model").removeClass("show");
                                $("#edit_religions_model").hide();
                                $(".modal-backdrop.fade.show").remove();
                                location.reload();
                            }
                            hideFields();
                            setTimeout(function () {
                                $('#result').html('');
                            }, 3000);

                        },
                        error: function (error) {
                            hideFields();
                            window.alert(error.responseText);
                        }
                    });

                });

                $(document).on("click","#btnSubmitForm",function(){
                    count = 0;
                    $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                        }
                    });

                    $.ajax({
                        url: "{{route('religions.store')}}",
                        type: 'POST',
                        dataType: 'json',
                        data: {
                            "religion_name" : $("input[name='religion_name']").val(),
                            "id_name" : $("input[name='id_name']").val(),
                            "status" : $("#status").val(),
                        },
                        beforeSend: function () {
                            var loading_screen = document.getElementById("loading_screen");
                            loading_screen.style.display = "block";
                        },
                        success: function (data) {
                            if (data.error) {
                                $('#result').html('<div class="alert alert-danger">' + data.error + '</div>');
                            } else {
                                $('#result').html('<div class="alert alert-success">' + data.success + '</div>');
                                $("#add_relegion_model").removeClass("show");
                                $("#add_relegion_model").hide();
                                $(".modal-backdrop.fade.show").remove();
                                location.reload();
                            }
                            hideFields();
                            setTimeout(function () {
                                $('#result').html('');
                            }, 3000);

                        },
                        error: function (error) {
                            hideFields();
                            window.alert(error.responseText);
                        }
                    });

                });

                function hideFields() {
                    $('#addReligionForm')[0].reset();
                    var loading_screen = document.getElementById("loading_screen");
                    loading_screen.style.display = "none";
                }
            })

            function notification_click($id) {
                $("#temp_id").val($id);
            }

            function reset_click($id) {
                $("#reset_temp_id").val($id);
            }

            function reset_creation($id) {
                $("#reset_creation_id").val($id);
            }
            $(document).on("click",".btn-edit",function(){
                let id = $(this).data('id');
                let religion = $(this).data('religion');
                let idName = $(this).data('id-name');
                let status = $(this).data('status');

                let selectActive = status == "1" ? 'selected=selected' : '';
                let selectUnActive = status == "0" ? 'selected=selected' : '';

                $("#update_model").empty();
                html = `<form method="post" id="edit_religions_form">
                            @csrf
                            <input class="form-control" type="textname" name="religion_id" value="${id}" style="display: none"/>
                            <div class="form-group">
                                <h7>Religion Name</h7>
                                <div class="input-group custom">
                                    <input type="text" class="form-control" placeholder="Enter Religion" id="editReligionName" value="${religion}" name="edit_religion_name" required="" />
                                </div>
                            </div>
                            <div class="form-group">
                                <h7>ID Name</h7>
                                <div class="input-group custom">
                                    <input type="text" class="form-control" placeholder="ID Name" id="editIdName" value="${idName}" name="edit_id_name" required="" />
                                </div>
                            </div>
                            <div class="form-group">
                                    <h6>Status</h6>
                                    <select id="editStatus" class="selectpicker form-control" data-style="btn-outline-primary">
                                        <option value="1" ${selectActive}>Active</option>
                                        <option value="0" ${selectUnActive}>Disable</option>
                                    </select>
                                </div>
                            <div class="row">
                                <div class="col-sm-12">
                                    <button type="button" class="btn btn-primary btn-block" id="update_click">Update</button>
                                </div>
                            </div>
                        </form>`;

                 $("#update_model").append(html);
            })
            
            function set_delete_id($id) {
                $("#delete_id").val($id);
            }

            function delete_click(id) {

                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                    }
                });

                var url ="{{route('religions.destroy', ":id")}}";
                url = url.replace(":id", id);

                $.ajax({
                    url: url,
                    type: 'DELETE',
                    beforeSend: function () {
                        // $('#delete_model').modal('toggle');
                        var loading_screen = document.getElementById("loading_screen");
                        loading_screen.style.display = "block";
                    },
                    success: function (data) {
                        var loading_screen = document.getElementById("loading_screen");
                        loading_screen.style.display = "none";
                        if (data.error) {
                            window.alert('error==>'+data.error);
                        } else {
                            location.reload();
                        }
                    },
                    error: function (error) {
                        var loading_screen = document.getElementById("loading_screen");
                        loading_screen.style.display = "none";
                        window.alert(error.responseText);
                    },
                    cache: false,
                    contentType: false,
                    processData: false
                })
            }


            const toTitleCase = str => str.replace(/\b\w+/g, txt => txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase());
            $(document).on("keypress","#religionName", function() {
                const titleString = toTitleCase($(this).val());
                $("#religionIDName").val(`${titleString.toLowerCase().replace(/\s+/g, '-')}`);
                $(this).val(titleString);
            });

            $(document).on("keypress","#editReligionName", function() {
                const titleString = toTitleCase($(this).val());
                $("#editIdName").val(`${titleString.toLowerCase().replace(/\s+/g, '-')}`);
                $(this).val(titleString);
            });
        </script>
    </body>
</html>
