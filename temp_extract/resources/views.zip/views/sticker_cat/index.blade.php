
@inject('roleManager', 'App\Http\Controllers\Utils\RoleManager')

<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>Laravel</title>
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

    <link rel="stylesheet" type="text/css" href="{{ asset('assets/vendors/styles/core.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/vendors/styles/icon-font.min.css') }}">
    <link rel="stylesheet" type="text/css"
        href="{{ asset('assets/plugins/datatables/css/dataTables.bootstrap4.min.css') }}">
    <link rel="stylesheet" type="text/css"
        href="{{ asset('assets/plugins/datatables/css/responsive.bootstrap4.min.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/vendors/styles/style.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/vendors/styles/custom.css') }}">
    <style>
        .sort-arrow {
            margin-left: 0px;
        }

        .sort-arrow.active {
            color: #1739d1ec;
        }

        .sort-arrow {
            font-family: 'dropways';
            font-size: 14px;
            color: grey;
        }

        .sort-asc::before {
            content: "\eabb";
        }

        .sort-desc::before {
            content: "\eaba";
        }

        .sort-asc.active::before,
        .sort-desc.active::before {
            color: #1b00ff;
        }

        span.sort-arrow.sort-desc {
            margin-left: -7px;
        }

        .form-row input.form-control {
            width: 297px;
        }

        .pd-20.f-left {
            float: left;
        }

        .form-row.f-right {
            padding: 20px;
            float: right;
        }

        .row ul.pagination {
            margin-bottom: 10px;
            float: right;
            margin-right: 20px;
        }
    </style>
</head>

<body class="antialiased">
    @include('layouts.header')
    <div class="main-container designer-access-container">
        <div class="pd-ltr-20 xs-pd-20-10">
            <div class="min-height-200px">
                <div class="card-box mb-30">
                    <div class="row justify-content-between pb-30 pt-30">
                        <div class="col-md-3">
                            @if ($roleManager::onlyDesignerAccess(Auth::user()->user_type))
                            <button type="button" class="btn btn-primary ml-4 mt-4" id="addNewStickerCatBtn">
                                + Add Sticker Category
                            </button>
                            @endif
                        </div>
                        <div class="col-md-9">
                            @include('partials.filter_form', [
                                'action' => route('show_sticker_cat.index'),
                            ])
                        </div>
                    </div>
                    <table id="shap_category_table" class="table table-striped">
                        <thead>
                            <tr>
                                <th>Id</th>
                                <th>User</th>
                                <th>Name</th>
                                <th class="datatable-nosort">Category Thumb</th>
                                <th>Sequence Number</th>
                                <th>Status</th>
                                <th class="datatable-nosort">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($stickerCatArray as $stickerCat)
                                <tr>
                                    <td class="table-plus">{{ $stickerCat->id }}</td>
                                    <td>{{ $roleManager::getUploaderName($stickerCat->emp_id) }}
                                    <td>{{ $stickerCat->stk_category_name }}</td>
                                    <td><img src="{{ \App\Http\Controllers\Utils\ContentManager::getStorageLink($stickerCat->stk_category_thumb)}}"
                                            style="max-width: 100px; max-height: 100px; width: auto; height: auto" />
                                    </td>
                                    <td>{{ $stickerCat->sequence_number }}</td>
                                    @if ($stickerCat->status == '1')
                                        <td>LIVE</td>
                                    @else
                                        <td>NOT LIVE</td>
                                    @endif

                                    <td>
                                        <button class="dropdown-item edit-sticker-category-btn"
                                            data-id="{{ $stickerCat->id }}">
                                            <i class="dw dw-edit2"></i> Edit
                                        </button>
                                        @if ($roleManager::isAdminOrDesignerManager(Auth::user()->user_type))
                                            <button type="button" class="dropdown-item"
                                                    id="delete-sticker-cat"
                                                data-id="{{ $stickerCat->id }}">
                                            <i class="dw dw-delete-3"></i> Delete
                                        </button>
                                        @endif
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                    @include('partials.pagination', ['items' => $stickerCatArray])
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade designer-access-container" id="add_sticker_category_model" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" style="max-width: 676px;">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add/Edit Sticker Category</h5>
                    <button type="button" class="close" data-dismiss="modal">×</button>
                </div>

                <div class="modal-body">
                    <form method="POST" id="sticker_cate_form" enctype="multipart/form-data">
                        <input type="hidden" name="id" id="sticker_category_id">

                        <div class="form-group">
                            <h6>Sticker Category Name</h6>
                            <input class="form-control" type="text" id="stk_category_name" name="stk_category_name"
                                required>
                        </div>

                        <div class="form-group">
                            <h6>Sticker Category Thumb</h6>
                            <input type="file" class="form-control-file form-control dynamic-file"
                                id="stkCategoryThumb" data-accept=".jpg, .jpeg, .webp, .svg" accept="image/*"
                                data-imgstore-id="stk_category_thumb" data-nameset="true">
                        </div>

                        <div class="form-group">
                            <h6>Sequence Number</h6>
                            <input class="form-control" type="text" id="sequence_number" name="sequence_number"
                                required>
                        </div>

                        <div class="form-group">
                            <h6>Status</h6>
                            <select class="form-control" id="status" name="status">
                                <option value="1">LIVE</option>
                                <option value="0">NOT LIVE</option>
                            </select>
                        </div>

                        <div class="text-right">
                            <button type="submit" class="btn btn-primary" id="sticker_form_submit">Submit</button>
                        </div>
                    </form>
                </div>
                <meta name="csrf-token" content="{{ csrf_token() }}">
            </div>
        </div>
    </div>

    <script>
        const STORAGE_URL = "{{ env('STORAGE_URL') }}";
        // *Debug
        const storageUrl = "{{ config('filesystems.storage_url') }}";
    </script>
    <script src="{{ asset('assets/vendors/scripts/core.js') }}"></script>
    <script src="{{ asset('assets/vendors/scripts/script.min.js') }}"></script>
    <script src="{{ asset('assets/vendors/scripts/process.js') }}"></script>
    <script src="{{ asset('assets/vendors/scripts/layout-settings.js') }}"></script>
    <script src="{{ asset('assets/js/dynamicfile.js') }}"></script>
    <script src="{{ asset('assets/js/role_access.js') }}"></script>

    <script>
        $(document).ready(function() {
            $('#addNewStickerCatBtn').on('click', function() {
                resetStickerCategoryForm();
                $('#add_sticker_category_model').modal('show');
            });

            $(document).on('click', '.edit-sticker-category-btn', function() {
                const id = $(this).data('id');

                $.get(`{{ url('show_sticker_cat') }}/${id}/edit`, function(data) {
                    $('#add_sticker_category_model').modal('show');

                    $('#sticker_category_id').val(data.id);
                    $('#stk_category_name').val(data.stk_category_name);
                    $('#sequence_number').val(data.sequence_number);
                    $('#status').val(data.status);

                    const imageUrl = getStorageLink(data.stk_category_thumb)
                    $('#stkCategoryThumb').attr('data-value', imageUrl);
                    dynamicFileCmp();
                    $('#result').html('');

                });
            });

            $('#sticker_cate_form').on('submit', function(e) {
                e.preventDefault();

                const formElement = $('#sticker_cate_form')[0];
                const formData = new FormData(formElement);

                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });

                $.ajax({
                    url: `{{ route('show_sticker_cat.store') }}`,
                    type: 'POST',
                    data: formData,
                    contentType: false,
                    processData: false,
                    success: function(data) {
                        if (data.status) {
                            location.reload();
                        } else {
                            alert(data.error);
                        }
                    },
                    error: function(xhr) {
                        alert(xhr.responseText);
                    }
                });
            });

            $(document).on('click', '#delete-sticker-cat', function() {
                event.preventDefault();
                const id = $(this).data('id');
                // alert(id);
                if (!confirm('Are you sure you want to delete this sticker category?')) return;
                $.ajax({
                    url: "{{ route('show_sticker_cat.destroy', ':id') }}".replace(":id", id),
                    type: 'POST',
                    data: {
                        _method: 'DELETE',
                        _token: '{{ csrf_token() }}'
                    },
                    success: function(response) {
                        location.reload(); // or dynamically remove the row from the table
                    },
                    error: function(xhr) {
                        alert('Something went wrong. Try again.');
                        console.error(xhr.responseText);
                    }
                });
            });


            function resetStickerCategoryForm() {
                $('#sticker_cate_form')[0].reset();
                $('#sticker_category_id').val('');
                resetDynamicFileValue("stkCategoryThumb")
            }
        });

    </script>
</body>

</html>
