<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Laravel</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

    <link rel="stylesheet" type="text/css" href="{{asset('assets/vendors/styles/core.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('assets/vendors/styles/icon-font.min.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('assets/vendors/styles/style.css')}}">

</head>

<body class="antialiased">

    @include('layouts.header')

    <div class="main-container">
        <div id="loading_screen" style="display: none;">
            <div id="loader-wrapper">
                <div id="loader"></div>
                <div class="loader-section section-left"></div>
                <div class="loader-section section-right"></div>
            </div>
        </div>
        <div class="pd-ltr-20 xs-pd-20-10">
            <div class="min-height-200px">
                <div class="pd-20 card-box mb-30">
                    <form method="post" id="dynamic_form" enctype="multipart/form-data">

                        <span id="result"></span>

                        @csrf
                        <div class="form-group">
                            <h6>Category Name</h6>
                            <input class="form-control" type="textname" name="stk_category_name"
                                value="{{$stickerCatData->stk_category_name}}" required>
                        </div>

                        <div class="form-group">
                            <h6>Category Thumb</h6>
                            <input type="file" class="form-control-file form-control height-auto"
                                name="stk_category_thumb"><br />
                            <img src="{{ config('filesystems.storage_url') }}{{$stickerCatData->stk_category_thumb}}"
                                width="100" />
                            <input class="form-control" type="textname" id="cat_thumb_path" name="stk_cat_thumb_path"
                                value="{{$stickerCatData->stk_category_thumb}}" style="display: none">
                        </div>

                        <div class="form-group">
                            <h6>Sequence Number</h6>
                            <input class="form-control" type="textname" name="sequence_number"
                                value="{{$stickerCatData->sequence_number}}" required>
                        </div>
                        <div class="form-group">
                            <h6>Status</h6>
                            <div class="col-sm-20">
                                <select class="selectpicker form-control" data-style="btn-outline-primary"
                                    name="status">
                                    @if($stickerCatData->status == '1')
                                        <option value="1" selected>LIVE</option>
                                        <option value="0">NOT LIVE</option>
                                    @else
                                        <option value="1">LIVE</option>
                                        <option value="0" selected>NOT LIVE</option>
                                    @endif
                                </select>
                            </div>
                        </div>
                        <div>
                            <input class="btn btn-primary" type="submit" name="submit">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script src="{{asset('assets/vendors/scripts/core.js')}}"></script>
    <script src="{{asset('assets/vendors/scripts/script.min.js')}}"></script>

    <script>
        $('#dynamic_form').on('submit', function (event) {
            event.preventDefault();


            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                }
            });

            var formData = new FormData(this);

            var url = "{{route('sticker_cat.update', [$stickerCatData->id])}}";

            $.ajax({
                url: url,
                type: 'POST',
                data: formData,
                beforeSend: function () {
                    var loading_screen = document.getElementById("loading_screen");
                    loading_screen.style.display = "block";

                },
                success: function (data) {

                    hideFields();
                    if (data.error) {
                        window.alert(data.error);
                        $('#result').html('<div class="alert alert-danger">' + data.error + '</div>');
                    } else {
                        window.location.replace("../show_sticker_cat");
                    }

                    setTimeout(function () {
                        $('#result').html('');
                    }, 3000);

                },
                error: function (error) {
                    hideFields();
                    window.alert(error.responseText);
                },
                cache: false,
                contentType: false,
                processData: false
            })
        });

        function hideFields() {
            var loading_screen = document.getElementById("loading_screen");
            loading_screen.style.display = "none";
        }

    </script>

</body>


</html>