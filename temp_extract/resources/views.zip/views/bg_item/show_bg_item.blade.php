@inject('roleManager', 'App\Http\Controllers\Utils\RoleManager')
@inject('helperController', 'App\Http\Controllers\HelperController')
<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>Laravel</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

    <link rel="stylesheet" type="text/css" href="{{asset('assets/vendors/styles/core.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('assets/vendors/styles/icon-font.min.css')}}">
    <link rel="stylesheet" type="text/css"
        href="{{asset('assets/plugins/datatables/css/dataTables.bootstrap4.min.css')}}">
    <link rel="stylesheet" type="text/css"
        href="{{asset('assets/plugins/datatables/css/responsive.bootstrap4.min.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('assets/vendors/styles/style.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('assets/vendors/styles/loader.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('assets/plugins/switchery/switchery.min.css')}}">
</head>

<body class="antialiased">

    @include('layouts.header')

    <div class="main-container">
        <div id="loading_screen" style="display: none;">
            <div id="loader-wrapper">
                <div id="loader"></div>
                <div class="loader-section section-left"></div>
                <div class="loader-section section-right"></div>
            </div>
        </div>
        <div class="pd-ltr-20 xs-pd-20-10">
            <div class="min-height-200px">
                <div class="card-box mb-30">
                    <div class="pb-20">

                        <div id="DataTables_Table_0_wrapper" class="dataTables_wrapper dt-bootstrap4 no-footer">

                            <div class="row">
                                <div class="col-sm-12 col-md-3">
                                    <div class="pd-20">
                                        <a class="btn btn-primary" href="create_bg_item" role="button"> Add New
                                            Background </a>
                                    </div>
                                </div>

                                <div class="col-sm-12 col-md-9">
                                    <div class="pt-20">
                                        <form action="{{ route('show_bg_item') }}" method="GET">
                                            <div class="form-group">
                                                <div id="DataTables_Table_0_filter" class="dataTables_filter">
                                                    <label>Search:<input type="text" class="form-control" name="query"
                                                            placeholder="Search here....."
                                                            value="{{ request()->input('query') }}"></label> <button
                                                        type="submit" class="btn btn-primary">Search</button>
                                                </div>
                                            </div>
                                        </form>

                                    </div>
                                </div>
                            </div>

                            <div class="col-sm-12 table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Background Id</th>
                                            <th>User</th>
                                            <th>Cateogry Name</th>
                                            <th>Background Name</th>
                                            <th class="datatable-nosort">Background Image</th>
                                            <th>Is Premium</th>
                                            <th>Status</th>
                                            <th class="datatable-nosort">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach ($bgArray['bg'] as $bg)
                                            <tr style="background-color: #efefef;">
                                                <td class="table-plus">{{$bg->id}}</td>
                                                <td>{{ $roleManager::getUploaderName($bg->emp_id) }}
                                                </td>
                                                <td>{{ $helperController::getBgCatName($bg->bg_cat_id) }}</td>
                                                <td>{{$bg->bg_name}}</td>
                                                <td><img src="{{ config('filesystems.storage_url') }}{{$bg->bg_thumb}}"
                                                        style="max-width: 100px; max-height: 100px; width: auto; height: auto" />
                                                </td>

                                                @if($bg->is_premium == '1')
                                                    <td><label id="premium_label_{{$bg->id}}"
                                                            style="display: none;">TRUE</label><Button style="border: none"
                                                            onclick="premium_click('{{$bg->id}}')"><input type="checkbox"
                                                                checked class="switch-btn" data-size="small"
                                                                data-color="#0059b2" /></Button></td>
                                                @else
                                                    <td><label id="premium_label_{{$bg->id}}"
                                                            style="display: none;">FALSE</label><Button style="border: none"
                                                            onclick="premium_click('{{$bg->id}}')"><input type="checkbox"
                                                                class="switch-btn" data-size="small"
                                                                data-color="#0059b2" /></Button></td>
                                                @endif

                                                @if($bg->status == '1')
                                                    <td><label id="status_label_{{$bg->id}}"
                                                            style="display: none;">Live</label><Button style="border: none"
                                                            onclick="status_click('{{$bg->id}}')"><input type="checkbox" checked
                                                                class="switch-btn" data-size="small"
                                                                data-color="#0059b2" /></Button></td>
                                                @else
                                                    <td><label id="status_label_{{$bg->id}}" style="display: none;">Not
                                                            Live</label><Button style="border: none"
                                                            onclick="status_click('{{$bg->id}}')"><input type="checkbox"
                                                                class="switch-btn" data-size="small"
                                                                data-color="#0059b2" /></Button></td>
                                                @endif

                                                <td>
                                                    <a class="dropdown-item" href="edit_bg_item/{{$bg->id}}"><i
                                                            class="dw dw-edit2"></i> Edit</a>


                                                    @if ($roleManager::isAdminOrSeoManager(Auth::user()->user_type))
                                                        <a class="dropdown-item" href="delete_bg_item/{{$bg->id}}"><i
                                                                class="dw dw-delete-3"></i> Delete</a>
                                                    @endif
                                                </td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>

                            <div class="row">
                                <div class="col-sm-12 col-md-5">
                                    <div class="dataTables_info" id="DataTables_Table_0_info" role="status"
                                        aria-live="polite">{{ $bgArray['count_str'] }}</div>
                                </div>
                                <div class="col-sm-12 col-md-7">
                                    <div class="dataTables_paginate paging_simple_numbers"
                                        id="DataTables_Table_0_paginate">
                                        <ul class="pagination">
                                            {{ $bgArray['bg']->appends(request()->input())->links('pagination::bootstrap-4') }}
                                        </ul>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="{{asset('assets/vendors/scripts/core.js')}}"></script>
    <script src="{{asset('assets/vendors/scripts/script.min.js')}}"></script>
    <script src="{{asset('assets/vendors/scripts/process.js')}}"></script>
    <script src="{{asset('assets/vendors/scripts/layout-settings.js')}}"></script>
    <script src="{{asset('assets/plugins/datatables/js/jquery.dataTables.min.js')}}"></script>
    <script src="{{asset('assets/plugins/datatables/js/dataTables.bootstrap4.min.js')}}"></script>
    <script src="{{asset('assets/plugins/datatables/js/dataTables.responsive.min.js')}}"></script>
    <script src="{{asset('assets/plugins/datatables/js/responsive.bootstrap4.min.js')}}"></script>
    <script src="{{asset('assets/vendors/scripts/datatable-setting.js')}}"></script>
    <script src="{{asset('assets/plugins/switchery/switchery.min.js')}}"></script>
    <script src="{{asset('assets/vendors/scripts/advanced-components.js')}}"></script>

    <script>

        function premium_click($id) {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                }
            });

            var status = $id;

            var url = "{{route('bg.premium', ":status")}}";
            url = url.replace(":status", status);

            var formData = new FormData();
            formData.append('id', $id);


            $.ajax({
                url: url,
                type: 'POST',
                data: formData,
                beforeSend: function () {
                    var loading_screen = document.getElementById("loading_screen");
                    loading_screen.style.display = "block";
                },
                success: function (data) {
                    var loading_screen = document.getElementById("loading_screen");
                    loading_screen.style.display = "none";
                    if (data.error) {
                        window.alert(data.error);
                    } else {
                        var x = document.getElementById("premium_label_" + $id);
                        if (x.innerHTML === "TRUE") {
                            x.innerHTML = "FALSE";
                        } else {
                            x.innerHTML = "TRUE";
                        }
                    }

                },
                error: function (error) {
                    var loading_screen = document.getElementById("loading_screen");
                    loading_screen.style.display = "none";
                    window.alert(error.responseText);
                },
                cache: false,
                contentType: false,
                processData: false
            })
        }

        function status_click($id) {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                }
            });

            var status = $id;


            var url = "{{route('bg.status', ":status")}}";
            url = url.replace(":status", status);

            var formData = new FormData();
            formData.append('id', $id);


            $.ajax({
                url: url,
                type: 'POST',
                data: formData,
                beforeSend: function () {
                    var loading_screen = document.getElementById("loading_screen");
                    loading_screen.style.display = "block";
                },
                success: function (data) {
                    var loading_screen = document.getElementById("loading_screen");
                    loading_screen.style.display = "none";
                    if (data.error) {
                        window.alert(data.error);
                    } else {
                        var x = document.getElementById("status_label_" + $id);
                        if (x.innerHTML === "Live") {
                            x.innerHTML = "Not Live";
                        } else {
                            x.innerHTML = "Live";
                        }
                    }
                },
                error: function (error) {
                    var loading_screen = document.getElementById("loading_screen");
                    loading_screen.style.display = "none";
                    window.alert(error.responseText);
                },
                cache: false,
                contentType: false,
                processData: false
            })
        }
    </script>
</body>

</html>