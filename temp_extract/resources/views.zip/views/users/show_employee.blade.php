@inject('roleManager', 'App\Http\Controllers\Utils\RoleManager')
<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}"/>

    <title>Laravel</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

    <link rel="stylesheet" type="text/css" href="{{asset('assets/vendors/styles/core.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('assets/vendors/styles/icon-font.min.css')}}">
    <link rel="stylesheet" type="text/css"
          href="{{asset('assets/plugins/datatables/css/dataTables.bootstrap4.min.css')}}">
    <link rel="stylesheet" type="text/css"
          href="{{asset('assets/plugins/datatables/css/responsive.bootstrap4.min.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('assets/vendors/styles/style.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('assets/vendors/styles/loader.css')}}">

</head>
<body class="antialiased">

@include('layouts.header')

<div class="main-container">

    <div id="loading_screen" style="display: none;">
        <div id="loader-wrapper">
            <div id="loader"></div>
            <div class="loader-section section-left"></div>
            <div class="loader-section section-right"></div>
        </div>
    </div>

    <div class="pd-ltr-20 xs-pd-20-10">
        <div class="min-height-200px">
            <div class="card-box mb-30">
                <div class="pb-20">

                    <div class="pd-20">

                        <a href="#" class="btn btn-primary" data-backdrop="static" data-toggle="modal"
                           data-target="#add_employee_model" type="button">
                            Add Employee </a>
                    </div>

                    <div id="DataTables_Table_0_wrapper" class="dataTables_wrapper dt-bootstrap4 no-footer">

                        <div class="row">
                            <div class="col-sm-12">
                                <table class="data-table table stripe hover nowrap">
                                    <thead>
                                    <tr>
                                        <th>Index</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Employee Type</th>
                                        <th>Status</th>
                                        <th class="datatable-nosort">Action</th>
                                    </tr>
                                    </thead>
                                    <tbody>

                                    @foreach ($employeeArray as $user)
                                    <tr>
                                        <td>{{$user->id}}</td>

                                        <td>{{$user->name}}</td>

                                        <td>{{$user->email}}</td>

                                        <td>{{$roleManager::getUserType($user->user_type)}}</td>

                                        @if($user->status == 1)
                                        <td>Enabled</td>
                                        @else
                                        <td>Disabled</td>
                                        @endif

                                        <td>
                                            <div class="dropdown">
                                                <a class="btn btn-link font-24 p-0 line-height-1 no-arrow dropdown-toggle"
                                                   href="#" role="button" data-toggle="dropdown">
                                                    <i class="dw dw-more"></i>
                                                </a>
                                                <div class="dropdown-menu dropdown-menu-right dropdown-menu-icon-list">

                                                    <Button class="dropdown-item"
                                                            onclick="edit_click('{{$user->id}}', '{{$user->name}}', '{{$user->email}}', '{{$user->user_type}}')"
                                                            data-backdrop="static" data-toggle="modal"
                                                            data-target="#edit_employee_model"><i
                                                                class="dw dw-edit2"></i>Edit
                                                    </Button>

                                                    <Button class="dropdown-item" onclick="reset_click('{{$user->id}}')"
                                                            data-backdrop="static" data-toggle="modal"
                                                            data-target="#reset_pass_model"><i
                                                                class="icon-copy dw dw-refresh"></i>Reset Password
                                                    </Button>

                                                    @if($user->status == 1)
                                                    <Button class="dropdown-item"
                                                            onclick="delete_click('{{$user->id}}')"><i
                                                                class="dw dw-delete-3"></i> Disable
                                                    </Button>
                                                    @else
                                                    <Button class="dropdown-item"
                                                            onclick="delete_click('{{$user->id}}')"><i
                                                                class="dw dw-delete-3"></i> Enable
                                                    </Button>
                                                    @endif

                                                </div>
                                            </div>
                                        </td>

                                    </tr>
                                    @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div
        class="modal fade"
        id="add_employee_model"
        tabindex="-1"
        role="dialog"
        aria-labelledby="myLargeModalLabel"
        aria-hidden="false">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="myLargeModalLabel">Add Employee</h5>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            </div>

            <div class="modal-body">
                <form method="post" id="add_employee_form" enctype="multipart/form-data">
                    @csrf
                    <div class="form-group">
                        <h7>Name</h7>
                        <div class="input-group custom">
                            <input type="text" class="form-control" placeholder="Name" name="name" required=""/>
                        </div>
                    </div>

                    <div class="form-group">
                        <h7>Email</h7>
                        <div class="input-group custom">
                            <input type="text" class="form-control" placeholder="Email" name="email" required=""/>
                        </div>
                    </div>

                    <div class="form-group">
                        <h7>Passowrd</h7>
                        <div class="input-group custom">
                            <input type="text" class="form-control" placeholder="Password" name="password" required=""/>
                        </div>
                    </div>

                    <div class="form-group">
                        <h6>Type</h6>
                        <div class="col-sm-20">
                            <select id="emplyee_type" class="selectpicker form-control"
                                    data-style="btn-outline-primary"
                                    name="emplyee_type">
                                @foreach($roles as $role)
                                    @if($role['id'] != 1)
                                        <option value="{{ $role['id'] }}">{{ $role['role']->value }}</option>
                                    @endif
                                @endforeach
                            </select>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-sm-12">
                            <input class="btn btn-primary btn-block" type="submit" name="submit">
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<div
        class="modal fade"
        id="reset_pass_model"
        tabindex="-1"
        role="dialog"
        aria-labelledby="myLargeModalLabel"
        aria-hidden="false">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="myLargeModalLabel">Reset Password</h5>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            </div>

            <div class="modal-body">
                <form method="post" id="reset_pass_form" enctype="multipart/form-data">
                    @csrf

                    <input type="text" class="form-control" id="password_id" name="password_id" required=""
                           style="display: none"/>

                    <div class="form-group">
                        <h7>New Passowrd</h7>
                        <div class="input-group custom">
                            <input type="text" class="form-control" id="new_password" placeholder="Passowrd"
                                   name="new_password" required=""/>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-sm-12">
                            <button type="button" class="btn btn-primary btn-block" id="reset_btn">Reset</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<div
        class="modal fade"
        id="edit_employee_model"
        tabindex="-1"
        role="dialog"
        aria-labelledby="myLargeModalLabel"
        aria-hidden="false">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="myLargeModalLabel">Edit Employee</h5>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            </div>

            <div class="modal-body" id="update_model">
            </div>

        </div>
    </div>
</div>

<script src="{{asset('assets/vendors/scripts/core.js')}}"></script>
<script src="{{asset('assets/vendors/scripts/script.min.js')}}"></script>
<script src="{{asset('assets/vendors/scripts/process.js')}}"></script>
<script src="{{asset('assets/vendors/scripts/layout-settings.js')}}"></script>
<script src="{{asset('assets/plugins/datatables/js/jquery.dataTables.min.js')}}"></script>
<script src="{{asset('assets/plugins/datatables/js/dataTables.bootstrap4.min.js')}}"></script>
<script src="{{asset('assets/plugins/datatables/js/dataTables.responsive.min.js')}}"></script>
<script src="{{asset('assets/plugins/datatables/js/responsive.bootstrap4.min.js')}}"></script>
<!-- Datatable Setting js -->
<script src="{{asset('assets/vendors/scripts/new-datatable-setting.js')}}"></script>
<script>
    const roles = @json($roles);
</script>
<script>

    function edit_click(id, name, email, employee_type) {
        $("#update_model").empty();
        let optionsHtml = "";
        roles.forEach(role => {
            if (role.id != 1) { // skip Admin
                const selected = role.id == employee_type ? "selected" : "";
                optionsHtml += `<option value="${role.id}" ${selected}>${role.role}</option>`;
            }
        });
        const html = `
            <form method="post" id="edit_employee_form" enctype="multipart/form-data">
              <input type="hidden" name="_token" value="${$('meta[name="csrf-token"]').attr('content')}">
              <input type="hidden" name="id" value="${id}" />
              <div class="form-group">
                <label>Name</label>
                <input type="text" class="form-control" name="name" value="${name}" required />
              </div>
              <div class="form-group">
                <label>Email</label>
                <input type="text" class="form-control" name="email" value="${email}" required />
              </div>
              <div class="form-group">
                <label>Type</label>
                <select id="emplyee_type_edit" class="form-control" name="emplyee_type">
                  ${optionsHtml}
                </select>
              </div>
              <div class="form-group" id="group_leader_div_edit" style="display: none;">
                <label>Group Leader</label>
                <select id="group_leader_edit" class="form-control" name="group_leader">
                </select>
              </div>
              <button type="button" class="btn btn-primary btn-block" id="update_click">Update</button>
            </form>
            `;


        $("#update_model").append(html);
    }

    function reset_click($id) {
        $("#password_id").val($id);
    }

    $('#add_employee_form').on('submit', function (event) {
        event.preventDefault();

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
            }
        });

        var formData = new FormData(this);

        $.ajax({
            url: 'create_employee',
            type: 'POST',
            data: formData,
            beforeSend: function () {
                var loading_screen = document.getElementById("loading_screen");
                loading_screen.style.display = "block";
            },
            success: function (data) {
                var loading_screen = document.getElementById("loading_screen");
                loading_screen.style.display = "none";
                if (data.error) {
                    window.alert('error==>' + data.error);
                } else {
                    location.reload();
                }

            },
            error: function (error) {
                var loading_screen = document.getElementById("loading_screen");
                loading_screen.style.display = "none";
                window.alert(error.responseText);
            },
            cache: false,
            contentType: false,
            processData: false
        })
    });

    $(document).on('click', '#update_click', function () {
        event.preventDefault();

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
            }
        });

        var formElement = document.getElementById("edit_employee_form");
        var formData = new FormData(formElement);
        var status = formData.get("employee_id");
        var url = "{{route('employee.update', "
    :
        status
        ")}}";
        url = url.replace(":status", status);

        $.ajax({
            url: url,
            type: 'POST',
            data: formData,
            beforeSend: function () {
                var loading_screen = document.getElementById("loading_screen");
                loading_screen.style.display = "block";
            },
            success: function (data) {
                var loading_screen = document.getElementById("loading_screen");
                loading_screen.style.display = "none";
                if (data.error) {
                    window.alert(data.error);
                } else {
                    location.reload();
                }

            },
            error: function (error) {
                var loading_screen = document.getElementById("loading_screen");
                loading_screen.style.display = "none";
                window.alert(error.responseText);
            },
            cache: false,
            contentType: false,
            processData: false
        })
    });

    $(document).on('click', '#reset_btn', function () {
        event.preventDefault();

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
            }
        });

        var formData = new FormData(document.getElementById("reset_pass_form"));
        var status = formData.get("password_id");
        console.log(status)

        var url = "{{route('employee.reset', ":status")}}";
        url = url.replace(":status", status);
        $.ajax({
            url: url,
            type: 'POST',
            data: formData,
            beforeSend: function () {
                var loading_screen = document.getElementById("loading_screen");
                loading_screen.style.display = "block";
            },
            success: function (data) {
                var loading_screen = document.getElementById("loading_screen");
                loading_screen.style.display = "none";
                if (data.error) {
                    window.alert(data.error);
                } else {
                    location.reload();
                }

            },
            error: function (error) {
                var loading_screen = document.getElementById("loading_screen");
                loading_screen.style.display = "none";
                window.alert(error.responseText);
            },
            cache: false,
            contentType: false,
            processData: false
        })
    });

    function delete_click(id) {

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
            }
        });

        var url = "{{route('employee.delete', "
    :
        id
        ")}}";
        url = url.replace(":id", id);

        $.ajax({
            url: url,
            type: 'POST',
            beforeSend: function () {
                var loading_screen = document.getElementById("loading_screen");
                loading_screen.style.display = "block";
            },
            success: function (data) {
                var loading_screen = document.getElementById("loading_screen");
                loading_screen.style.display = "none";
                if (data.error) {
                    window.alert('error==>' + data.error);
                } else {
                    location.reload();
                }
            },
            error: function (error) {
                var loading_screen = document.getElementById("loading_screen");
                loading_screen.style.display = "none";
                window.alert(error.responseText);
            },
            cache: false,
            contentType: false,
            processData: false
        })
    }

</script>
</body>
</html>