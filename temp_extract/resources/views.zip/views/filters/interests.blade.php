@inject('helperController', 'App\Http\Controllers\HelperController')
@inject('roleManager', 'App\Http\Controllers\Utils\RoleManager')

<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}" />

    <title>Laravel</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

    <link rel="stylesheet" type="text/css" href="{{ asset('assets/vendors/styles/core.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/vendors/styles/icon-font.min.css') }}">
    <link rel="stylesheet" type="text/css"
        href="{{ asset('assets/plugins/datatables/css/dataTables.bootstrap4.min.css') }}">
    <link rel="stylesheet" type="text/css"
        href="{{ asset('assets/plugins/datatables/css/responsive.bootstrap4.min.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/vendors/styles/style.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/vendors/styles/custom.css') }}">
</head>

<body class="antialiased">

    @include('layouts.header')

    <div class="main-container seo-all-container">
        <div id="loading_screen" style="display: none;">
            <div id="loader-wrapper">
                <div id="loader"></div>
                <div class="loader-section section-left"></div>
                <div class="loader-section section-right"></div>
            </div>
        </div>

        <div class="pd-ltr-20 xs-pd-20-10">
            <div class="min-height-200px">
                <div class="card-box mb-30">
                    <div class="pb-20">

                        <!-- Trigger Button -->
                        <div class="pd-20">
                            @if ($roleManager::onlySeoAccess(Auth::user()->user_type))
                                <a href="#" class="btn btn-primary" onclick="openAddModal()">Add Interest</a>
                            @endif
                        </div>

                        <table class="data-table table stripe hover nowrap">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Name</th>
                                    <th>New Category</th>
                                    <th>Status</th>
                                    <th>User</th>
                                    <th class="datatable-nosort">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($interestArray as $interest)
                                    @php
                                        $newCategoryIds =
                                            isset($interest->new_category_id) && $interest->new_category_id != null
                                                ? json_decode($interest->new_category_id, true)
                                                : [];
                                        if (!is_array($newCategoryIds)) {
                                            $newCategoryIds = [$newCategoryIds];
                                        }
                                    @endphp
                                    <tr>
                                        <td class="table-plus">{{ $interest->id }}</td>
                                        <td class="table-plus">{{ $interest->name }}</td>
                                        <td class="table-plus">
                                            {{ $helperController::getNewCatNames($newCategoryIds, true) }}
                                        </td>

                                        @if ($interest->status == '1')
                                            <td>Active</td>
                                        @else
                                            <td>Disabled</td>
                                        @endif
                                        <td>{{ $roleManager::getUploaderName($interest->emp_id) }}
                                        </td>
                                        <td>
                                            <button class="dropdown-item"
                                                onclick="edit_click(
    '{{ $interest->id }}',
    '{{ addslashes($interest->name) }}',
    '{{ $interest->status }}',
    '{{ addslashes($interest->id_name) }}',
    '{{ json_encode(json_decode($interest->new_category_id, true)) }}'
)">
                                                Edit
                                            </button>


                                            @if ($roleManager::isAdminOrSeoManager(Auth::user()->user_type))
                                                <Button class="dropdown-item"
                                                    onclick="delete_click('{{ $interest->id }}')"><i
                                                        class="dw dw-delete-3"></i> Delete</Button>
                                            @endif
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade seo-all-container" id="interest_modal" tabindex="-1" role="dialog"
        aria-labelledby="interest_modal_title" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">

                <div class="modal-header">
                    <h5 class="modal-title" id="interest_modal_title">Add Interest</h5>
                    <button type="button" class="close" data-dismiss="modal">×</button>
                </div>

                <div class="modal-body">
                    <form id="add_interest_form" method="POST" enctype="multipart/form-data">
                        @csrf
                        <input type="hidden" name="id" id="interest_id" />

                        <div class="form-group">
                            <label>Name</label>
                            <input type="text" class="form-control" placeholder="Interest" id="interestName"
                                name="name" required />
                        </div>

                        <div class="form-group">
                            <label>ID Name</label>
                            <input type="text" class="form-control" placeholder="ID Name" id="interestIDName"
                                name="id_name" required />
                        </div>

                        <div class="form-group">
                            <h7>New Category</h7>
                            <div class="col-sm-20" id="newCategory">
                                <select class="custom-select2 form-control" multiple="multiple"
                                    name="new_category_ids[]" id="newEditCategoryIds" required>
                                    @foreach ($allNewCategories as $newCategory)
                                        <option value="{{ $newCategory->id }}">{{ $newCategory->category_name }}
                                        </option>
                                    @endforeach
                                </select>
                            </div>
                        </div>

                        <div class="form-group">
                            <label>Status</label>
                            <select id="status" class="form-control" name="status">
                                <option value="1">Active</option>
                                <option value="0">Disable</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <button type="submit" id="interest_submit_btn"
                                class="btn btn-primary btn-block">Save</button>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>

    <script src="{{ asset('assets/vendors/scripts/core.js') }}"></script>
    <script src="{{ asset('assets/vendors/scripts/script.min.js') }}"></script>
    <script src="{{ asset('assets/vendors/scripts/process.js') }}"></script>
    <script src="{{ asset('assets/vendors/scripts/layout-settings.js') }}"></script>
    <script src="{{ asset('assets/js/role_access.js') }}"></script>
    <script src="{{ asset('assets/plugins/datatables/js/jquery.dataTables.min.js') }}"></script>
    <script src="{{ asset('assets/plugins/datatables/js/dataTables.bootstrap4.min.js') }}"></script>
    <script src="{{ asset('assets/plugins/datatables/js/dataTables.responsive.min.js') }}"></script>
    <script src="{{ asset('assets/plugins/datatables/js/responsive.bootstrap4.min.js') }}"></script>
    <!-- Datatable Setting js -->
    <script src="{{ asset('assets/vendors/scripts/datatable-setting.js') }}"></script>

    <script>
        $(document).ready(function() {
            $('#newEditCategoryIds').select2({
                width: '100%',
                placeholder: "Select Categories",
                allowClear: true
            });
        });

        // Open Add Modal
        function openAddModal() {
            $('#interest_modal_title').text("Add Interest");
            $('#interest_submit_btn').text("Save");

            $('#interest_id').val('');
            $('#interestName').val('');
            $('#interestIDName').val('');
            $('#status').val('1');
            $('#newEditCategoryIds').val([]).trigger('change');

            $('#interest_modal').modal('show');
        }

        // Open Edit Modal
        function edit_click(id, name, status, idName, newCategoryIdJson) {
            $('#interest_modal_title').text("Edit Interest");
            $('#interest_submit_btn').text("Update");

            $('#interest_id').val(id);
            $('#interestName').val(name);
            $('#interestIDName').val(idName);
            $('#status').val(status);

            let categoryIds = [];
            try {
                categoryIds = JSON.parse(newCategoryIdJson) || [];
                categoryIds = categoryIds.map(String);
            } catch (e) {
                categoryIds = [];
            }

            $('#newEditCategoryIds').val(categoryIds).trigger('change');
            $('#interest_modal').modal('show');
        }

        // Submit Form
        $('#add_interest_form').on('submit', function(event) {
            event.preventDefault();

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                }
            });

            const formData = new FormData(this);

            $.ajax({
                url: '{{ url('interest_store_or_update') }}',
                type: 'POST',
                data: formData,
                beforeSend: function() {
                    $("#loading_screen").show();
                },
                success: function(response) {
                    $("#loading_screen").hide();
                    if (response.error) {
                        alert('Error: ' + response.error);
                    } else {
                        alert(response.success || "Saved successfully.");
                        location.reload();
                    }
                },
                error: function(error) {
                    $("#loading_screen").hide();
                    alert("Something went wrong:\n" + error.responseText);
                },
                cache: false,
                contentType: false,
                processData: false
            });
        });

        // Reset on close
        $('#interest_modal').on('hidden.bs.modal', function() {
            $('#add_interest_form')[0].reset();
            $('#newEditCategoryIds').val([]).trigger('change');
            $('#interest_id').val('');
        });

        // Auto-generate ID name
        const toTitleCase = str => str.replace(/\b\w+/g, txt => txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase());

        $(document).on("input", "#interestName", function() {
            const titleString = toTitleCase($(this).val());
            $("#interestIDName").val(titleString.toLowerCase().replace(/\s+/g, '-'));
            $(this).val(titleString);
        });


        function delete_click(id) {

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                }
            });

            var url = "{{ route('interest.delete', ':id') }}";
            url = url.replace(":id", id);

            $.ajax({
                url: url,
                type: 'POST',
                beforeSend: function() {
                    var loading_screen = document.getElementById("loading_screen");
                    loading_screen.style.display = "block";
                },
                success: function(data) {
                    var loading_screen = document.getElementById("loading_screen");
                    loading_screen.style.display = "none";
                    if (data.error) {
                        window.alert(data.error);
                    } else {
                        location.reload();
                    }
                },
                error: function(error) {
                    var loading_screen = document.getElementById("loading_screen");
                    loading_screen.style.display = "none";
                    window.alert(error.responseText);
                },
                cache: false,
                contentType: false,
                processData: false
            })
        }
    </script>

</body>

</html>
