@inject('roleManager', 'App\Http\Controllers\Utils\RoleManager')

<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}" />

    <title>Laravel</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

    <link rel="stylesheet" type="text/css" href="{{ asset('assets/vendors/styles/core.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/vendors/styles/icon-font.min.css') }}">
    <link rel="stylesheet" type="text/css"
        href="{{ asset('assets/plugins/datatables/css/dataTables.bootstrap4.min.css') }}">
    <link rel="stylesheet" type="text/css"
        href="{{ asset('assets/plugins/datatables/css/responsive.bootstrap4.min.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/vendors/styles/style.css') }}">
</head>

<body class="antialiased">

    @include('layouts.header')

    <div class="main-container seo-all-container ">
        <div id="loading_screen" style="display: none;">
            <div id="loader-wrapper">
                <div id="loader"></div>
                <div class="loader-section section-left"></div>
                <div class="loader-section section-right"></div>
            </div>
        </div>

        <div class="pd-ltr-20 xs-pd-20-10">
            <div class="min-height-200px">
                <div class="card-box mb-30">
                    <div class="pb-20">

                        <div class="pd-20">
                            @if ($roleManager::onlySeoAccess(Auth::user()->user_type))
                                <a href="javascript:void(0)" class="btn btn-primary"
                                    onclick="openSearchTagModal('add')">
                                    Add Search Tag
                                </a>
                            @endif
                        </div>

                        <table class="data-table table stripe hover nowrap">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>User</th>
                                    <th>Name</th>
                                    <th>Status</th>
                                    <th class="datatable-nosort">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($searchTagArray as $searchTag)
                                    <tr>
                                        <td class="table-plus">{{ $searchTag->id }}</td>

                                        <td>{{ \$roleManager::getUploaderName($searchTag->emp_id) }}
                                        </td>
                                        <td class="table-plus">{{ $searchTag->name }}</td>

                                        @if ($searchTag->status == '1')
                                            <td>Active</td>
                                        @else
                                            <td>Disabled</td>
                                        @endif
                                        <td>
                                            <button class="dropdown-item"
                                                onclick="openSearchTagModal('edit', {
        id: '{{ $searchTag->id }}',
        name: '{{ $searchTag->name }}',
        status: '{{ $searchTag->status }}'
    })">
                                                <i class="dw dw-edit2"></i> Edit
                                            </button>

                                            @if ($roleManager::isAdminOrSeoManager(Auth::user()->user_type))
                                                <Button class="dropdown-item"
                                                    onclick="delete_click('{{ $searchTag->id }}')"><i
                                                        class="dw dw-delete-3"></i> Delete</Button>
                                            @endif
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade seo-all-container" id="add_search_tag_model" tabindex="-1"
        role="dialog" aria-hidden="false">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="search_tag_modal_title">Add Search Tag</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                </div>

                <div class="modal-body">
                    <form method="post" id="search_tag_form" enctype="multipart/form-data">
                        @csrf
                        <input type="hidden" name="search_tag_id" id="search_tag_id" />

                        <div class="form-group">
                            <h7>Name</h7>
                            <input type="text" class="form-control" placeholder="Search Tag" id="searchTagName"
                                name="name" required />
                        </div>

                        <div class="form-group">
                            <h6>Status</h6>
                            <select id="searchTagStatus" class="selectpicker form-control" name="status"
                                data-style="btn-outline-primary">
                                <option value="1">Active</option>
                                <option value="0">Disable</option>
                            </select>
                        </div>

                        <div class="row">
                            <div class="col-sm-12">
                                <button type="submit" class="btn btn-primary btn-block"
                                    id="search_tag_submit_btn">Save</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>


    <script src="{{ asset('assets/vendors/scripts/core.js') }}"></script>
    <script src="{{ asset('assets/vendors/scripts/script.min.js') }}"></script>
    <script src="{{ asset('assets/vendors/scripts/process.js') }}"></script>
    <script src="{{ asset('assets/vendors/scripts/layout-settings.js') }}"></script>
    <script src="{{ asset('assets/js/role_access.js') }}"></script>
    <script src="{{ asset('assets/plugins/datatables/js/jquery.dataTables.min.js') }}"></script>
    <script src="{{ asset('assets/plugins/datatables/js/dataTables.bootstrap4.min.js') }}"></script>
    <script src="{{ asset('assets/plugins/datatables/js/dataTables.responsive.min.js') }}"></script>
    <script src="{{ asset('assets/plugins/datatables/js/responsive.bootstrap4.min.js') }}"></script>
    <!-- Datatable Setting js -->
    <script src="{{ asset('assets/vendors/scripts/datatable-setting.js') }}"></script>

    <script>
        function openSearchTagModal(mode, data = {}) {
            $('#search_tag_form')[0].reset();
            $('#search_tag_modal_title').text(mode === 'edit' ? 'Edit Search Tag' : 'Add Search Tag');
            $('#search_tag_submit_btn').text(mode === 'edit' ? 'Update' : 'Save');
            $('#search_tag_method').val(mode === 'edit' ? 'PUT' : 'POST');
            $('#search_tag_form').attr('data-mode', mode);

            if (mode === 'edit' && data) {
                $('#search_tag_id').val(data.id);
                $('#searchTagName').val(data.name);
                $('#searchTagStatus').val(data.status);
            } else {
                $('#search_tag_id').val('');
                $('#searchTagStatus').val('1');
            }

            $('#add_search_tag_model').modal('show');
        }

        $('#search_tag_form').on('submit', function(event) {
            event.preventDefault();

            const formData = new FormData(this);
            const id = $('#search_tag_id').val();

            if (id) {
                formData.append('id', id); // Include ID if in edit mode
            }

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                }
            });

            $.ajax({
                url: 'submit_search_tag',
                type: 'POST',
                data: formData,
                beforeSend: function() {
                    $('#loading_screen').show();
                },
                success: function(data) {
                    $('#loading_screen').hide();
                    if (data.error) {
                        alert('Error: ' + data.error);
                    } else {
                        location.reload();
                    }
                },
                error: function(error) {
                    $('#loading_screen').hide();
                    alert(error.responseText);
                },
                cache: false,
                contentType: false,
                processData: false
            });
        });



        function delete_click(id) {

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                }
            });

            var url = "{{ route('searchTag.delete', ':id') }}";
            url = url.replace(":id", id);

            $.ajax({
                url: url,
                type: 'POST',
                beforeSend: function() {
                    var loading_screen = document.getElementById("loading_screen");
                    loading_screen.style.display = "block";
                },
                success: function(data) {
                    var loading_screen = document.getElementById("loading_screen");
                    loading_screen.style.display = "none";
                    if (data.error) {
                        window.alert(data.error);
                    } else {
                        location.reload();
                    }
                },
                error: function(error) {
                    var loading_screen = document.getElementById("loading_screen");
                    loading_screen.style.display = "none";
                    window.alert(error.responseText);
                },
                cache: false,
                contentType: false,
                processData: false
            })
        }
    </script>

</body>

</html>
