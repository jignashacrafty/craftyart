@inject('roleManager', 'App\Http\Controllers\Utils\RoleManager')

<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}" />

    <title>Laravel</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

    <link rel="stylesheet" type="text/css" href="{{ asset('assets/vendors/styles/core.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/vendors/styles/icon-font.min.css') }}">
    <link rel="stylesheet" type="text/css"
        href="{{ asset('assets/plugins/datatables/css/dataTables.bootstrap4.min.css') }}">
    <link rel="stylesheet" type="text/css"
        href="{{ asset('assets/plugins/datatables/css/responsive.bootstrap4.min.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/vendors/styles/style.css') }}">
</head>

<body class="antialiased">

    @include('layouts.header')

    <div class="main-container seo-all-container">
        <div id="loading_screen" style="display: none;">
            <div id="loader-wrapper">
                <div id="loader"></div>
                <div class="loader-section section-left"></div>
                <div class="loader-section section-right"></div>
            </div>
        </div>

        <div class="pd-ltr-20 xs-pd-20-10">
            <div class="min-height-200px">
                <div class="card-box mb-30">
                    <div class="pb-20">

                        <div class="pd-20">
                            @if ($roleManager::onlySeoAccess(Auth::user()->user_type))
                                <a href="#" class="btn btn-primary" onclick="openLangAddModal()">Add Language</a>
                            @endif
                        </div>
                        <table class="data-table table stripe hover nowrap">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Name</th>
                                    <th>ID Name</th>
                                    <th>Status</th>
                                    <th class="datatable-nosort">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($langArray as $lang)
                                    <tr>
                                        <td class="table-plus">{{ $lang->id }}</td>
                                        <td class="table-plus">{{ $lang->name }}</td>
                                        <td class="table-plus">{{ $lang->id_name }}</td>
                                        @if ($lang->status == '1')
                                            <td>Active</td>
                                        @else
                                            <td>Disabled</td>
                                        @endif

                                        <td>
                                            <button class="dropdown-item"
                                                onclick="openLangEditModal('{{ $lang->id }}', '{{ $lang->name }}', '{{ $lang->status }}', '{{ $lang->id_name }}')">
                                                <i class="dw dw-edit2"></i> Edit
                                            </button>

                                            @if ($roleManager::isAdminOrSeoManager(Auth::user()->user_type))
                                                <Button class="dropdown-item"
                                                    onclick="delete_click('{{ $lang->id }}')"><i
                                                        class="dw dw-delete-3"></i> Delete</Button>
                                            @endif
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade seo-all-container" id="lang_modal" tabindex="-1" role="dialog"
        aria-labelledby="lang_modal_title" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">

                <div class="modal-header">
                    <h5 class="modal-title" id="lang_modal_title">Add Language</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                </div>

                <div class="modal-body">
                    <form method="post" id="lang_form" enctype="multipart/form-data">
                        @csrf
                        <input type="hidden" name="lang_id" id="lang_id" />

                        <div class="form-group">
                            <h7>Name</h7>
                            <div class="input-group custom">
                                <input type="text" class="form-control" placeholder="Language Name" name="name"
                                    id="languageName" required />
                            </div>
                        </div>

                        <div class="form-group">
                            <h7>ID Name</h7>
                            <div class="input-group custom">
                                <input type="text" class="form-control" placeholder="ID Name" id="languageIDName"
                                    name="id_name" required />
                            </div>
                        </div>

                        <div class="form-group">
                            <h6>Status</h6>
                            <div class="col-sm-20">
                                <select id="status" class="selectpicker form-control"
                                    data-style="btn-outline-primary" name="status">
                                    <option value="1">Active</option>
                                    <option value="0">Disable</option>
                                </select>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-sm-12">
                                <input class="btn btn-primary btn-block" type="submit" id="lang_submit_btn"
                                    value="Save">
                            </div>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>

    <script src="{{ asset('assets/vendors/scripts/core.js') }}"></script>
    <script src="{{ asset('assets/vendors/scripts/script.min.js') }}"></script>
    <script src="{{ asset('assets/vendors/scripts/process.js') }}"></script>
    <script src="{{ asset('assets/vendors/scripts/layout-settings.js') }}"></script>
    <script src="{{ asset('assets/js/role_access.js') }}"></script>
    <script src="{{ asset('assets/plugins/datatables/js/jquery.dataTables.min.js') }}"></script>
    <script src="{{ asset('assets/plugins/datatables/js/dataTables.bootstrap4.min.js') }}"></script>
    <script src="{{ asset('assets/plugins/datatables/js/dataTables.responsive.min.js') }}"></script>
    <script src="{{ asset('assets/plugins/datatables/js/responsive.bootstrap4.min.js') }}"></script>
    <!-- Datatable Setting js -->
    <script src="{{ asset('assets/vendors/scripts/datatable-setting.js') }}"></script>

    <script>
        function openLangAddModal() {
            $('#lang_modal_title').text("Add Language");
            $('#lang_submit_btn').val("Save");

            $('#lang_id').val('');
            $('#languageName').val('');
            $('#languageIDName').val('');
            $('#status').val('1');

            $('#lang_modal').modal('show');
        }

        function openLangEditModal(id, name, status, idName) {
            $('#lang_modal_title').text("Edit Language");
            $('#lang_submit_btn').val("Update");

            $('#lang_id').val(id);
            $('#languageName').val(name);
            $('#languageIDName').val(idName);
            $('#status').val(status);

            $('#lang_modal').modal('show');
        }

        $('#lang_form').on('submit', function(event) {
            event.preventDefault();

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                }
            });

            const formData = new FormData(this);
            const id = $('#lang_id').val();

            if (id) {
                formData.append('id', id);
            }

            $.ajax({
                url: 'store_or_update_lang',
                type: 'POST',
                data: formData,
                beforeSend: function() {
                    $("#loading_screen").show();
                },
                success: function(data) {
                    $("#loading_screen").hide();
                    if (data.error) {
                        alert('Error: ' + data.error);
                    } else {
                        location.reload(); // or refresh the table
                    }
                },
                error: function(error) {
                    $("#loading_screen").hide();
                    alert(error.responseText);
                },
                cache: false,
                contentType: false,
                processData: false
            });
        });


        $('#lang_modal').on('hidden.bs.modal', function() {
            $('#lang_form')[0].reset();
            $('#lang_id').val('');
        });


        function delete_click(id) {

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                }
            });

            var url = "{{ route('lang.delete', ':id') }}";
            url = url.replace(":id", id);
            $.ajax({
                url: url,
                type: 'POST',
                beforeSend: function() {
                    var loading_screen = document.getElementById("loading_screen");
                    loading_screen.style.display = "block";
                },
                success: function(data) {
                    var loading_screen = document.getElementById("loading_screen");
                    loading_screen.style.display = "none";
                    if (data.error) {
                        window.alert('error==>' + data.error);
                    } else {
                        location.reload();
                    }
                },
                error: function(error) {
                    var loading_screen = document.getElementById("loading_screen");
                    loading_screen.style.display = "none";
                    window.alert(error.responseText);
                },
                cache: false,
                contentType: false,
                processData: false
            })
        }
        const toTitleCase = str => str.replace(/\b\w+/g, txt => txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase());

        $(document).on("keypress", "#languageName", function() {
            const titleString = toTitleCase($(this).val());
            $("#languageIDName").val(`${titleString.toLowerCase().replace(/\s+/g, '-')}`);
            $(this).val(titleString);
        });

        $(document).on("keypress", "#editLangName", function() {
            const titleString = toTitleCase($(this).val());
            $("#editLangIDName").val(`${titleString.toLowerCase().replace(/\s+/g, '-')}`);
            $(this).val(titleString);
        });
    </script>
</body>

</html>
