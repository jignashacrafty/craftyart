@inject('roleManager', 'App\Http\Controllers\Utils\RoleManager')

<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}" />

    <title>Laravel</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

    <link rel="stylesheet" type="text/css" href="{{ asset('assets/vendors/styles/core.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/vendors/styles/icon-font.min.css') }}">
    <link rel="stylesheet" type="text/css"
        href="{{ asset('assets/plugins/datatables/css/dataTables.bootstrap4.min.css') }}">
    <link rel="stylesheet" type="text/css"
        href="{{ asset('assets/plugins/datatables/css/responsive.bootstrap4.min.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/vendors/styles/style.css') }}">
</head>

<body class="antialiased">

    @include('layouts.header')

    <div class="main-container seo-all-container">
        <div id="loading_screen" style="display: none;">
            <div id="loader-wrapper">
                <div id="loader"></div>
                <div class="loader-section section-left"></div>
                <div class="loader-section section-right"></div>
            </div>
        </div>

        <div class="pd-ltr-20 xs-pd-20-10">
            <div class="min-height-200px">
                <div class="card-box mb-30">
                    <div class="pb-20">

                        <div class="pd-20 ">
                            @if ($roleManager::onlySeoAccess(Auth::user()->user_type))
                                <a href="javascript:void(0)" onclick="openAddStyleModal()" class="btn btn-primary">Add
                                    Style</a>
                            @endif
                        </div>

                        <table class="data-table table stripe hover nowrap">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Name</th>
                                    <th>ID Name</th>
                                    <th>Status</th>
                                    <th>User</th>
                                    <th class="datatable-nosort">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($styleArray as $style)
                                    <tr>
                                        <td class="table-plus">{{ $style->id }}</td>

                                        <td class="table-plus">{{ $style->name }}</td>
                                        <td class="table-plus">{{ isset($style->id_name) ? $style->id_name : '' }}
                                        </td>

                                        @if ($style->status == '1')
                                            <td>Active</td>
                                        @else
                                            <td>Disabled</td>
                                        @endif
                                        <td>{{ $roleManager::getUploaderName($style->emp_id) }}
                                        </td>
                                        <td>
                                            @php
                                                $idName = $style->id_name;
                                            @endphp
                                            <button class="dropdown-item"
                                                onclick="openEditStyleModal('{{ $style->id }}', '{{ $style->name }}', '{{ $style->status }}', '{{ $style->id_name }}')"><i
                                                    class="dw dw-edit2"></i> Edit</button>
                                            @if ($roleManager::isAdminOrSeoManager(Auth::user()->user_type))
                                                <Button class="dropdown-item"
                                                    onclick="delete_click('{{ $style->id }}')"><i
                                                        class="dw dw-delete-3"></i> Delete</Button>
                                            @endif
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Shared Add/Edit Style Modal -->
    <div class="modal fade seo-access-container seo-all-container" id="add_style_model" tabindex="-1" role="dialog"
        aria-labelledby="myLargeModalLabel" aria-hidden="false">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="style_modal_title">Add Style</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                </div>

                <div class="modal-body">
                    <form method="post" id="style_form" enctype="multipart/form-data">
                        @csrf
                        <input type="hidden" name="id" id="style_id" value="">

                        <div class="form-group">
                            <h7>Name</h7>
                            <input type="text" class="form-control" id="styleName" name="name"
                                placeholder="Style Name" required />
                        </div>

                        <div class="form-group">
                            <h7>ID Name</h7>
                            <input type="text" class="form-control" id="styleIDName" name="id_name"
                                placeholder="ID Name" required />
                        </div>

                        <div class="form-group">
                            <h6>Status</h6>
                            <select id="styleStatus" class="form-control" name="status">
                                <option value="1">Active</option>
                                <option value="0">Disable</option>
                            </select>
                        </div>

                        <div class="row">
                            <div class="col-sm-12">
                                <button type="submit" id="style_submit_btn"
                                    class="btn btn-primary btn-block">Save</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="{{ asset('assets/vendors/scripts/core.js') }}"></script>
    <script src="{{ asset('assets/vendors/scripts/script.min.js') }}"></script>
    <script src="{{ asset('assets/vendors/scripts/process.js') }}"></script>
    <script src="{{ asset('assets/vendors/scripts/layout-settings.js') }}"></script>
    <script src="{{ asset('assets/js/role_access.js') }}"></script>
    <script src="{{ asset('assets/plugins/datatables/js/jquery.dataTables.min.js') }}"></script>
    <script src="{{ asset('assets/plugins/datatables/js/dataTables.bootstrap4.min.js') }}"></script>
    <script src="{{ asset('assets/plugins/datatables/js/dataTables.responsive.min.js') }}"></script>
    <script src="{{ asset('assets/plugins/datatables/js/responsive.bootstrap4.min.js') }}"></script>
    <!-- Datatable Setting js -->
    <script src="{{ asset('assets/vendors/scripts/datatable-setting.js') }}"></script>

    <script>
        // Add New Style Click
        function openAddStyleModal() {
            $('#style_modal_title').text('Add Style');
            $('#style_submit_btn').text('Save');
            $('#style_form')[0].reset();
            $('#style_id').val('');
            $('#style_form').attr('data-mode', 'add');

            $('#add_style_model').modal('show');
        }

        // Edit Style Click
        function openEditStyleModal(id, name, status, id_name) {
            $('#style_modal_title').text('Edit Style');
            $('#style_submit_btn').text('Update');

            $('#style_id').val(id);
            $('#styleName').val(name);
            $('#styleStatus').val(status);
            $('#styleIDName').val(id_name);

            $('#style_form').attr('data-mode', 'edit');

            $('#add_style_model').modal('show');
        }


        $('#style_form').on('submit', function(event) {
            event.preventDefault();

            const formData = new FormData(this);
            const id = $('#style_id').val();

            if (id) {
                formData.append('id', id);
            }

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                }
            });

            $.ajax({
                url: 'submit_style',
                type: 'POST',
                data: formData,
                beforeSend: function() {
                    $('#loading_screen').show();
                },
                success: function(data) {
                    $('#loading_screen').hide();
                    if (data.error) {
                        alert(data.error);
                    } else {
                        location.reload();
                    }
                },
                error: function(xhr) {
                    $('#loading_screen').hide();
                    alert(xhr.responseText);
                },
                cache: false,
                contentType: false,
                processData: false
            });
        });



        function delete_click(id) {

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                }
            });

            var url = "{{ route('style.delete', ':id') }}";
            url = url.replace(":id", id);

            $.ajax({
                url: url,
                type: 'POST',
                beforeSend: function() {
                    var loading_screen = document.getElementById("loading_screen");
                    loading_screen.style.display = "block";
                },
                success: function(data) {
                    var loading_screen = document.getElementById("loading_screen");
                    loading_screen.style.display = "none";
                    if (data.error) {
                        window.alert('error==>' + data.error);
                    } else {
                        location.reload();
                    }
                },
                error: function(error) {
                    var loading_screen = document.getElementById("loading_screen");
                    loading_screen.style.display = "none";
                    window.alert(error.responseText);
                },
                cache: false,
                contentType: false,
                processData: false
            })
        }

        const toTitleCase = str => str.replace(/\b\w+/g, txt => txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase());
        $("#styleName").on("input", function() {
            const titleString = toTitleCase($(this).val());
            $("#styleIDName").val(`${titleString.toLowerCase().replace(/\s+/g, '-')}`);
            $(this).val(titleString);
        });

        $(document).on("keypress", "#editName", function() {
            const titleString = toTitleCase($(this).val());
            $("#editIDName").val(`${titleString.toLowerCase().replace(/\s+/g, '-')}`);
            $(this).val(titleString);
        });
    </script>

</body>

</html>
