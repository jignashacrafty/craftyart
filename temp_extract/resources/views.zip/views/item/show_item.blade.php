@inject('helperController', 'App\Http\Controllers\HelperController')
@inject('roleManager', 'App\Http\Controllers\Utils\RoleManager')

<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>Laravel</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

    <link rel="stylesheet" type="text/css" href="{{ asset('assets/vendors/styles/core.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/vendors/styles/icon-font.min.css') }}">
    <link rel="stylesheet" type="text/css"
          href="{{ asset('assets/plugins/datatables/css/dataTables.bootstrap4.min.css') }}">
    <link rel="stylesheet" type="text/css"
          href="{{ asset('assets/plugins/datatables/css/responsive.bootstrap4.min.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/vendors/styles/style.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/vendors/styles/loader.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/plugins/switchery/switchery.min.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/vendors/styles/custom.css') }}">

    <style>
        .filter-row .form-control,
        .filter-row button {
            min-width: 170px;
        }

        @media (max-width: 768px) {
            .filter-row {
                gap: 10px !important;
            }
        }

        .scroll-wrapper {
            flex: 1;
            overflow-y: auto;
            overflow-x: auto;
            max-height: calc(100vh - 220px);
        }

        .tableFixHead thead th {
            position: sticky;
            top: -5px;
            z-index: 10;
            background-color: grey;
            color: white;
        }

        .tableFixHead {
            min-width: 1000px;
        }

        .pagination-footer {
            position: sticky;
            bottom: 0;
            background: #fff;
            z-index: 15;
            padding: 10px 0;
            border-top: 1px solid #ddd;
        }

        @media (max-width: 1024px) {
            .pagination-footer .pagination {
                flex-wrap: wrap;
                justify-content: center !important;
            }

            .dataTables_info {
                text-align: center;
            }
        }

        .filter-header {
            position: sticky;
            top: 0;
            z-index: 20;
            background: #fff;
            padding: 10px 15px;
            border-bottom: 1px solid #ddd;
        }
    </style>
</head>

<body class="antialiased">

@include('layouts.header')

<div class="main-container">
    <div id="loading_screen" style="display: none;">
        <div id="loader-wrapper">
            <div id="loader"></div>
            <div class="loader-section section-left"></div>
            <div class="loader-section section-right"></div>
        </div>
    </div>
    <div class=" xs-pd-20-10">
        <div class="min-height-200px">
            <div class="card-box mb-5">
                <div class="">

                    <div style="display: flex; flex-direction: column; height: 87vh; overflow: hidden;">

                        <div class="filter-header">
                            <div class="row align-items-center justify-content-between pd-20">

                                @if($roleManager::onlyDesignerAccess(Auth::user()->user_type) && !$roleManager::isDesignerManager(Auth::user()->user_type))
                                <div class="col-lg-2 col-md-4 col-12">
                                    <div class=" buttons-list">
                                        <button class="btn btn-primary" onclick="appSelection()">Add New
                                            Template
                                        </button>
                                    </div>
                                </div>
                                @endif

                                <div
                                        class="col-md-8 col-lg-6 col-12 d-flex mt-2 col-md-justify-content-around justify-content-between flex-wrap">
                                    <form method="GET" action="{{ route('show_item') }}" class="me-2">
                                        <input type="hidden" name="animated"
                                               value="{{ request('animated', 'all') }}">
                                        <select name="template_status" class="form-control" style="min-width:170px;"
                                                onchange="this.form.submit()">
                                            <option value="all"
                                                    {{ request(
                                            'template_status') == 'all' ? 'selected' : '' }}>All
                                            Templates</option>
                                            <option value="live"
                                                    {{ request(
                                            'template_status') == 'live' ? 'selected' : '' }}>Live
                                            Templates</option>
                                            <option value="not-live"
                                                    {{ request(
                                            'template_status') == 'not-live' ? 'selected' : '' }}>
                                            Not Live Templates</option>
                                        </select>
                                    </form>

                                    @if($roleManager::isSeoIntern(Auth::user()->user_type) || $roleManager::isSeoExecutive(Auth::user()->user_type))
                                    <form method="GET" action="{{ route('show_item') }}" class="me-2">
                                        <input type="hidden" name="seo_employee"
                                               value="{{ request('seo_employee', 'all') }}">
                                        <select name="seo_employee" class="form-control" style="min-width:170px;"
                                                onchange="this.form.submit()">
                                            <option value="all"
                                                    {{ request('seo_employee') == 'all' ? 'selected' : '' }}>All Templates</option>
                                            <option value="1" {{ request('seo_employee') == '1' ? 'selected' : '' }}>My Seo Template</option>
                                            <option value="0" {{ request('seo_employee') == '0' ? 'selected' : '' }}>
                                            Other Seo Template</option>
                                        </select>
                                    </form>
                                    @endif

                                    <form method="GET" action="{{ route('show_item') }}" class="me-2">
                                        <input type="hidden" name="template_status"
                                               value="{{ request('template_status', 'all') }}">
                                        <select name="animated" class="form-control" style="min-width:170px;"
                                                onchange="this.form.submit()">
                                            <option value="all"
                                                    {{ request(
                                            'animated') == 'all' ? 'selected' : '' }}>All Templates
                                            </option>
                                            <option value="false"
                                                    {{ request(
                                            'animated') == 'false' ? 'selected' : '' }}>Normal
                                            Templates</option>
                                            <option value="true"
                                                    {{ request(
                                            'animated') == 'true' ? 'selected' : '' }}>Animated
                                            Templates</option>
                                        </select>
                                    </form>


                                    @if ($roleManager::isAdmin(Auth::user()->user_type))
                                    <!-- Excel Button -->
                                    <div class="me-2">
                                        <button id="excel_btn"
                                                class="btn btn-secondary buttons-excel buttons-html5"
                                                type="button">
                                            <span>Excel</span>
                                        </button>
                                    </div>
                                    @endif

                                    @if ($roleManager::isAdmin(Auth::user()->user_type) &&
                                    isset($itemArray['thumbs']))
                                    <div class="me-2">
                                        <button class="btn btn-primary"
                                                onclick="downloadClick('{{ $itemArray['thumbs'] }}')">Download
                                            All
                                        </button>
                                    </div>
                                    @endif
                                </div>

                                <div class="col-lg-4 col-12 mt-4">
                                    <form action="{{ route('show_item') }}" method="GET">
                                        <div class="input-group d-flex" style="gap: 10px">
                                            <input type="text" class="form-control" name="query"
                                                   placeholder="Search here....."
                                                   value="{{ request()->input('query') }}">
                                            <button type="submit" class="btn btn-primary">Search</button>
                                        </div>
                                    </form>
                                </div>
                            </div>

                        </div>

                        <div class="scroll-wrapper table-responsive tableFixHead">
                            <table id="temp_table" class="table table-striped table-bordered mb-0">
                                <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>User</th>
                                    <th>Seo Employee</th>
                                    <th>Creator</th>
                                    <th>
                                        @php
                                        if ($roleManager::isAdminOrSeoManager(Auth::user()->user_type) || $roleManager::isAdminOrDesignerManager(Auth::user()->user_type)){
                                        $label = 'Assign to';
                                        } else {
                                        $label = 'Assign by';
                                        }
                                        @endphp
                                        <span>{{ $label }}</span>
                                    </th>
                                    <th>Category Name</th>
                                    <th>W/H</th>
                                    <th>Poster Name</th>
                                    <th class="datatable-nosort">Poster Thumb</th>
                                    <th>Size</th>
                                    <th>Views</th>
                                    @if ($roleManager::isAdmin(Auth::user()->user_type))
                                    <th>Purchases</th>
                                    @endif
                                    <th>No Index</th>
                                    <th>Is Pinned</th>
                                    <th>Editor choice</th>
                                    <th style="min-width: 150px">Premium Type</th>
                                    <th>Status</th>
                                    <th>Created At</th>
                                    <th class="datatable-nosort">Action</th>
                                </tr>
                                </thead>
                                <tbody id="item_table">
                                @foreach ($itemArray['item'] as $item)
                                <tr style="background-color: #efefef;">
                                    <td class="table-plus">{{$item->id}}</td>
                                    <td>{{ $roleManager::getEmployeeName($item->emp_id) }}</td>
                                    <td>{{ $roleManager::getEmployeeName($item->seo_emp_id) }}</td>
                                    <td>{{ $roleManager::getCreatorName($item->creator_id) }}</td>
                                    <td>
                                        @if (
                                        $roleManager::isAdminOrSeoManager(Auth::user()->user_type) ||
                                        $roleManager::isAdminOrDesignerManager(Auth::user()->user_type)
                                        )
                                        @if(!isset($item->seo_emp_id))
                                        <select name="seo_assigner_id" class="form-control" onchange="assignSeoEmployee('{{ $item->id }}', this.value)">
                                            <option value="">-- Select Executive/Intern --</option>
                                            @foreach ($itemArray['seoExecutiveNIntern'] as $user)
                                            <option value="{{ $user->id }}">{{ $user->name }}</option>
                                            @endforeach
                                        </select>
                                        @else
                                        <span>{{ $roleManager::getEmployeeName($item->seo_emp_id) }}</span>
                                        @endif
                                        @else
                                        <span>{{ $roleManager::getEmployeeName($item->seo_assigner_id) }}</span>
                                        @endif
                                    </td>
                                    <td style="position: relative;">
                                        <label>({{ $helperController::getCatName($item->category_id) }})</label><br/>
                                        <label>({{ $helperController::getNewCatName($item->new_category_id) }} - ({{
                                            $helperController::getParentNewCatName($item->new_category_id) }}))</label>
                                    </td>


                                    <!-- <td style="position: relative;">
                                        <input type="hidden" id="category-{{$item->id}}"
                                            value="{{ json_encode($itemArray['newCategories']) }}" />
                                        <label data-id="{{$item->id}}"
                                            data-cat-id="{{$item->category_id}}">{{ $helperController::getNewCatName($item->new_category_id) }}</label>
                                        {{-- <label class="editable" data-id="{{$item->id}}"
                                            data-cat-id="{{$item->category_id}}">{{ $helperController::
                                            getNewCatName($item->new_category_id) }}</label> --}}
                                        {{-- <div class="categoriesList" data-id="{{$item->id}}">
                                            <ul class="orderlist-categories"
                                                id="orderlistCategories-{{$item->id}}" data-id="{{$item->id}}">

                                            </ul>
                                        </div> --}}
                                    </td>
                                    <td style="position: relative;">
                                        <label>{{ $helperController::getParentNewCatName($item->new_category_id) }}</label>
                                    </td> -->
                                    <td>{{ $item->width }} * {{ $item->height }}</td>
                                    <td>{{ $item->post_name }}</td>
                                    <td><img src="{{ config('filesystems.storage_url') }}{{$item->post_thumb}}"
                                             style="max-width: 100px; max-height: 100px; width: auto; height: auto"/>
                                    </td>
                                    <td>{{ $helperController::templateSize($item->size) }}</td>
                                    <td>{{ $item->views }} ({{ $item->trending_views }})</td>

                                    @if ($roleManager::isAdmin(Auth::user()->user_type))
                                    <td>{{ $helperController::getPurchaseTemplateCount($item->string_id) }}</td>
                                    @endif

                                    @if ($roleManager::isAdminOrSeoManager(Auth::user()->user_type))
                                    @if($item->no_index == '1')
                                    <td><label id="noindex_label_{{$item->id}}"
                                               style="display: none;">TRUE</label>
                                        <Button style="border: none"
                                                onclick="noindex_click(this, '{{$item->id}}')"><input type="checkbox"
                                                                                                      checked
                                                                                                      class="switch-btn"
                                                                                                      data-size="small"
                                                                                                      data-color="#0059b2"/>
                                        </Button>
                                    </td>
                                    @else
                                    <td><label id="noindex_label_{{$item->id}}"
                                               style="display: none;">FALSE</label>
                                        <Button style="border: none"
                                                onclick="noindex_click(this, '{{$item->id}}')"><input type="checkbox"
                                                                                                      class="switch-btn"
                                                                                                      data-size="small"
                                                                                                      data-color="#0059b2"/>
                                        </Button>
                                    </td>
                                    @endif
                                    @else
                                    @if($item->no_index == '1')
                                    <td>True</td>
                                    @else
                                    <td>False</td>
                                    @endif
                                    @endif

                                    @if($item->pinned == '1')
                                    <td><label id="pinned_label_{{$item->id}}"
                                               style="display: none;">TRUE</label>
                                        <Button style="border: none"
                                                onclick="pinned_click('{{$item->id}}')"><input type="checkbox"
                                                                                               checked
                                                                                               class="switch-btn"
                                                                                               data-size="small"
                                                                                               data-color="#0059b2"/>
                                        </Button>
                                    </td>
                                    @else
                                    <td><label id="pinned_label_{{$item->id}}"
                                               style="display: none;">FALSE</label>
                                        <Button style="border: none"
                                                onclick="pinned_click('{{$item->id}}')"><input type="checkbox"
                                                                                               class="switch-btn"
                                                                                               data-size="small"
                                                                                               data-color="#0059b2"/>
                                        </Button>
                                    </td>
                                    @endif

                                    @if ($roleManager::isAdminOrSeoManager(Auth::user()->user_type))
                                    @if($item->editor_choice == '1')
                                    <td><label id="editorchoice_label_{{$item->id}}"
                                               style="display: none;">TRUE</label>
                                        <Button style="border: none"
                                                onclick="editor_choice_click( '{{$item->id}}')"><input type="checkbox"
                                                                                                       checked
                                                                                                       class="switch-btn"
                                                                                                       data-size="small"
                                                                                                       data-color="#0059b2"/>
                                        </Button>
                                    </td>
                                    @else
                                    <td><label id="editorchoice_label_{{$item->id}}"
                                               style="display: none;">FALSE</label>
                                        <Button style="border: none"
                                                onclick="editor_choice_click('{{$item->id}}')"><input type="checkbox"
                                                                                                      class="switch-btn"
                                                                                                      data-size="small"
                                                                                                      data-color="#0059b2"/>
                                        </Button>
                                    </td>
                                    @endif
                                    @else
                                    @if($item->editor_choice == '1')
                                    <td>True</td>
                                    @else
                                    <td>False</td>
                                    @endif
                                    @endif


                                    @if ($roleManager::onlySeoAccess(Auth::user()->user_type) && !$roleManager::isSeoIntern(Auth::user()->user_type))
                                    <td>
                                        <select class="form-control"
                                                onchange="onPremiumChange('{{ $item->id }}', this.value)">
                                            <option value="free" {{ $item->is_premium == '0' && $item->is_freemium ==
                                                '0' ? 'selected' : '' }}>Free
                                            </option>
                                            <option value="freemium" {{ $item->is_premium == '0' && $item->is_freemium
                                                == '1' ? 'selected' : '' }}>Freemium
                                            </option>
                                            <option value="premium" {{ $item->is_premium == '1' && $item->is_freemium ==
                                                '0' ? 'selected' : '' }}>Premium
                                            </option>
                                        </select>
                                    </td>
                                    @else
                                    <td>
                                        @php
                                        if ($item->is_premium == '1' && $item->is_freemium == '0') {
                                        $label = 'Premium';
                                        } elseif ($item->is_premium == '0' && $item->is_freemium == '1') {
                                        $label = 'Freemium';
                                        } else {
                                        $label = 'Free';
                                        }
                                        @endphp
                                        <span>{{ $label }}</span>
                                    </td>
                                    @endif

                                    @if ($roleManager::onlySeoAccess(Auth::user()->user_type) && !$roleManager::isSeoIntern(Auth::user()->user_type))
                                    @if($item->status == '1')
                                    <td><label id="status_label_{{$item->id}}"
                                               style="display: none;">Live</label>
                                        <Button style="border: none"
                                                onclick="status_click(this, '{{$item->id}}')"><input type="checkbox"
                                                                                                     checked
                                                                                                     class="switch-btn"
                                                                                                     data-size="small"
                                                                                                     data-color="#0059b2"/>
                                        </Button>
                                    </td>
                                    @else
                                    <td><label id="status_label_{{$item->id}}" style="display: none;">Not
                                            Live</label>
                                        <Button style="border: none"
                                                onclick="status_click(this, '{{$item->id}}')"><input type="checkbox"
                                                                                                     class="switch-btn"
                                                                                                     data-size="small"
                                                                                                     data-color="#0059b2"/>
                                        </Button>
                                    </td>
                                    @endif
                                    @else
                                    @if($item->status == '1')
                                    <td>True</td>
                                    @else
                                    <td>False</td>
                                    @endif
                                    @endif

                                    <td>{{ $item->created_at }}</td>

                                    <td>
                                        <div class="dropdown">
                                            <a class="btn btn-link font-24 p-0 line-height-1 no-arrow dropdown-toggle"
                                               href="#" role="button" data-toggle="dropdown">
                                                <i class="dw dw-more"></i>
                                            </a>
                                            <div
                                                    class="dropdown-menu dropdown-menu-right dropdown-menu-icon-list">
                                                <Button class="dropdown-item"
                                                        onclick="notification_click('{{$item->id}}')"
                                                        data-backdrop="static" data-toggle="modal"
                                                        data-target="#send_notification_model"><i
                                                            class="dw dw-notification1"></i>Send
                                                    Notification
                                                </Button>
                                                <a class="dropdown-item" href="edit_item/{{$item->id}}"><i
                                                            class="dw dw-edit2"></i> Edit</a>
                                                <a class="dropdown-item" href="edit_seo_item/{{$item->id}}"><i
                                                            class="dw dw-edit2"></i> Edit SEO Data</a>
                                                @if ($roleManager::isAdminOrSeoManager(Auth::user()->user_type))
                                                <Button class="dropdown-item"
                                                        onclick="set_delete_id('{{$item->id}}')"
                                                        data-backdrop="static" data-toggle="modal"
                                                        data-target="#delete_model"><i
                                                            class="dw dw-delete-3"></i>Delete
                                                </Button>
                                                @endif
                                                <Button class="dropdown-item"
                                                        onclick="reset_click('{{$item->id}}')"
                                                        data-backdrop="static" data-toggle="modal"
                                                        data-target="#reset_date_model"><i
                                                            class="icon-copy dw dw-refresh"></i>Reset Date
                                                </Button>
                                                <Button class="dropdown-item"
                                                        onclick="reset_creation('{{$item->id}}')"
                                                        data-backdrop="static" data-toggle="modal"
                                                        data-target="#reset_creation_model"><i
                                                            class="icon-copy dw dw-refresh"></i>Reset
                                                    Creation
                                                </Button>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                @endforeach
                                </tbody>
                            </table>
                        </div>

                        <div class="pagination-footer w-100">
                            <div class="row mx-0 d-flex flex-wrap align-items-center">
                                <div class="col-12 col-md-5 mb-2 mb-md-0">
                                    <div class="dataTables_info" role="status" aria-live="polite">
                                        {{ $itemArray['count_str'] }}
                                    </div>
                                </div>
                                <div class="col-12 col-md-7 text-md-end">
                                    <div class="dataTables_paginate paging_simple_numbers">
                                        <ul class="pagination justify-content-md-end justify-content-center mb-0">
                                            {{
                                            $itemArray['item']->appends(request()->input())->links('pagination::bootstrap-4')
                                            }}
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="send_notification_model" tabindex="-1" role="dialog"
     aria-labelledby="myLargeModalLabel" aria-hidden="false">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="myLargeModalLabel">Send Notification</h5>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            </div>

            <div class="modal-body" id="notification_model">

                <form method="post" id="notification_form" enctype="multipart/form-data">
                    @csrf
                    <input id="temp_id" class="form-control" type="textname" name="temp_id"
                           style="display: none;"/>
                    <div class="form-group">
                        <h7>Title</h7>
                        <div class="input-group custom">
                            <input type="text" class="form-control" placeholder="Title" name="title"
                                   required=""/>
                        </div>
                    </div>

                    <div class="form-group">
                        <h7>Description</h7>
                        <div class="input-group custom">
                            <input type="text" class="form-control" placeholder="Description"
                                   name="description" required=""/>
                        </div>
                    </div>

                    <div class="form-group">
                        <h7>Large Icon</h7>
                        <div class="input-group custom">
                            <input type="file" class="form-control" name="large_icon"/>
                        </div>
                    </div>

                    <div class="form-group">
                        <h7>Big Picture</h7>
                        <div class="input-group custom">
                            <input type="file" class="form-control" name="big_picture"/>
                        </div>
                    </div>

                    <div class="form-group">
                        <h7>Schedule</h7>
                        <div class="input-group custom">
                            <input class="form-control datetimepicker" placeholder="Select Date & Time"
                                   type="text" name="schedule" readonly>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-sm-12">
                            <button type="button" class="btn btn-primary btn-block"
                                    id="send_notification_click">Send
                            </button>
                        </div>
                    </div>
                </form>

            </div>

        </div>
    </div>
</div>

<div class="modal fade" id="reset_date_model" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel"
     aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="myLargeModalLabel">Reset Date</h4>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            </div>
            <div class="modal-body">
                <p>Are you sure you reset the date?</p>
            </div>

            <input class="form-control" type="textname" id="reset_temp_id" name="reset_temp_id"
                   style="display: none">

            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">No</button>
                <button type="button" id="reset_date_click" class="btn btn-primary">Yes, Reset</button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="reset_creation_model" tabindex="-1" role="dialog"
     aria-labelledby="myLargeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="myLargeModalLabel">Reset Creation Date</h4>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            </div>
            <div class="modal-body">
                <p>Are you sure you reset the creation date?</p>
            </div>

            <input class="form-control" type="textname" id="reset_creation_id" name="reset_creation_id"
                   style="display: none">

            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">No</button>
                <button type="button" id="reset_creation_click" class="btn btn-primary">Yes, Reset</button>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="delete_model" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel"
     aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <input type="text" id="delete_id" name="delete_id" style="display: none;">
            <div class="modal-header">
                <h4 class="modal-title" id="myLargeModalLabel">Delete</h4>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            </div>
            <div class="modal-body">
                <p> Are you sure you want to delete? </p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">No, Cancel</button>
                <button type="button" class="btn btn-primary" onclick="delete_click()">Yes, Delete</button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade designer-employee-container" id="templateModal" tabindex="-1" role="dialog" aria-labelledby="templateModalLabel"
     aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-xl" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="templateModalLabel">Add New Template</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <!-- Your existing form -->
                <form method="post" id="dynamic_form" enctype="multipart/form-data">
                    <span id="result"></span>
                    @csrf
                    <div class="row">
                        <div class="col-md-4 col-sm-12">
                            <div class="form-group">
                                <h6>Json File</h6>
                                <input type="file" id="json_file" class="form-control-file form-control"
                                       name="json_file">
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-12">
                            <div class="form-group">
                                <h6>Images</h6>
                                <input type="file" class="form-control" id="st_image" name="st_image[]"
                                       multiple required>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-12">
                            <div class="form-group">
                                <h6>Select Application</h6>
                                <div class="col-sm-20">
                                    <select id="app_id" class="selectpicker form-control"
                                            data-style="btn-outline-primary" required name="app_id">
                                        <option value="" disabled selected>== Select Application ==</option>
                                        @foreach ($datas['apps'] as $app)
                                        <option value="{{ $app->id }}">{{ $app->app_name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            {{ csrf_field() }}
                        </div>
                    </div>
                    <div class="text-right">
                        <input class="btn btn-primary" type="submit" name="submit">
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script src="{{ asset('assets/vendors/scripts/core.js') }}"></script>
<script src="{{ asset('assets/vendors/scripts/script.min.js') }}"></script>
<script src="{{ asset('assets/vendors/scripts/process.js') }}"></script>
<script src="{{ asset('assets/vendors/scripts/layout-settings.js') }}"></script>
<script src="{{ asset('assets/plugins/datatables/js/jquery.dataTables.min.js') }}"></script>
<script src="{{ asset('assets/plugins/datatables/js/dataTables.bootstrap4.min.js') }}"></script>
<script src="{{ asset('assets/plugins/datatables/js/dataTables.responsive.min.js') }}"></script>
<script src="{{ asset('assets/plugins/datatables/js/responsive.bootstrap4.min.js') }}"></script>
<!-- <script src="{{ asset('assets/vendors/scripts/datatable-setting.js') }}"></script> -->
<script src="{{ asset('assets/plugins/switchery/switchery.min.js') }}"></script>
<script src="{{ asset('assets/vendors/scripts/advanced-components.js') }}"></script>
<script src="https://unpkg.com/xlsx/dist/xlsx.full.min.js"></script>

<script>
    $(document).ready(function () {
        $('#dynamic_form').on('submit', function(event) {
            event.preventDefault();
            count = 0;
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                }
            });
            var formData = new FormData(this);
            $.ajax({
                url: 'submit_json',
                type: 'POST',
                data: formData,
                beforeSend: function() {
                    var loading_screen = document.getElementById("loading_screen");
                    loading_screen.style.display = "block";
                },
                success: function(data) {
                    if (data.error) {
                        $('#result').html('<div class="alert alert-danger">' + data.error.message +
                            '</div>');
                    } else {
                        $('#result').html('<div class="alert alert-success">' + data
                                .success +
                            '</div>');
                    }
                    loading_screen.style.display = "none";
                    location.reload();
                },
                error: function(xhr, status, error) {
                    window.alert(error);
                    loading_screen.style.display = "none";
                },
                cache: false,
                contentType: false,
                processData: false
            })
        });

        function updateCategory(catId, templateId) {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                }
            });
            $.ajax({
                url: "{{route('update.temp_category')}}",
                type: 'PUT',
                data: {
                    cat_id: catId,
                    tempId: templateId,
                },
                beforeSend: function () {
                    var loading_screen = document.getElementById("loading_screen");
                    loading_screen.style.display = "block";
                },
                success: function (data) {
                    var loading_screen = document.getElementById("loading_screen");
                    loading_screen.style.display = "none";
                    location.reload();
                },
                error: function (error) {
                    var loading_screen = document.getElementById("loading_screen");
                    loading_screen.style.display = "none";
                    window.alert(error.responseText);
                },
            })
        }
        $('.editable').click(function () {
            $(".categoriesList").hide();
            let id = $(this).data('id');
            var categories = $(`#category-${id}`).val();
            categories = JSON.parse(categories);
            var categorisList = '';
            $.each(categories, function (index, val) {
                categorisList += `<li data-id="${val.id}" data-temp-id="${id}">${val.category_name}</li>`;
            });
            $(this).next().show();
            $(`#orderlistCategories-${id}`).html(categorisList);
        });

        $(document).on("click", ".categoriesList ul li", function () {
            let templateId = $(this).data('temp-id');
            let catId = $(this).data('id');
            updateCategory(catId, templateId)
            $(".categoriesList").hide();
        })

        $('input').blur(function () {
            var newText = $(this).val();
            // $(this).hide();
            $(this).siblings('label').text(newText).show();
        });

    });

    function notification_click($id) {
        $("#temp_id").val($id);
    }
    function reset_click($id) {
        $("#reset_temp_id").val($id);
    }
    function reset_creation($id) {
        $("#reset_creation_id").val($id);
    }

    function onPremiumChange(id, type) {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
            }
        });

        let formData = new FormData();
        formData.append('id', id);
        formData.append('type', type);

        $.ajax({
            url: "{{ route('temp.premium.update') }}", // use your correct route
            type: 'POST',
            data: formData,
            beforeSend: function () {
                document.getElementById("loading_screen").style.display = "block";
            },
            success: function (data) {
                document.getElementById("loading_screen").style.display = "none";
                if (data.error) {
                    alert(data.error);
                }
            },
            error: function (xhr) {
                document.getElementById("loading_screen").style.display = "none";
                alert('Something went wrong: ' + xhr.responseText);
            },
            cache: false,
            contentType: false,
            processData: false
        });
    }

    function pinned_click($id) {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
            }
        });

        var status = $id;
        var url = "{{route('temp.pinned', ":status")}}";
        url = url.replace(":status", status);
        var formData = new FormData();
        formData.append('id', $id);
        $.ajax({
            url: url,
            type: 'POST',
            data: formData,
            beforeSend: function () {
                var loading_screen = document.getElementById("loading_screen");
                loading_screen.style.display = "block";
            },
            success: function (data) {
                var loading_screen = document.getElementById("loading_screen");
                loading_screen.style.display = "none";
                if (data.error) {
                    window.alert(data.error);
                } else {
                    var x = document.getElementById("pinned_label_" + $id);
                    if (x.innerHTML === "TRUE") {
                        x.innerHTML = "FALSE";
                    } else {
                        x.innerHTML = "TRUE";
                    }
                }

            },
            error: function (error) {
                var loading_screen = document.getElementById("loading_screen");
                loading_screen.style.display = "none";
                window.alert(error.responseText);
            },
            cache: false,
            contentType: false,
            processData: false
        })
    }

    function editor_choice_click($id) {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
            }
        });

        var status = $id;
        var url = "{{route('temp.editor.choice', ":status")}}";
        url = url.replace(":status", status);
        var formData = new FormData();
        formData.append('id', $id);
        $.ajax({
            url: url,
            type: 'POST',
            data: formData,
            beforeSend: function () {
                var loading_screen = document.getElementById("loading_screen");
                loading_screen.style.display = "block";
            },
            success: function (data) {
                var loading_screen = document.getElementById("loading_screen");
                loading_screen.style.display = "none";
                if (data.error) {
                    window.alert(data.error);
                } else {
                    var x = document.getElementById("editorchoice_label_" + $id);
                    if (x.innerHTML === "TRUE") {
                        x.innerHTML = "FALSE";
                    } else {
                        x.innerHTML = "TRUE";
                    }
                }

            },
            error: function (error) {
                var loading_screen = document.getElementById("loading_screen");
                loading_screen.style.display = "none";
                window.alert(error.responseText);
            },
            cache: false,
            contentType: false,
            processData: false
        })
    }

    function noindex_click(parentElement, $id) {
        let element = parentElement.firstElementChild;
        const originalChecked = element.checked;
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
            }
        });

        var status = $id;
        var url = "{{route('check_n_i')}}";
        var formData = new FormData();
        formData.append('id', $id);
        formData.append('type', 'template');
        $.ajax({
            url: url,
            type: 'POST',
            data: formData,
            beforeSend: function () {
                var loading_screen = document.getElementById("loading_screen");
                loading_screen.style.display = "block";
            },
            success: function (data) {
                var loading_screen = document.getElementById("loading_screen");
                loading_screen.style.display = "none";
                if (data.error) {
                    alert(data.error);
                    element.checked = !originalChecked;
                    element.dispatchEvent(new Event('change', { bubbles: true }));
                } else {
                    var x = document.getElementById("noindex_label_" + $id);
                    if (x.innerHTML === "TRUE") {
                        x.innerHTML = "FALSE";
                    } else {
                        x.innerHTML = "TRUE";
                    }
                }

            },
            error: function (error) {
                var loading_screen = document.getElementById("loading_screen");
                loading_screen.style.display = "none";
                window.alert(error.responseText);
            },
            cache: false,
            contentType: false,
            processData: false
        })
    }

    function status_click(parentElement, $id) {

        let element = parentElement.firstElementChild;
        const originalChecked = element.checked;

        event.preventDefault();

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
            }
        });

        var status = $id;
        var url = "{{route('temp.status', ":status")}}";
        url = url.replace(":status", status);
        var formData = new FormData();
        formData.append('id', $id);
        $.ajax({
            url: url,
            type: 'POST',
            data: formData,
            beforeSend: function () {
                var loading_screen = document.getElementById("loading_screen");
                loading_screen.style.display = "block";
            },
            success: function (data) {
                var loading_screen = document.getElementById("loading_screen");
                loading_screen.style.display = "none";
                if (data.error) {
                    alert(data.error);
                    element.checked = !originalChecked;
                    element.dispatchEvent(new Event('change', { bubbles: true }));
                } else {
                    var x = document.getElementById("status_label_" + $id);
                    if (x.innerHTML === "Live") {
                        x.innerHTML = "Not Live";
                    } else {
                        x.innerHTML = "Live";
                    }
                }
            },
            error: function (error) {
                var loading_screen = document.getElementById("loading_screen");
                loading_screen.style.display = "none";
                window.alert(error.responseText);
            },
            cache: false,
            contentType: false,
            processData: false
        })
    }

    function assignSeoEmployee(id, seo_emp_id) {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
            }
        });

        let formData = new FormData();
        formData.append('id', id);
        formData.append('seo_emp_id', seo_emp_id);
        $.ajax({
            url: "{{ route('temp.assign-seo') }}",
            type: "POST",
            data: formData,
            contentType: false,
            processData: false,
            beforeSend: function () {
                var loading_screen = document.getElementById("loading_screen");
                if (loading_screen) loading_screen.style.display = "block";
            },
            success: function (data) {
                var loading_screen = document.getElementById("loading_screen");
                if (loading_screen) loading_screen.style.display = "none";

                if (data.success) {
                    location.reload(); // Reload to show <span> instead of <select>
                } else {
                    alert("Error: " + data.message);
                }
            },
            error: function (xhr) {
                var loading_screen = document.getElementById("loading_screen");
                if (loading_screen) loading_screen.style.display = "none";

                alert("AJAX Error:\n" + xhr.responseText);
            }
        });
    }

    $(document).on('click', '#send_notification_click', function () {
        event.preventDefault();
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
            }
        });

        var formData = new FormData(document.getElementById("notification_form"));
        var status = formData.get("temp_id");
        var url = "{{route('poster.notification', ":status")}}";
        url = url.replace(":status", status);

        $.ajax({
            url: url,
            type: 'POST',
            data: formData,
            beforeSend: function () {
                $('#send_notification_model').modal('toggle');
                var loading_screen = document.getElementById("loading_screen");
                loading_screen.style.display = "block";
            },
            success: function (data) {
                var loading_screen = document.getElementById("loading_screen");
                loading_screen.style.display = "none";
                if (data.error) {
                    window.alert(data.error);
                } else {
                    window.alert(data.success);
                }

            },
            error: function (error) {
                var loading_screen = document.getElementById("loading_screen");
                loading_screen.style.display = "none";
                window.alert(error.responseText);
            },
            cache: false,
            contentType: false,
            processData: false
        })
    });

    $(document).on('click', '#reset_date_click', function () {
        event.preventDefault();
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
            }
        });

        var status = $("#reset_temp_id").val();
        var url = "{{route('reset.date', ":status")}}";
        url = url.replace(":status", status);
        var formData = new FormData();
        formData.append('id', status);
        $.ajax({
            url: url,
            type: 'POST',
            data: formData,
            beforeSend: function () {
                $('#reset_date_model').modal('toggle');
                var loading_screen = document.getElementById("loading_screen");
                loading_screen.style.display = "block";
            },
            success: function (data) {
                var loading_screen = document.getElementById("loading_screen");
                loading_screen.style.display = "none";
                if (data.error) {
                    window.alert(data.error);
                }

            },
            error: function (error) {
                var loading_screen = document.getElementById("loading_screen");
                loading_screen.style.display = "none";
                window.alert(error.responseText);
            },
            cache: false,
            contentType: false,
            processData: false
        })
    });

    $(document).on('click', '#reset_creation_click', function () {
        event.preventDefault();
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
            }
        });

        var status = $("#reset_creation_id").val();
        var url = "{{route('reset.creation', ":status")}}";
        url = url.replace(":status", status);
        var formData = new FormData();
        formData.append('id', status);

        $.ajax({
            url: url,
            type: 'POST',
            data: formData,
            beforeSend: function () {
                $('#reset_creation_model').modal('toggle');
                var loading_screen = document.getElementById("loading_screen");
                loading_screen.style.display = "block";
            },
            success: function (data) {
                var loading_screen = document.getElementById("loading_screen");
                loading_screen.style.display = "none";
                if (data.error) {
                    window.alert(data.error);
                }
            },
            error: function (error) {
                var loading_screen = document.getElementById("loading_screen");
                loading_screen.style.display = "none";
                window.alert(error.responseText);
            },
            cache: false,
            contentType: false,
            processData: false
        })
    });

    $(document).ready(function () {
        $('#application_id').change(function () {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            var value = $(this).val();
            $.ajax({
                url: "{{ route('item.custom_data') }}",
                method: "POST",
                data: { value: value, _token: '{{csrf_token()}}' },
                success: function (result) {
                    $('#item_table').html(result);
                }, error: function (result) {
                    window.alert(result.responseText);
                }
            })
        });
    });


    function set_delete_id($id) {
        $("#delete_id").val($id);
    }

    function delete_click() {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
            }
        });

        id = $("#delete_id").val();
        var url = "{{route('item.delete', ":id")}}";
        url = url.replace(":id", id);
        $.ajax({
            url: url,
            type: 'POST',
            beforeSend: function () {
                $('#delete_model').modal('toggle');
                var loading_screen = document.getElementById("loading_screen");
                loading_screen.style.display = "block";
            },
            success: function (data) {
                var loading_screen = document.getElementById("loading_screen");
                loading_screen.style.display = "none";
                if (data.error) {
                    window.alert('error==>' + data.error);
                } else {
                    location.reload();
                }
            },
            error: function (error) {
                var loading_screen = document.getElementById("loading_screen");
                loading_screen.style.display = "none";
                window.alert(error.responseText);
            },
            cache: false,
            contentType: false,
            processData: false
        })
    }


    function appSelection() {
        $('#templateModal').modal('show');
    }

</script>
</body>
{{ request(

</html>