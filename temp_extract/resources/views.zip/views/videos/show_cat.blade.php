@inject('roleManager', 'App\Http\Controllers\Utils\RoleManager')
<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Laravel</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

    <link rel="stylesheet" type="text/css" href="{{ asset('assets/vendors/styles/core.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/vendors/styles/icon-font.min.css') }}">
    <link rel="stylesheet" type="text/css"
        href="{{ asset('assets/plugins/datatables/css/dataTables.bootstrap4.min.css') }}">
    <link rel="stylesheet" type="text/css"
        href="{{ asset('assets/plugins/datatables/css/responsive.bootstrap4.min.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/vendors/styles/style.css') }}">
    <style>
        .sort-arrow {
            margin-left: 0px;
        }

        .sort-arrow.active {
            color: #1739d1ec;
        }

        .sort-arrow {
            font-family: 'dropways';
            font-size: 14px;
            color: grey;
            /* Default color */
        }

        .sort-asc::before {
            content: "\eabb";
            /* Custom icon content for up arrow */
        }

        .sort-desc::before {
            content: "\eaba";
        }

        /* Active state with blue color */
        .sort-asc.active::before,
        .sort-desc.active::before {
            color: #1b00ff;
        }

        span.sort-arrow.sort-desc {
            margin-left: -7px;
        }
    </style>
</head>

<body class="antialiased">

    @include('layouts.header')

    <div class="main-container">
        <div class="pd-ltr-20 xs-pd-20-10">
            <div class="min-height-200px">
                <div class="card-box mb-30">
                    <div class="pb-20">

                        <div class="pd-20">
                            <a class="btn btn-primary" href="create_v_cat" role="button"> Add New Category </a>
                        </div>

                        <table class="table table-striped mt-2">
                            <form method="GET" action="{{ route('show_v_cat') }}" id="filter-form">
                                <div class="form-row">
                                    <div class="col">
                                        <input type="text" name="query" class="form-control" placeholder="Search..."
                                            value="{{ request('query') }}">
                                    </div>
                                    <div class="col">
                                        <select name="per_page" class="form-control">
                                            <option value="10" {{ request('per_page') == '10' ? 'selected' : '' }}>10
                                            </option>
                                            <option value="20" {{ request('per_page') == '20' ? 'selected' : '' }}>20
                                            </option>
                                            <option value="50" {{ request('per_page') == '50' ? 'selected' : '' }}>50
                                            </option>
                                            <option value="100" {{ request('per_page') == '100' ? 'selected' : '' }}>100
                                            </option>
                                            <option value="500" {{ request('per_page') == '500' ? 'selected' : '' }}>500
                                            </option>
                                            <option value="1000" {{ request('per_page') == '1000' ? 'selected' : '' }}>
                                                1000</option>
                                        </select>
                                    </div>
                                    <div class="col">
                                        <button type="submit" class="btn btn-primary">Apply</button>
                                    </div>
                                </div>
                            </form>
                            <thead>
                                <tr>
                                    <th class="datatable-nosort">
                                        <a href="javascript:void(0);">Category Id
                                            @php
                                                $sortOrderById = "desc";
                                                if (request('sort_by') == 'id' || request('sort_by') == null) {
                                                    $sortOrderById = request('sort_order', 'desc') == 'asc' ? 'asc' : 'desc';
                                                }
                                                if (request('sort_by') != null && request('sort_by') != 'id') {
                                                    $sortOrderById = "";
                                                }
                                            @endphp
                                            <span
                                                class="sort-arrow sort-asc {{ $sortOrderById == 'asc' ? 'active' : '' }}"
                                                onclick="sortTable(event,'id','asc')"></span>
                                            <span
                                                class="sort-arrow sort-desc {{ $sortOrderById == 'desc' ? 'active' : '' }}"
                                                onclick="sortTable(event,'id','desc')"></span>
                                        </a>


                                    </th>
                                    <th class="datatable-nosort">
                                        <a href="javascript:void(0);">
                                            Category Name
                                            @php
                                                $sortOrderByCatName = "";
                                                if (request('sort_by') == 'category_name') {
                                                    $sortOrderByCatName = request('sort_order', 'desc') == 'asc' ? 'asc' : 'desc';
                                                }
                                            @endphp
                                            <span
                                                class="sort-arrow sort-asc {{ $sortOrderByCatName == 'asc' ? 'active' : '' }}"
                                                onclick="sortTable(event,'category_name','asc')"></span>
                                            <span
                                                class="sort-arrow sort-desc {{ $sortOrderByCatName == 'desc' ? 'active' : '' }}"
                                                onclick="sortTable(event,'category_name','desc')"></span>
                                        </a>
                                    </th>
                                    <th class="datatable-nosort">Category Thumb</th>
                                    <th class="datatable-nosort">Sequence Number</th>
                                    <th class="datatable-nosort">Status</th>
                                    <th class="datatable-nosort">User</th>
                                    <th class="datatable-nosort">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($catArray as $cat)
                                    <tr>
                                        <td class="table-plus">{{$cat->id}}</td>

                                        <td>{{$cat->category_name}}</td>

                                        <td><img src="{{ config('filesystems.storage_url') }}{{$cat->category_thumb}}"
                                                width="100" /></td>

                                        <td>{{$cat->sequence_number}}</td>

                                        @if($cat->status == '1')
                                            <td>LIVE</td>
                                        @else
                                            <td>NOT LIVE</td>
                                        @endif
                                        <td>{{ $roleManager::getUploaderName($cat->emp_id) }}</td>
                                        <td>
                                            <a class="dropdown-item" href="edit_v_cat/{{$cat->id}}"><i
                                                    class="dw dw-edit2"></i> Edit</a>
                                            @if ($roleManager::isAdminOrManager(Auth::user()->id))
                                                <a class="dropdown-item" href="delete_v_cat/{{$cat->id}}"><i
                                                        class="dw dw-delete-3"></i> Delete</a>
                                            @endif

                                        </td>

                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                    <div class="row">
                        <div class="col-sm-12 col-md-7">
                            <div class="dataTables_info" role="status" aria-live="polite">
                                Showing {{ $catArray->firstItem() }} to {{ $catArray->lastItem() }} of
                                {{ $catArray->total() }} entries
                            </div>
                        </div>
                        <div class="col-sm-12 col-md-5">
                            <div class="dataTables_paginate paging_simple_numbers">
                                {{ $catArray->appends(request()->input())->links('pagination::bootstrap-4') }}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="{{ asset('assets/vendors/scripts/core.js')}}"></script>
    <script src="{{ asset('assets/vendors/scripts/script.min.js')}}"></script>
    <script src="{{ asset('assets/vendors/scripts/process.js')}}"></script>
    <script src="{{ asset('assets/vendors/scripts/layout-settings.js')}}"></script>
    <script src="{{ asset('assets/plugins/datatables/js/jquery.dataTables.min.js')}}"></script>
    <script src="{{ asset('assets/plugins/datatables/js/dataTables.bootstrap4.min.js')}}"></script>
    <script src="{{ asset('assets/plugins/datatables/js/dataTables.responsive.min.js')}}"></script>
    <script src="{{ asset('assets/plugins/datatables/js/responsive.bootstrap4.min.js')}}"></script>
    <!-- Datatable Setting js -->
    <script src="{{ asset('assets/vendors/scripts/datatable-setting.js')}}"></script>

    <script>
        const sortTable = (event, column, sortType) => {
            event.preventDefault();
            let url = new URL(window.location.href);
            url.searchParams.set('sort_by', column);
            url.searchParams.set('sort_order', sortType);
            window.location.href = url.toString();
        }
    </script>
</body>

</html>