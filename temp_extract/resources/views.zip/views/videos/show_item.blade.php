@inject('helperController', 'App\Http\Controllers\HelperController')
@inject('roleManager', 'App\Http\Controllers\Utils\RoleManager')
<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>Laravel</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

    <link rel="stylesheet" type="text/css" href="{{asset('assets/vendors/styles/core.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('assets/vendors/styles/icon-font.min.css')}}">
    <link rel="stylesheet" type="text/css"
        href="{{asset('assets/plugins/datatables/css/dataTables.bootstrap4.min.css')}}">
    <link rel="stylesheet" type="text/css"
        href="{{asset('assets/plugins/datatables/css/responsive.bootstrap4.min.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('assets/vendors/styles/style.css')}}">

    <style>
        .sort-arrow {
            margin-left: 0px;
        }

        .sort-arrow.active {
            color: #1739d1ec;
        }

        .sort-arrow {
            font-family: 'dropways';
            font-size: 14px;
            color: grey;
            /* Default color */
        }

        .sort-asc::before {
            content: "\eabb";
            /* Custom icon content for up arrow */
        }

        .sort-desc::before {
            content: "\eaba";
        }

        /* Active state with blue color */
        .sort-asc.active::before,
        .sort-desc.active::before {
            color: #1b00ff;
        }

        span.sort-arrow.sort-desc {
            margin-left: -7px;
        }
    </style>
</head>

<body class="antialiased">

    @include('layouts.header')

    <div class="main-container">
        <div class="pd-ltr-20 xs-pd-20-10">
            <div class="min-height-200px">
                <div class="card-box mb-30">
                    <div class="pb-20">

                        <div class="pd-20">
                            <Button class="btn btn-primary" onclick="appSelection()"> Add New Item </a>
                        </div>

                        <form id="create_item_action" action="create_v_item" method="POST" enctype="multipart/form-data"
                            style="display: none;">
                            <input type="text" id="passingAppId" name="passingAppId">
                            @csrf
                        </form>

                        <table class="table table-striped mt-2">

                            <form method="GET" action="{{ route('show_v_item') }}" id="filter-form">
                                <div class="form-row">
                                    <div class="col">
                                        <input type="text" name="query" class="form-control" placeholder="Search..."
                                            value="{{ request('query') }}">
                                    </div>
                                    <div class="col">
                                        <select name="per_page" class="form-control">
                                            <option value="10" {{ request('per_page') == '10' ? 'selected' : '' }}>10
                                            </option>
                                            <option value="20" {{ request('per_page') == '20' ? 'selected' : '' }}>20
                                            </option>
                                            <option value="50" {{ request('per_page') == '50' ? 'selected' : '' }}>50
                                            </option>
                                            <option value="100" {{ request('per_page') == '100' ? 'selected' : '' }}>100
                                            </option>
                                            <option value="500" {{ request('per_page') == '500' ? 'selected' : '' }}>500
                                            </option>
                                            <option value="1000" {{ request('per_page') == '1000' ? 'selected' : '' }}>
                                                1000</option>
                                        </select>
                                    </div>
                                    <div class="col">
                                        <button type="submit" class="btn btn-primary">Apply</button>
                                    </div>
                                </div>
                            </form>
                            <thead>
                                <tr>
                                    <th>
                                        <a href="javascript:void(0);">Item Id
                                            @php
                                                $sortOrderById = "desc";
                                                if (request('sort_by') == 'id' || request('sort_by') == null) {
                                                    $sortOrderById = request('sort_order', 'desc') == 'asc' ? 'asc' : 'desc';
                                                }
                                                if (request('sort_by') != null && request('sort_by') != 'id') {
                                                    $sortOrderById = "";
                                                }
                                            @endphp
                                            <span
                                                class="sort-arrow sort-asc {{ $sortOrderById == 'asc' ? 'active' : '' }}"
                                                onclick="sortTable(event,'id','asc')"></span>
                                            <span
                                                class="sort-arrow sort-desc {{ $sortOrderById == 'desc' ? 'active' : '' }}"
                                                onclick="sortTable(event,'id','desc')"></span>
                                        </a>
                                    </th>
                                    <th>
                                        <a href="javascript:void(0);">User
                                            @php
                                                $sortOrderByEmpId = "";
                                                if (request('sort_by') == 'emp_id') {
                                                    $sortOrderByEmpId = request('sort_order', 'desc') == 'asc' ? 'asc' : 'desc';
                                                }
                                            @endphp
                                            <span
                                                class="sort-arrow sort-asc {{ $sortOrderByEmpId == 'asc' ? 'active' : '' }}"
                                                onclick="sortTable(event,'emp_id','asc')"></span>
                                            <span
                                                class="sort-arrow sort-desc {{ $sortOrderByEmpId == 'desc' ? 'active' : '' }}"
                                                onclick="sortTable(event,'emp_id','desc')"></span>
                                        </a>
                                    </th>
                                    <th>
                                        <a href="javascript:void(0);">Template Id
                                            @php
                                                $sortOrderByTemplateId = "";
                                                if (request('sort_by') == 'relation_id') {
                                                    $sortOrderByTemplateId = request('sort_order', 'desc') == 'asc' ? 'asc' : 'desc';
                                                }
                                            @endphp
                                            <span
                                                class="sort-arrow sort-asc {{ $sortOrderByTemplateId == 'asc' ? 'active' : '' }}"
                                                onclick="sortTable(event,'relation_id','asc')"></span>
                                            <span
                                                class="sort-arrow sort-desc {{ $sortOrderByTemplateId == 'desc' ? 'active' : '' }}"
                                                onclick="sortTable(event,'relation_id','desc')"></span>
                                        </a>
                                    </th>
                                    <th>
                                        <a href="javascript:void(0);">Category Name
                                            @php
                                                $sortOrderByCatName = "";
                                                if (request('sort_by') == 'category_id') {
                                                    $sortOrderByCatName = request('sort_order', 'desc') == 'asc' ? 'asc' : 'desc';
                                                }
                                            @endphp
                                            <span
                                                class="sort-arrow sort-asc {{ $sortOrderByCatName == 'asc' ? 'active' : '' }}"
                                                onclick="sortTable(event,'category_id','asc')"></span>
                                            <span
                                                class="sort-arrow sort-desc {{ $sortOrderByCatName == 'desc' ? 'active' : '' }}"
                                                onclick="sortTable(event,'category_id','desc')"></span>
                                        </a>
                                    </th>
                                    <th>
                                        <a href="javascript:void(0);">Video Name
                                            @php
                                                $sortOrderByVideoName = "";
                                                if (request('sort_by') == 'video_name') {
                                                    $sortOrderByVideoName = request('sort_order', 'desc') == 'asc' ? 'asc' : 'desc';
                                                }
                                            @endphp
                                            <span
                                                class="sort-arrow sort-asc {{ $sortOrderByVideoName == 'asc' ? 'active' : '' }}"
                                                onclick="sortTable(event,'video_name','asc')"></span>
                                            <span
                                                class="sort-arrow sort-desc {{ $sortOrderByVideoName == 'desc' ? 'active' : '' }}"
                                                onclick="sortTable(event,'video_name','desc')"></span>
                                        </a>
                                    </th>
                                    <th class="datatable-nosort">Video Thumb</th>
                                    @if ($roleManager::isAdmin(Auth::user()->user_type))
                                        <th>Views</th>
                                        <th>Purchases</th>
                                    @endif
                                    <th>Is Premium</th>
                                    <th>Status</th>
                                    <th class="datatable-nosort">Action</th>
                                </tr>
                            </thead>
                            <tbody id="item_table">
                                @foreach ($itemArray['item'] as $item)
                                    <tr>
                                        <td class="table-plus">{{$item->id}} ({{$item->string_id}})</td>

                                        <td>{{ $roleManager::getEmployeeName($item->emp_id) }}</td>

                                        <td class="table-plus">{{$item->relation_id}}</td>

                                        <td>{{ $helperController::getVCatName($item->category_id) }}</td>

                                        <td>{{ $item->video_name }}</td>

                                        <td><img src="{{ config('filesystems.storage_url') }}{{$item->video_thumb}}"
                                                width="100" /></td>

                                        @if ($roleManager::isAdmin(Auth::user()->user_type))
                                            <td>{{ $item->views }}</td>
                                            <td>{{ $helperController::getVPurchaseTemplateCount($item->string_id) }}</td>
                                        @endif

                                        @if($item->is_premium == '1')
                                            <td>TRUE</td>
                                        @else
                                            <td>FALSE</td>
                                        @endif

                                        @if($item->status == '1')
                                            <td>LIVE</td>
                                        @else
                                            <td>NOT LIVE</td>
                                        @endif
                                        <td>
                                            <a class="dropdown-item" href="edit_v_item/{{$item->id}}"><i
                                                    class="dw dw-edit2"></i> Edit</a>
                                            @if ($roleManager::isAdminOrManager(Auth::user()->id))
                                                <Button class="dropdown-item" onclick="set_delete_id('{{$item->id}}')"
                                                    data-backdrop="static" data-toggle="modal" data-target="#delete_model"><i
                                                        class="dw dw-delete-3"></i>Delete</Button>
                                            @endif
                                            <!-- <a class="dropdown-item" href="delete_v_item/{{$item->id}}"><i class="dw dw-delete-3"></i> Delete</a> -->
                                            <!--<a class="dropdown-item" data-toggle="modal" data-target="#Medium-modal" href="#"><i class="dw dw-delete-3"></i> Delete</a>-->
                                        </td>

                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="delete_model" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <input type="text" id="delete_id" name="delete_id" style="display: none;">
                <div class="modal-header">
                    <h4 class="modal-title" id="myLargeModalLabel">Delete</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                </div>
                <div class="modal-body">
                    <p> Are you sure you want to delete? </p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">No, Cancel</button>
                    <button type="button" class="btn btn-primary" onclick="delete_click()">Yes, Delete</button>
                </div>
            </div>
        </div>
    </div>

    <script src="{{asset('assets/vendors/scripts/core.js')}}"></script>
    <script src="{{asset('assets/vendors/scripts/script.min.js')}}"></script>
    <script src="{{asset('assets/vendors/scripts/process.js')}}"></script>
    <script src="{{asset('assets/vendors/scripts/layout-settings.js')}}"></script>
    <script src="{{asset('assets/plugins/datatables/js/jquery.dataTables.min.js')}}"></script>
    <script src="{{asset('assets/plugins/datatables/js/dataTables.bootstrap4.min.js')}}"></script>
    <script src="{{asset('assets/plugins/datatables/js/dataTables.responsive.min.js')}}"></script>
    <script src="{{asset('assets/plugins/datatables/js/responsive.bootstrap4.min.js')}}"></script>
    <!-- Datatable Setting js -->
    <script src="{{asset('assets/vendors/scripts/datatable-setting.js')}}"></script>

    <script>

        function set_delete_id($id) {
            $("#delete_id").val($id);
        }

        function delete_click() {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                }
            });

            id = $("#delete_id").val();
            var url = "{{route('v_item.delete', ":id")}}";
            url = url.replace(":id", id);
            $.ajax({
                url: url,
                type: 'POST',
                beforeSend: function () {
                    $('#delete_model').modal('toggle');
                },
                success: function (data) {
                    if (data.error) {
                        window.alert('error==>' + data.error);
                    } else {
                        location.reload();
                    }
                },
                error: function (error) {
                    window.alert(error.responseText);
                },
                cache: false,
                contentType: false,
                processData: false
            })
        }

        function appSelection() {
            $('#create_item_action').submit();
        }

        const sortTable = (event, column, sortType) => {
            event.preventDefault();
            let url = new URL(window.location.href);
            url.searchParams.set('sort_by', column);
            url.searchParams.set('sort_order', sortType);
            window.location.href = url.toString();
        }
    </script>
</body>

</html>