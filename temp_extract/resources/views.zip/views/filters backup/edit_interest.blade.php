    <input class="form-control" type="textname" name="interest_id" value="{{$dataArray['item']['id']}}" style="display: none"/>
    <div class="form-group">
		<h7>Interest</h7>
		<div class="input-group custom">
			<input type="text" class="form-control" placeholder="Interest Name" value="{{$dataArray['item']['name']}}" name="name" required="" />
		</div>
	</div>
	<div class="form-group">
		<h7>ID Name</h7>
		<div class="input-group custom">
			<input type="text" class="form-control" placeholder="ID Name" value="{{$dataArray['item']['id_name']}}" name="id_name" required="" />
		</div>
	</div>
    <div class="form-group">
		<h6>New Category</h6>
        <div class="col-sm-20" id="newCategory">
            <select class="custom-select2 form-control" multiple="multiple" data-style="btn-outline-primary" name="new_category_ids[]"  id="newEditCategoryIds" required>
                @foreach($dataArray['allCategories'] as $newCategory)
                    @if( \App\Http\Controllers\HelperController::stringContain($dataArray['item']->new_category_id, $newCategory->id))
                        <option value="{{ $newCategory->id }}" selected="">{{ $newCategory->category_name }}
                        </option>
                    @else
                        <option value="{{ $newCategory->id }}">{{ $newCategory->category_name }}</option>
                    @endif
                @endforeach
            </select>
        </div>
    </div>

	<div class="form-group">
		<h6>Status</h6>
		<div class="col-sm-20">
			<select id="status" class="selectpicker form-control" data-style="btn-outline-primary" name="status">
				<option value="1" {{($dataArray['item']['status'] == '1') ? 'selected' : ''}}>Active</option> <option value="0" {{($dataArray['item']['status'] == '0') ? 'selected' : ''}}>Disable</option>
			</select>
		</div>
	</div>
	<div class="row"> <div class="col-sm-12"> <button type="button" class="btn btn-primary btn-block" id="update_click">Update</button> </div> </div>
