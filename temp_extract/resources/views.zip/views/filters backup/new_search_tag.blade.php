@inject('helperController', 'App\Http\Controllers\HelperController')
<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="{{ csrf_token() }}" />

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

        <link rel="stylesheet" type="text/css" href="{{asset('assets/vendors/styles/core.css')}}">
        <link rel="stylesheet" type="text/css" href="{{asset('assets/vendors/styles/icon-font.min.css')}}">
        <link rel="stylesheet" type="text/css" href="{{asset('assets/plugins/datatables/css/dataTables.bootstrap4.min.css')}}">
        <link rel="stylesheet" type="text/css" href="{{asset('assets/plugins/datatables/css/responsive.bootstrap4.min.css')}}">
        <link rel="stylesheet" type="text/css" href="{{asset('assets/vendors/styles/style.css')}}">
        <link rel="stylesheet" type="text/css" href="{{asset('assets/vendors/styles/custom.css')}}">
    </head>
    <body class="antialiased">

        @include('layouts.header')

        <div class="main-container">
            <div id="loading_screen" style="display: none;">
                <div id="loader-wrapper">
                    <div id="loader"></div>
                    <div class="loader-section section-left"></div>
                    <div class="loader-section section-right"></div>
                </div>
            </div>

            <div class="pd-ltr-20 xs-pd-20-10">
                <div class="min-height-200px">
                    <div class="card-box mb-30">
                        <div class="pb-20">
                            <div class="pd-20">
                                <a href="#" class="btn btn-primary" data-backdrop="static" data-toggle="modal" data-target="#add_seach_tag_model" type="button">
                                Add Sub Category Tag </a>
                            </div>
                            <table class="data-table table stripe hover nowrap">
                                <thead>
                                    <tr>
                                        <th>Id</th>
                                        <th>User</th>
                                        <th>Name</th>
                                        <th>New Category</th>
                                        <th>Status</th>
                                        <th class="datatable-nosort">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($newSearchTags as $newSearchTag)
                                    <tr>
                                        <td class="table-plus">{{$newSearchTag->id}}</td>
                                        <td>{{ \App\Http\Controllers\HelperController::getUploaderName($newSearchTag->emp_id) }}</td>
                                        <td class="table-plus">{{$newSearchTag->name}}</td>

                                        @php
                                            $catNames = "";
                                            $categoryIds = json_decode($newSearchTag->new_category_id);
                                            for ($i = 0; $i < count($categoryIds); $i++) {
                                                $cn = $helperController::getNewCatName($categoryIds[$i]);
                                                if ($i == count($categoryIds) - 1) {
                                                    $catNames = $catNames . $cn;
                                                } else {
                                                    $catNames = $catNames . $cn . ", ";
                                                }
                                            }
                                        @endphp
                                    
                                        <td class="table-plus">{{ $catNames }}</td>
                                        
                                        @if($newSearchTag->status =='1')
                                            <td>Active</td>
                                        @else
                                            <td>Disabled</td>
                                        @endif
                                        <td>
                                            <Button class="dropdown-item" onclick="edit_click('{{$newSearchTag->id}}', '{{$newSearchTag->name}}', '{{$newSearchTag->status}}','{{$newSearchTag->new_category_id}}')" data-backdrop="static" data-toggle="modal" data-target="#edit_search_tag_model"><i class="dw dw-edit2" ></i> Edit</Button>
                                            @if ( $helperController::getUserType(Auth::user()->user_type) == "Admin" || $helperController::getUserType(Auth::user()->user_type) == "Manager" )
                                            <Button class="dropdown-item" onclick="delete_click('{{$newSearchTag->id}}')"><i class="dw dw-delete-3" ></i> Delete</Button>
                                            @endif
                                        </td>
                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade"
            id="add_seach_tag_model"
            tabindex="-1"
            role="dialog"
            aria-labelledby="myLargeModalLabel"
            aria-hidden="false">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                   <div class="modal-header">
                        <h5 class="modal-title" id="myLargeModalLabel">Add Sub Category Tag</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    </div>
                    <div class="modal-body">
                        <form method="post" id="add_new_tag_form" enctype="multipart/form-data">
                            @csrf
                            <div class="form-group">
                                <h7>Name</h7>
                                <div class="input-group custom">
                                    <input type="text" class="form-control" placeholder="Sub Category Tag" id="searchTagName" name="name" required="" />
                                </div>
                            </div>
                            <div class="form-group">
                                <h7>ID Name</h7>
                                <div class="input-group custom">
                                    <input type="text" class="form-control" placeholder="ID Name" id="searchTagIDName" name="id_name" required="" />
                                </div>
                            </div>
                            <div class="col-md-12 col-sm-12" style="height: auto;padding: 0;">
                                <div class="form-group category-dropbox-wrap">
                                    <h7>Select New Category</h7>
                                    <div class="input-subcategory-dropbox unset-bottom-border" id="parentCategoryInput" style="height: auto; border-bottom: 1px solid #ced4da;"><span>== none ==</span> <i style="font-size:18px" class="fa down-arrow-dropbox">&#xf107;</i></div>
                                        <div class="custom-dropdown parent-category-input">
                                            <input type="text" id="categoryFilter" class="form-control-file form-control" placeholder="Search categories">
                                            <ul class="dropdown-menu-ul filter-wrap-list">
                                                <li class="category none-option">== none ==</li>
                                                @foreach ($allNewCategories as $category)
                                                    @php
                                                        $classBold = (!empty($category['subcategories']) && isset($category['subcategories'][0])) ? "has-children" : "has-parent";
                                                        $selected = (isset($dataArray['item']['new_category_id']) && $dataArray['item']['new_category_id'] == $category['id']) ? "selected" : "";
                                                    @endphp
                                                    <li class="category {{$classBold}} {{$selected}}" data-id="{{$category['id']}}" data-catname="{{$category['category_name']}}">
                                                        <span>{{ $category['category_name'] }}</span>
                                                        @if (!empty($category['subcategories']))
                                                            <ul class="subcategories">
                                                                @foreach ($category['subcategories'] as $subcategory)
                                                                    @include('partials.subcategory-optgroup', ['subcategory' => $subcategory,'sub_category_id' => $subcategory['id'],'sub_category_name' => $subcategory['category_name']])
                                                                @endforeach
                                                            </ul>
                                                        @endif
                                                    </li>
                                                @endforeach
                                            </ul>
                                        </div>
                                        <div class="popup-container" id="newCategoryRequiredPopup">
                                            <p><span class="required-icon">!</span>Please select a new category.</p>
                                        </div>
                                        <input type="hidden" name="new_category_id" value="0">

                                </div>
                            </div>
                            <div class="form-group" style="margin-top:40px;">
                                <h7>Status</h7>
                                <div class="col-sm-20">
                                    <select id="status" class="selectpicker form-control"
                                            data-style="btn-outline-primary"
                                            name="status">
                                        <option value="1">Active</option>
                                        <option value="0">Disable</option>
                                    </select>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-sm-12">
                                    <input class="btn btn-primary btn-block" type="submit" name="submit">
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <div
            class="modal fade"
            id="edit_search_tag_model"
            tabindex="-1"
            role="dialog"
            aria-labelledby="myLargeModalLabel"
            aria-hidden="false">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                   <div class="modal-header">
                        <h5 class="modal-title" id="myLargeModalLabel">Edit Sub Category Tag</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    </div>

                    <div class="modal-body" id="update_model">
                        <form method="post" id="edit_tag_form" enctype="multipart/form-data">
                        </form>
                    </div>

                </div>
            </div>
        </div>

        <script src="{{asset('assets/vendors/scripts/core.js')}}"></script>
        <script src="{{asset('assets/vendors/scripts/script.min.js')}}"></script>
        <script src="{{asset('assets/vendors/scripts/process.js')}}"></script>
        <script src="{{asset('assets/vendors/scripts/layout-settings.js')}}"></script>
        <script src="{{asset('assets/plugins/datatables/js/jquery.dataTables.min.js')}}"></script>
        <script src="{{asset('assets/plugins/datatables/js/dataTables.bootstrap4.min.js')}}"></script>
        <script src="{{asset('assets/plugins/datatables/js/dataTables.responsive.min.js')}}"></script>
        <script src="{{asset('assets/plugins/datatables/js/responsive.bootstrap4.min.js')}}"></script>
        <!-- Datatable Setting js -->
        <script src="{{asset('assets/vendors/scripts/datatable-setting.js')}}"></script>


        <script>

            var catIds = [];
            var catNames = [];

            $('#add_seach_tag_model').on('show.bs.modal', function (e) {
                resetSelection();
            });

            $('#add_seach_tag_model').on('shown.bs.modal', function (e) {
                resetSelection();
            });

            $('#add_seach_tag_model').on('hide.bs.modal', function (e) {
                resetSelection();
            });

            $('#add_seach_tag_model').on('hidden.bs.modal', function (e) {
                resetSelection();
            });

            function edit_click(id, search_tag, status,new_category_id) {
                event.preventDefault();
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                    }
                });

                 $.ajax({
                    url: "{{ route('new_search_tags.edit', ':id') }}".replace(':id', id),
                    type: 'GET',
                    beforeSend: function () {
                        var loading_screen = document.getElementById("loading_screen");
                        loading_screen.style.display = "block";
                    },
                    success: function (data) {
                        catIds = [];
                        catNames = [];
                        var loading_screen = document.getElementById("loading_screen");
                        loading_screen.style.display = "none";
                        if (data.status == true) {
                            catIds = data.id.map(Number);
                            catNames = catNames.concat(data.name);
                            $("#edit_tag_form").html(data.view);
                        }
                    },
                    error: function (error) {
                        var loading_screen = document.getElementById("loading_screen");
                        loading_screen.style.display = "none";
                        window.alert(error.responseText);
                    },
                    cache: false,
                    contentType: false,
                    processData: false
                })
            }

            $('#add_new_tag_form').on('submit', function (event) {
                event.preventDefault();
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                    }
                });
                var formData = new FormData(this);

                if (formData.get('new_category_id') == "0") {
                    window.alert("Please select category id")
                    return;
                }

                 $.ajax({
                    url: "{{route('new_search_tags.store')}}",
                    type: 'POST',
                    data: formData,
                    beforeSend: function () {
                        var loading_screen = document.getElementById("loading_screen");
                        loading_screen.style.display = "block";
                    },
                    success: function (data) {
                        var loading_screen = document.getElementById("loading_screen");
                        loading_screen.style.display = "none";
                        if (data.error) {
                            window.alert('error==>'+data.error);
                        } else {
                            location.reload();
                        }
                    },
                    error: function (error) {
                        var loading_screen = document.getElementById("loading_screen");
                        loading_screen.style.display = "none";
                        window.alert(error.responseText);
                    },
                    cache: false,
                    contentType: false,
                    processData: false
                })
            });

            $(document).on('click', '#update_click', function () {
               event.preventDefault();

                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                    }
                });

                var formData = new FormData(document.getElementById("edit_tag_form"));
                formData.append('_method', 'PUT');
                var status = formData.get("search_tag_id");

                if (formData.get('new_category_id') == "0") {
                    window.alert("Please select category id")
                    return;
                }

                var url ="{{route('new_search_tags.update', ":status")}}";
                url = url.replace(":status", status);
                $.ajax({
                    url: url,
                    type: 'POST',
                    data: formData,
                    beforeSend: function () {
                        var loading_screen = document.getElementById("loading_screen");
                        loading_screen.style.display = "block";
                    },
                    success: function (data) {
                        var loading_screen = document.getElementById("loading_screen");
                        loading_screen.style.display = "none";
                        if (data.error) {
                            window.alert('error==>'+data.error);
                        } else {
                            location.reload();
                        }

                    },
                    error: function (error) {
                        var loading_screen = document.getElementById("loading_screen");
                        loading_screen.style.display = "none";
                        window.alert(error.responseText);
                    },
                    cache: false,
                    contentType: false,
                    processData: false
                })
            });

            function delete_click(id) {
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                    }
                });
                var url ="{{route('new_search_tags.destroy', ":id")}}";
                url = url.replace(":id", id);
                $.ajax({
                    url: url,
                    type: 'DELETE',
                    beforeSend: function () {
                        var loading_screen = document.getElementById("loading_screen");
                        loading_screen.style.display = "block";
                    },
                    success: function (data) {
                        var loading_screen = document.getElementById("loading_screen");
                        loading_screen.style.display = "none";
                        if (data.error) {
                            window.alert(data.error);
                        } else {
                            location.reload();
                        }
                    },
                    error: function (error) {
                        var loading_screen = document.getElementById("loading_screen");
                        loading_screen.style.display = "none";
                        window.alert(error.responseText);
                    },
                    cache: false,
                    contentType: false,
                    processData: false
                })
            }
            /* New Category */
            $(document).on('click','#parentCategoryInput',function(){
                $("#newCategoryRequiredPopup").hide();
                if( $('.parent-category-input').hasClass('show') ){
                    $('.parent-category-input').removeClass('show');
                }else{
                    $(".parent-category-input").addClass('show');
                }
            });

            $(document).on("click", ".category", function(event) {
                addOrRemove($(this));
            });

            $(document).on("click", ".subcategory", function(event) {
                event.stopPropagation();
                addOrRemove($(this));
            });

            $(document).on('click', function(e) {
                if (!$(e.target).closest('.form-group.category-dropbox-wrap').length) {
                    $('.custom-dropdown.parent-category-input.show').removeClass('show');
                }
            });

            $(document).on("click","li.category.none-option",function(){
                catIds = [];
                catNames = [];
                $(".category").removeClass("selected");
                $(".subcategory").removeClass("selected");

                $("input[name='new_category_id']").val("0");
                $('.parent-category-input').removeClass('show');
                $("#parentCategoryInput span").html('== none ==');
            });

            $('#categoryFilter').on('input', function() {
                var filterValue = $(this).val().toLowerCase();
                $('.category, .subcategory').each(function() {
                    var text = $(this).text().toLowerCase();
                    if (text.indexOf(filterValue) > -1) {
                        $(this).show();
                    } else {
                        $(this).hide();
                    }
                });
            });


            const toTitleCase = str => str.replace(/\b\w+/g, txt => txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase());

            $(document).on("keypress","#searchTagName", function() {
                const titleString = toTitleCase($(this).val());
                $("#searchTagIDName").val(`${titleString.toLowerCase().replace(/\s+/g, '-')}`);
                $(this).val(titleString);
            });

            $(document).on("keypress","#editSearchTagName", function() {
                const titleString = toTitleCase($(this).val());
                $("#editSearchTagIDName").val(`${titleString.toLowerCase().replace(/\s+/g, '-')}`);
                $(this).val(titleString);
            });


            function addOrRemove(ele) {
                var id = ele.data('id');
                var catname = ele.data('catname');

                var newIds = "";
                var newNames = "";

                if (catname) {

                    var indexOfId = catIds.indexOf(id);
                    var indexOfName = catNames.indexOf(catname);

                    if (indexOfId !== -1) {
                        catIds.splice(indexOfId, 1);
                        ele.removeClass("selected");
                    } else {
                        catIds.push(id);
                        ele.addClass("selected");
                    }

                    if (indexOfName !== -1) {
                        catNames.splice(indexOfName, 1);
                        ele.removeClass("selected");
                    } else {
                        catNames.push(catname);
                        ele.addClass("selected");
                    }

                    for (var i = 0; i < catIds.length; i++) {
                        if (i == catIds.length - 1) {
                            newIds = newIds + catIds[i];
                            newNames = newNames + catNames[i];
                        } else {
                            newIds = newIds + catIds[i] + ", ";
                            newNames = newNames + catNames[i] + ", ";
                        }
                    }

                } else {
                    catIds = [];
                    catNames = [];
                    newIds = "0";
                    newNames = "== none ==";
                }

                $("input[name='new_category_id']").val(newIds);
                $("#parentCategoryInput span").html(newNames);

                $('.parent-category-input').removeClass('show');
            }

            function resetSelection() {

                catIds = [];
                catNames = [];

                $(".category").removeClass("selected");
                $(".subcategory").removeClass("selected");

                $("input[name='new_category_id']").val("0");
                $("#parentCategoryInput span").html("== none ==");

                $('.parent-category-input').removeClass('show');
            }
        </script>
    </body>
</html>
