@inject('helperController', 'App\Http\Controllers\HelperController')
<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="{{ csrf_token() }}" />

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

        <link rel="stylesheet" type="text/css" href="{{asset('assets/vendors/styles/core.css')}}">
        <link rel="stylesheet" type="text/css" href="{{asset('assets/vendors/styles/icon-font.min.css')}}">
        <link rel="stylesheet" type="text/css" href="{{asset('assets/plugins/datatables/css/dataTables.bootstrap4.min.css')}}">
        <link rel="stylesheet" type="text/css" href="{{asset('assets/plugins/datatables/css/responsive.bootstrap4.min.css')}}">
        <link rel="stylesheet" type="text/css" href="{{asset('assets/vendors/styles/style.css')}}">
    </head>
    <body class="antialiased">

        @include('layouts.header')

        <div class="main-container">
            <div id="loading_screen" style="display: none;">
                <div id="loader-wrapper">
                    <div id="loader"></div>
                    <div class="loader-section section-left"></div>
                    <div class="loader-section section-right"></div>
                </div>
            </div>

            <div class="pd-ltr-20 xs-pd-20-10">
                <div class="min-height-200px">
                    <div class="card-box mb-30">
                        <div class="pb-20">

                            <div class="pd-20">
                                <a href="#" class="btn btn-primary" data-backdrop="static" data-toggle="modal" data-target="#add_lang_model" type="button">
                                Add Language </a>
                            </div>
                            <table class="data-table table stripe hover nowrap">
                                <thead>
                                    <tr>
                                        <th>Id</th>
                                        <th>Name</th>
                                        <th>ID Name</th>
                                        <th>Status</th>
                                        <th class="datatable-nosort">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($langArray as $lang)
                                    <tr>
                                        <td class="table-plus">{{$lang->id}}</td>
                                        <td class="table-plus">{{$lang->name}}</td>
                                        <td class="table-plus">{{$lang->id_name}}</td>
                                        @if($lang->status =='1')
                                              <td>Active</td>
                                        @else
                                              <td>Disabled</td>
                                        @endif

                                        <td>
                                            <Button class="dropdown-item" onclick="edit_click('{{$lang->id}}', '{{$lang->name}}', '{{$lang->status}}','{{$lang->id_name}}')" data-backdrop="static" data-toggle="modal" data-target="#edit_lang_model"><i class="dw dw-edit2" ></i> Edit</Button>
                                            @if ( $helperController::getUserType(Auth::user()->user_type) == "Admin" || $helperController::getUserType(Auth::user()->user_type) == "Manager" )
                                                <Button class="dropdown-item" onclick="delete_click('{{$lang->id}}')"><i class="dw dw-delete-3" ></i> Delete</Button>
                                            @endif
                                        </td>
                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div
            class="modal fade"
            id="add_lang_model"
            tabindex="-1"
            role="dialog"
            aria-labelledby="myLargeModalLabel"
            aria-hidden="false">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                   <div class="modal-header">
                        <h5 class="modal-title" id="myLargeModalLabel">Add Language</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    </div>

                    <div class="modal-body">
                            <form method="post" id="add_lang_form" enctype="multipart/form-data">
                            @csrf
                            <div class="form-group">
                                <h7>Name</h7>
                                <div class="input-group custom">
                                    <input type="text" class="form-control" placeholder="Language Name" name="name" id="languageName" required="" />
                                </div>
                            </div>

                            <div class="form-group">
                                <h7>ID Name</h7>
                                <div class="input-group custom">
                                    <input type="text" class="form-control" placeholder="ID Name" id="languageIDName" name="id_name" required="" />
                                </div>
                            </div>

                            <div class="form-group">
                                <h6>Status</h6>
                                <div class="col-sm-20">
                                    <select id="status" class="selectpicker form-control"
                                            data-style="btn-outline-primary"
                                            name="status">
                                        <option value="1">Active</option>
                                        <option value="0">Disable</option>
                                    </select>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-sm-12">
                                    <input class="btn btn-primary btn-block" type="submit" name="submit">
                                </div>
                            </div>
                            </form>
                        </div>
                </div>
            </div>
        </div>

        <div
            class="modal fade"
            id="edit_lang_model"
            tabindex="-1"
            role="dialog"
            aria-labelledby="myLargeModalLabel"
            aria-hidden="false">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                   <div class="modal-header">
                        <h5 class="modal-title" id="myLargeModalLabel">Edit Language</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    </div>

                    <div class="modal-body" id="update_model">
                    </div>

                </div>
            </div>
        </div>

        <script src="{{asset('assets/vendors/scripts/core.js')}}"></script>
        <script src="{{asset('assets/vendors/scripts/script.min.js')}}"></script>
        <script src="{{asset('assets/vendors/scripts/process.js')}}"></script>
        <script src="{{asset('assets/vendors/scripts/layout-settings.js')}}"></script>
        <script src="{{asset('assets/plugins/datatables/js/jquery.dataTables.min.js')}}"></script>
        <script src="{{asset('assets/plugins/datatables/js/dataTables.bootstrap4.min.js')}}"></script>
        <script src="{{asset('assets/plugins/datatables/js/dataTables.responsive.min.js')}}"></script>
        <script src="{{asset('assets/plugins/datatables/js/responsive.bootstrap4.min.js')}}"></script>
        <!-- Datatable Setting js -->
        <script src="{{asset('assets/vendors/scripts/datatable-setting.js')}}"></script>


        <script>
            function edit_click($id, $lang_name, $status,$id_name) {
            $("#update_model").empty();

            let selectedActive = $status == "1" ? 'selected' : '';
            let selectedUnActive = $status == "0" ? 'selected' : '';

             html = '<form method="post" id="edit_lang_form" enctype="multipart/form-data"> @csrf <input class="form-control" type="textname" name="lang_id" value="'+$id+'" style="display: none"/> <div class="form-group"> <h7>Language Name</h7> <div class="input-group custom"><input type="text" class="form-control" placeholder="Language Name" value="'+$lang_name+'" id="editLangName" name="name" required="" /> </div> </div> <div class="form-group"> <h7>ID Name</h7> <div class="input-group custom"><input type="text" class="form-control" placeholder="ID Name" id="editLangIDName" value="'+$id_name+'" name="id_name" required="" /> </div> </div> <div class="form-group"> <h6>Status</h6> <div class="col-sm-20"> <select id="status" class="selectpicker form-control" data-style="btn-outline-primary" name="status"> <option value="1" '+selectedActive+'>Active</option> <option value="0" '+selectedUnActive+'>Disable</option> </select> </div> </div> <div class="row"> <div class="col-sm-12"> <button type="button" class="btn btn-primary btn-block" id="update_click">Update</button> </div> </div> </form>';
                $("#update_model").append(html);
            }

            $('#add_lang_form').on('submit', function (event) {
                event.preventDefault();
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                    }
                });

                var formData = new FormData(this);
                $.ajax({
                    url: 'submit_lang',
                    type: 'POST',
                    data: formData,
                    beforeSend: function () {
                        var loading_screen = document.getElementById("loading_screen");
                        loading_screen.style.display = "block";
                    },
                    success: function (data) {
                        var loading_screen = document.getElementById("loading_screen");
                        loading_screen.style.display = "none";
                        if (data.error) {
                            window.alert('error==>'+data.error);
                        } else {
                            location.reload();
                        }

                    },
                    error: function (error) {
                        var loading_screen = document.getElementById("loading_screen");
                        loading_screen.style.display = "none";
                        window.alert(error.responseText);
                    },
                    cache: false,
                    contentType: false,
                    processData: false
                })
            });

            $(document).on('click', '#update_click', function () {
                event.preventDefault();
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                    }
                });

                var formData = new FormData(document.getElementById("edit_lang_form"));
                var status = formData.get("lang_id");
                var url ="{{route('lang.update', ":status")}}";
                url = url.replace(":status", status);

                $.ajax({
                    url: url,
                    type: 'POST',
                    data: formData,
                    beforeSend: function () {
                        var loading_screen = document.getElementById("loading_screen");
                        loading_screen.style.display = "block";
                    },
                    success: function (data) {
                        var loading_screen = document.getElementById("loading_screen");
                        loading_screen.style.display = "none";
                        if (data.error) {
                            window.alert(data.error);
                        } else {
                            location.reload();
                        }

                    },
                    error: function (error) {
                        var loading_screen = document.getElementById("loading_screen");
                        loading_screen.style.display = "none";
                        window.alert(error.responseText);
                    },
                    cache: false,
                    contentType: false,
                    processData: false
                })
            });

            function delete_click(id) {

                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                    }
                });

                var url ="{{route('lang.delete', ":id")}}";
                url = url.replace(":id", id);
                $.ajax({
                    url: url,
                    type: 'POST',
                    beforeSend: function () {
                        var loading_screen = document.getElementById("loading_screen");
                        loading_screen.style.display = "block";
                    },
                    success: function (data) {
                        var loading_screen = document.getElementById("loading_screen");
                        loading_screen.style.display = "none";
                        if (data.error) {
                            window.alert('error==>'+data.error);
                        } else {
                            location.reload();
                        }
                    },
                    error: function (error) {
                        var loading_screen = document.getElementById("loading_screen");
                        loading_screen.style.display = "none";
                        window.alert(error.responseText);
                    },
                    cache: false,
                    contentType: false,
                    processData: false
                })
            }
            const toTitleCase = str => str.replace(/\b\w+/g, txt => txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase());

            $(document).on("keypress","#languageName", function() {
                const titleString = toTitleCase($(this).val());
                $("#languageIDName").val(`${titleString.toLowerCase().replace(/\s+/g, '-')}`);
                $(this).val(titleString);
            });

            $(document).on("keypress","#editLangName", function() {
                const titleString = toTitleCase($(this).val());
                $("#editLangIDName").val(`${titleString.toLowerCase().replace(/\s+/g, '-')}`);
                $(this).val(titleString);
            });
        </script>
    </body>
</html>
