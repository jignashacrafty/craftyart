<input class="form-control" type="textname" name="theme_id" value="{{$dataArray['item']['id']}}" style="display: none"/>
	<div class="form-group">
		<h7>Theme Name</h7>
		<div class="input-group custom">
			<input type="text" class="form-control" placeholder="Theme Name" value="{{$dataArray['item']['name']}}" name="name" required="" />
		</div>
	</div>
	<div class="form-group">
		<h7>ID Name</h7>
		<div class="input-group custom">
			<input type="text" class="form-control" placeholder="ID Name" value="{{$dataArray['item']['id_name']}}" name="id_name" required="" />
		</div>
	</div>
    <div class="col-md-12 col-sm-12" style="height: 46px;padding: 0;margin-bottom: 38px;">
        <div class="form-group category-dropbox-wrap">
            <h7>Select New Category</h7>
            <div class="input-subcategory-dropbox unset-bottom-border" id="parentCategoryInput" style="border-bottom: 1px solid #ced4da;"><span>

                @if ( !empty($dataArray['item']) )
                    {{ App\Http\Controllers\HelperController::getNewCatName( $dataArray['item']['new_category_id'] ) }}
                @else
                    {{ "== none ==" }}
                @endif

            </span> <i style="font-size:18px" class="fa down-arrow-dropbox">&#xf107;</i></div>
                <div class="custom-dropdown parent-category-input">
                    <input type="text" id="categoryFilter" class="form-control-file form-control" placeholder="Search categories">

                    <ul class="dropdown-menu-ul filter-wrap-list">
                        <li class="category none-option">== none ==</li>
                        @foreach ($dataArray['allCategories'] as $category)
                            @php
                                $classBold = (!empty($category['subcategories']) && isset($category['subcategories'][0])) ? "has-children" : "has-parent";
                                $selected = (isset($dataArray['item']['new_category_id']) && $dataArray['item']['new_category_id'] == $category['id']) ? "selected" : "";
                            @endphp
                            <li class="category {{$classBold}} {{$selected}}" data-id="{{$category['id']}}" data-catname="{{$category['category_name']}}">
                                <span>{{ $category['category_name'] }}</span>
                                @if (!empty($category['subcategories']))
                                    <ul class="subcategories">
                                        @foreach ($category['subcategories'] as $subcategory)
                                            @include('partials.subcategory-optgroup', ['subcategory' => $subcategory,'sub_category_id' => $subcategory['id'],'sub_category_name' => $subcategory['category_name']])
                                        @endforeach
                                    </ul>
                                @endif
                            </li>
                        @endforeach
                    </ul>
                </div>
                <div class="popup-container" id="newCategoryRequiredPopup">
                    <p><span class="required-icon">!</span>Please select a new category.</p>
                </div>
                <input type="hidden" name="new_category_id" value="{{$dataArray['item']['new_category_id']}}">

        </div>
    </div>
	<div class="form-group">
		<h6>Status</h6>
		<div class="col-sm-20">
			<select id="status" class="selectpicker form-control" data-style="btn-outline-primary" name="status">
				<option value="1" {{$dataArray['item']['status'] == "1" ? "selected" : ""}}>Active</option> <option value="0" {{$dataArray['item']['status'] == "0" ? "selected" : ""}}>Disable</option>
			</select>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-12">
			<button type="button" class="btn btn-primary btn-block" id="update_click">Update</button>
		</div>
	</div>
