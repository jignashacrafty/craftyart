@inject('roleManager', 'App\Http\Controllers\Utils\RoleManager')
@guest
@else
<style>
    /* Custom styles for the sidebar */
    .selectSubMenu {
        color: #fff;
        background-color: rgba(0, 0, 0, 0.4);
    }
    .left-side-bar.open {
        left: -281px;
    }
</style>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet" />
<div class="header">
    <div class="header-left">
        <div class="menu-icon dw dw-menu"></div>
    </div>
    <div class="header-right pd-ltr-20">
        </i> {{ Auth::user()->name }} &nbsp &nbsp &nbsp</i>
        <a href="{{ route('logout') }}" onclick="event.preventDefault();document.getElementById('logout-form').submit();"><i class="dw dw-logout"></i>{{ __('Log Out') }}
        </a>
        <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
            @csrf
        </form>
    </div>
</div>
@endguest
<div class="left-side-bar">
    <div class="brand-logo">
        <a href="{{route('dashboard')}}">
            <img src="{{asset('assets/vendors/images/deskapp-logo.svg')}}" alt="" class="dark-logo">
            <img src="{{asset('assets/vendors/images/deskapp-logo-white.svg')}}" alt="" class="light-logo">
        </a>
        <div class="close-sidebar" data-toggle="left-sidebar-close">
            <i class="ion-close-round"></i>
        </div>
    </div>
    <div class="menu-block customscroll">
        <div class="sidebar-menu">
            <ul id="accordion-menu">

                @if ( $roleManager::isManager(Auth::user()->user_type))
                    <li class="dropdown {{( Route::currentRouteName() == 'dashboard' ) ? 'show' : ''}}">
                        <a href="javascript:;" class="dropdown-toggle">
                            <span class="micon"><img src="{{asset('assets/vendors/images/menu_icon/Dashboard.svg')}}" alt=""></span><span class="mtext">Dashboard</span>
                        </a>
                        <ul class="submenu" style="display: {{ Route::currentRouteName() == 'dashboard' ? 'block':'none' }};">
                            @if ( Route::currentRouteName() == 'dashboard' && Request::segment(2) == '1' )
                                <li>
                                    <a href="{{route('dashboard',1)}}" class="selectSubMenu">All Data</a>
                                </li>
                                <li>
                                    <a href="{{route('dashboard')}}">Your Data</a>
                                </li>
                            @else
                                <li>
                                    <a href="{{route('dashboard',1)}}">All Data</a>
                                </li>
                                <li>
                                    <a href="{{route('dashboard')}}" class="{{ (Route::currentRouteName() == 'dashboard') ? 'selectSubMenu' : '' }}">Your Data</a>
                                </li>
                            @endif
                        </ul>
                    </li>
                @else
                    <li class="dropdown">
                        <a href="{{route('dashboard')}}" class="dropdown-toggle no-arrow {{ ( Route::currentRouteName() == 'dashboard' ) ? 'selectSubMenu' : '' }}">
                            <span class="micon"><img src="{{asset('assets/vendors/images/menu_icon/Dashboard.svg')}}" alt=""></span><span class="mtext">Dashboard</span>
                        </a>
                    </li>
                @endif

                <li class="dropdown {{( Route::currentRouteName() == 'show_fonts' || Route::currentRouteName() == 'font_families' || Route::currentRouteName() == 'font_list' || Route::currentRouteName() == 'create_font' || Route::currentRouteName() == 'edit_font' ) ? 'show' : ''}}">
                    <a href="javascript:;" class="dropdown-toggle">
                        <span class="micon"><img src="{{asset('assets/vendors/images/menu_icon/Fonts.svg')}}" alt=""></span><span class="mtext">Fonts</span>
                    </a>
                    <ul class="submenu" style="display: {{ Route::currentRouteName() == 'show_fonts' || Route::currentRouteName() == 'font_families' || Route::currentRouteName() == 'font_list' || Route::currentRouteName() == 'create_font' || Route::currentRouteName() == 'edit_font' ? 'block':'none' }};">
                        <li><a href="{{route('show_fonts')}}" class="{{ (Route::currentRouteName() == 'show_fonts' || Route::currentRouteName() == 'create_font' || Route::currentRouteName() == 'edit_font') ? 'selectSubMenu' : '' }}">Mobile Fonts</a></li>
                        <li>
                            <a href="{{route('font_families')}}" class="{{ (Route::currentRouteName() == 'font_families') ? 'selectSubMenu' : '' }}">Web Font Familes</a>
                        </li>
                        <li><a href="{{route('font_list')}}" class="{{ (Route::currentRouteName() == 'font_list') ? 'selectSubMenu' : '' }}">Web Font List</a></li>
                    </ul>
                </li>

                <!-- @if ($roleManager::isAdmin(Auth::user()->user_type))
                <li class="dropdown">
                    <a href="{{route('show_app')}}" class="dropdown-toggle no-arrow {{ ( Route::currentRouteName() == 'show_app' ) ? 'selectSubMenu' : '' }}">
                        <span class="micon bi bi-house"></span>
                        <span class="mtext">Application</span>
                    </a>
                </li>
                @endif -->

                <li class="dropdown {{( Route::currentRouteName() == 'show_v_cat' || Route::currentRouteName() == 'show_v_item' || Route::currentRouteName() == 'create_v_cat' || Route::currentRouteName() == 'edit_v_cat' || Route::currentRouteName() == 'create_v_item' || Route::currentRouteName() == 'edit_v_item' ) ? 'show' : '' }}">
                    <a href="javascript:;" class="dropdown-toggle">
                        <span class="micon"><img src="{{asset('assets/vendors/images/menu_icon/Video.svg')}}" alt=""></span><span class="mtext">Video</span>
                    </a>
                    <ul class="submenu" style="display:{{( Route::currentRouteName() == 'show_v_cat' || Route::currentRouteName() == 'show_v_item'  || Route::currentRouteName() == 'create_v_cat' || Route::currentRouteName() == 'edit_v_cat' || Route::currentRouteName() == 'create_v_item' || Route::currentRouteName() == 'edit_v_item') ? 'block' : 'none' }};">
                        <li><a href="{{route('show_v_cat')}}" class="{{ (Route::currentRouteName() == 'show_v_cat' || Route::currentRouteName() == 'create_v_cat' || Route::currentRouteName() == 'edit_v_cat') ? 'selectSubMenu' : '' }}">Categories</a></li>
                        <li><a href="{{route('show_v_item')}}" class="{{ (Route::currentRouteName() == 'show_v_item' || Route::currentRouteName() == 'create_v_item' || Route::currentRouteName() == 'edit_v_item') ? 'selectSubMenu' : '' }}">Templates</a></li>
                    </ul>
                </li>
                {{-- @endif --}}
                <li class="dropdown {{ ( Route::currentRouteName() == 'show_style' || Route::currentRouteName() == 'show_theme'  || Route::currentRouteName() == 'show_keyword' || Route::currentRouteName() == 'show_search_tag' || Route::currentRouteName() == 'show_interest' || Route::currentRouteName() == 'show_lang' || Route::currentRouteName() == 'sizes.index' || Route::currentRouteName() == 'colors.index' || Route::currentRouteName() == 'religions.index' || Route::currentRouteName() == "new_search_tags.index")  ? 'show' : '' }}">
                    <a href="javascript:;" class="dropdown-toggle">
                        <span class="micon"><img src="{{asset('assets/vendors/images/menu_icon/Filter.svg')}}" alt=""></span><span class="mtext">Filters</span>
                    </a>
                    <ul class="submenu" style="display:{{ ( Route::currentRouteName() == 'show_style' || Route::currentRouteName() == 'show_theme'  || Route::currentRouteName() == 'show_keyword' || Route::currentRouteName() == 'show_search_tag' || Route::currentRouteName() == 'show_lang' || Route::currentRouteName() == 'sizes.index' || Route::currentRouteName() == 'colors.index' || Route::currentRouteName() == 'religions.index' || Route::currentRouteName() == 'show_interest' || Route::currentRouteName() == 'sizes.create' || Route::currentRouteName() == 'sizes.edit' || Route::currentRouteName() == "new_search_tags.index") ? 'block' : 'none' }};">
                        <li><a href="{{route('show_style')}}" class="{{ (Route::currentRouteName() == 'show_style') ? 'selectSubMenu' : '' }}">Style</a></li>
                        <li><a href="{{route('show_theme')}}" class="{{ (Route::currentRouteName() == 'show_theme') ? 'selectSubMenu' : '' }}">Theme</a></li>
                        <li><a href="{{route('show_keyword')}}" class="{{ (Route::currentRouteName() == 'show_keyword' || Route::currentRouteName() == 'create_keyword' || Route::currentRouteName() == 'edit_keyword') ? 'selectSubMenu' : '' }}">Special Keywords</a></li>
                        <li><a href="{{route('show_search_tag')}}" class="{{ (Route::currentRouteName() == 'show_search_tag') ? 'selectSubMenu' : '' }}">Search Tags</a></li>
                        <li><a href="{{route('new_search_tags.index')}}" class="{{ (Route::currentRouteName() == 'new_search_tags.index') ? 'selectSubMenu' : '' }}">Sub Category Tags</a></li>
                        <li><a href="{{route('show_interest')}}" class="{{ (Route::currentRouteName() == 'show_interest') ? 'selectSubMenu' : '' }}">Interest</a></li>
                        <li><a href="{{route('show_lang')}}" class="{{ (Route::currentRouteName() == 'show_lang' || Route::currentRouteName() == 'sizes.create') ? 'selectSubMenu' : '' }}">Languages</a></li>
                        <li><a href="{{route('sizes.index')}}" class="{{ (Route::currentRouteName() == 'sizes.index' || Route::currentRouteName() == 'sizes.edit') ? 'selectSubMenu' : '' }}">Size</a></li>
                        {{-- <li><a href="{{route('colors.index')}}" class="{{ (Route::currentRouteName() == 'colors.index') ? 'selectSubMenu' : '' }}">Color</a></li> --}}
                        <li><a href="{{route('religions.index')}}" class="{{ (Route::currentRouteName() == 'religions.index') ? 'selectSubMenu' : '' }}">Relegion</a></li>
                    </ul>
                </li>
                <li>
                    <a href="{{route('create_editable_mode')}}" class="dropdown-toggle no-arrow {{ ( Route::currentRouteName() == 'create_editable_mode' ) ? 'selectSubMenu' : '' }}" >
                        <span class="micon bi bi-calendar4-week"></span><span class="mtext">Editable Title</span>
                    </a>
                </li>
            @if ($roleManager::onlySeoAccess(Auth::user()->user_type))
                  <li>
                    <a href="{{route('special_page.index')}}"
                    class="dropdown-toggle no-arrow {{ (Route::currentRouteName() == 'special_page') || Route::currentRouteName() == 'create_pages' ? 'selectSubMenu' : '' }}">
                    <span class="micon bi bi-calendar4-week"></span><span class="mtext">Special Page</span>
                    </a>
                  </li>
                @endif

                <li class="dropdown {{ ( Route::currentRouteName() == 'show_item' || Route::currentRouteName() == 'show_cat' || Route::currentRouteName() == 'show_new_cat'  || Route::currentRouteName() == 'create_item' || Route::currentRouteName() == 'create_item' ||  Route::currentRouteName() == 'edit_item' || Route::currentRouteName() == 'create_new_cat' || Route::currentRouteName() == 'create_cat' || Route::currentRouteName() == 'edit_cat' || Route::currentRouteName() == 'show_virtual_cat' || Route::currentRouteName() == 'create_virtual_cat' || Route::currentRouteName() == 'edit_virtual_cat') ? 'show' : '' }}">
                    <a href="javascript:;" class="dropdown-toggle">
                        <span class="micon"><img src="{{asset('assets/vendors/images/menu_icon/Template.svg')}}" alt=""></span><span class="mtext">Templates</span>
                    </a>
                    <ul class="submenu" style="display:{{ ( Route::currentRouteName() == 'show_item' || Route::currentRouteName() == 'show_cat' || Route::currentRouteName() == 'show_new_cat' || Route::currentRouteName() == 'create_item' || Route::currentRouteName() == 'edit_item' || Route::currentRouteName() == 'create_new_cat' || Route::currentRouteName() == 'edit_new_cat' || Route::currentRouteName() == 'create_cat' || Route::currentRouteName() == 'edit_cat' || Route::currentRouteName() == 'show_virtual_cat' || Route::currentRouteName() == 'create_virtual_cat' || Route::currentRouteName() == 'edit_virtual_cat') ? 'block' : 'none' }};">
                        <li><a href="{{route('show_item')}}" class="{{ (Route::currentRouteName() == 'show_item' || Route::currentRouteName() == 'create_item' || Route::currentRouteName() == 'edit_item') ? 'selectSubMenu' : '' }}">Items</a></li>
                        <li><a href="{{route('show_cat')}}" class="{{ (Route::currentRouteName() == 'show_cat' || Route::currentRouteName() == 'create_cat' || Route::currentRouteName() == 'edit_cat') ? 'selectSubMenu' : '' }}">Categories</a></li>
                        <li><a href="{{route('show_new_cat')}}" class="{{ (Route::currentRouteName() == 'show_new_cat' || Route::currentRouteName() == 'create_new_cat' || Route::currentRouteName() == 'edit_new_cat') ? 'selectSubMenu' : '' }}">New Categories</a></li>
                        <li><a href="{{route('show_virtual_cat')}}"
                        class="{{ (Route::currentRouteName() == 'show_virtual_cat' || Route::currentRouteName() == 'create_virtual_cat' || Route::currentRouteName() == 'edit_virtual_cat') ? 'selectSubMenu' : '' }}">Virtual Categories</a></li>
                    </ul>
                </li>

                <li>
                    <a href="{{ route('raw_datas.index') }}"
                        class="dropdown-toggle no-arrow {{ Route::currentRouteName() == 'raw_datas' ? 'selectSubMenu' : '' }}">
                        <span class="micon bi bi-calendar4-week"></span><span class="mtext">Raw Datas</span>
                    </a>
                </li>
                
                <li
                    class="dropdown {{ Route::currentRouteName() == 'frame_categories.index' ||
                    Route::currentRouteName() == 'frame_items.index' ||
                    Route::currentRouteName() == 'show_sticker_cat.index' ||
                    Route::currentRouteName() == 'sticker_item.index' ||
                    Route::currentRouteName() == 'create_sticker_cat' ||
                    Route::currentRouteName() == 'edit_sticker_cat' ||
                    Route::currentRouteName() == 'create_sticker_item' ||
                    Route::currentRouteName() == 'edit_sticker_item' ||
                    Route::currentRouteName() == 'vector_categories.index' ||
                    Route::currentRouteName() == 'vector_items.index' ||
                    Route::currentRouteName() == 'audio_cat.index' ||
                    Route::currentRouteName() == 'audio_items.index' ||
                    Route::currentRouteName() == 'show_bg_cat.index' ||
                    Route::currentRouteName() == 'show_bg_item.index' ||
                    Route::currentRouteName() == 'create_bg_cat' ||
                    Route::currentRouteName() == 'edit_bg_cat' ||
                    Route::currentRouteName() == 'create_bg_item' ||
                    Route::currentRouteName() == 'edit_bg_item' ||
                    Route::currentRouteName() == 'video_cat.index' ||
                    Route::currentRouteName() == 'video_item.index' ||
                    Route::currentRouteName() == 'gif_categories.index' ||
                    Route::currentRouteName() == 'gif_items.index'
                        ? 'show'
                        : '' }}">
                    <a href="javascript:;" class="dropdown-toggle">
                        <span class="micon"><img src="{{ asset('assets/vendors/images/menu_icon/Elements.svg') }}"
                                alt=""></span>
                        <span class="mtext">Element</span>
                    </a>

                    {{-- Frame --}}
                    <ul class="submenu"
                        style="display: {{ Route::currentRouteName() == 'frame_categories.index' ||
                        Route::currentRouteName() == 'frame_items.index' ||
                        Route::currentRouteName() == 'show_bg_cat.index' ||
                        Route::currentRouteName() == 'show_bg_item.index' ||
                        Route::currentRouteName() == 'audio_cat.index' ||
                        Route::currentRouteName() == 'audio_items.index' ||
                        Route::currentRouteName() == 'vector_categories.index' ||
                        Route::currentRouteName() == 'vector_items.index' ||
                        Route::currentRouteName() == 'show_sticker_cat.index' ||
                        Route::currentRouteName() == 'sticker_item.index' ||
                        Route::currentRouteName() == 'video_cat.index' ||
                        Route::currentRouteName() == 'video_item.index' ||
                        Route::currentRouteName() == 'gif_categories.index' ||
                        Route::currentRouteName() == 'gif_items.index'
                            ? 'block'
                            : 'none' }}">
                        <li
                            class="dropdown {{ Route::currentRouteName() == 'frame_categories.index' || Route::currentRouteName() == 'frame_items.index'
                                ? 'show'
                                : '' }}">
                            <a href="javascript:;" class="dropdown-toggle">
                                <span class="micon"><img
                                        src="{{ asset('assets/vendors/images/menu_icon/Shape.svg') }}"
                                        alt=""></span>
                                <span class="mtext">Frame</span>
                            </a>
                            <ul class="submenu child"
                                style="display: {{ Route::currentRouteName() == 'frame_categories.index' || Route::currentRouteName() == 'frame_items.index'
                                    ? 'block'
                                    : 'none' }}">
                                <li><a href="{{ route('frame_categories.index') }}"
                                        class="{{ Route::currentRouteName() == 'frame_categories.index' ? 'selectSubMenu' : '' }}">Category</a>
                                </li>
                                <li><a href="{{ route('frame_items.index') }}"
                                        class="{{ Route::currentRouteName() == 'frame_items.index' ? 'selectSubMenu' : '' }}">Item</a>
                                </li>
                            </ul>
                        </li>
                    </ul>

                    {{-- Sticker --}}
                    <ul class="submenu"
                        style="display: {{ Route::currentRouteName() == 'show_sticker_cat.index' ||
                        Route::currentRouteName() == 'sticker_item.index' ||
                        Route::currentRouteName() == 'show_bg_cat.index' ||
                        Route::currentRouteName() == 'show_bg_item.index' ||
                        Route::currentRouteName() == 'audio_cat.index' ||
                        Route::currentRouteName() == 'audio_items.index' ||
                        Route::currentRouteName() == 'vector_categories.index' ||
                        Route::currentRouteName() == 'vector_items.index' ||
                        Route::currentRouteName() == 'frame_categories.index' ||
                        Route::currentRouteName() == 'frame_items.index' ||
                        Route::currentRouteName() == 'video_cat.index' ||
                        Route::currentRouteName() == 'video_item.index' ||
                        Route::currentRouteName() == 'gif_categories.index' ||
                        Route::currentRouteName() == 'gif_items.index'
                            ? 'block'
                            : 'none' }}">
                        <li
                            class="dropdown {{ Route::currentRouteName() == 'show_sticker_cat.index' || Route::currentRouteName() == 'sticker_item.index'
                                ? 'show'
                                : '' }}">
                            <a href="javascript:;" class="dropdown-toggle">
                                <span class="micon"><img
                                        src="{{ asset('assets/vendors/images/menu_icon/Sticker.svg') }}"
                                        alt=""></span>
                                <span class="mtext">Sticker</span>
                            </a>
                            <ul class="submenu child"
                                style="display: {{ Route::currentRouteName() == 'show_sticker_cat.index' || Route::currentRouteName() == 'sticker_item.index'
                                    ? 'block'
                                    : 'none' }}">
                                <li><a href="{{ route('show_sticker_cat.index') }}"
                                        class="{{ Route::currentRouteName() == 'show_sticker_cat.index' ? 'selectSubMenu' : '' }}">Category</a>
                                </li>
                                <li><a href="{{ route('sticker_item.index') }}"
                                        class="{{ Route::currentRouteName() == 'sticker_item.index' ? 'selectSubMenu' : '' }}">Item</a>
                                </li>
                            </ul>
                        </li>
                    </ul>

                    {{-- SVG --}}
                    <ul class="submenu"
                        style="display: {{ Route::currentRouteName() == 'vector_categories.index' ||
                        Route::currentRouteName() == 'vector_items.index' ||
                        Route::currentRouteName() == 'show_bg_cat.index' ||
                        Route::currentRouteName() == 'show_bg_item.index' ||
                        Route::currentRouteName() == 'audio_cat.index' ||
                        Route::currentRouteName() == 'audio_items.index' ||
                        Route::currentRouteName() == 'show_sticker_cat.index' ||
                        Route::currentRouteName() == 'sticker_item.index' ||
                        Route::currentRouteName() == 'frame_categories.index' ||
                        Route::currentRouteName() == 'frame_items.index' ||
                        Route::currentRouteName() == 'video_cat.index' ||
                        Route::currentRouteName() == 'video_item.index' ||
                        Route::currentRouteName() == 'gif_categories.index' ||
                        Route::currentRouteName() == 'gif_items.index'
                            ? 'block'
                            : 'none' }}">
                        <li
                            class="dropdown {{ Route::currentRouteName() == 'vector_categories.index' || Route::currentRouteName() == 'vector_items.index'
                                ? 'show'
                                : '' }}">
                            <a href="javascript:;" class="dropdown-toggle">
                                <span class="micon"><img
                                        src="{{ asset('assets/vendors/images/menu_icon/Shape.svg') }}"
                                        alt=""></span>
                                <span class="mtext">Vector</span>
                            </a>
                            <ul class="submenu child"
                                style="display: {{ Route::currentRouteName() == 'vector_categories.index' || Route::currentRouteName() == 'vector_items.index'
                                    ? 'block'
                                    : 'none' }}">
                                <li><a href="{{ route('vector_categories.index') }}"
                                        class="{{ Route::currentRouteName() == 'vector_categories.index' ? 'selectSubMenu' : '' }}">Category</a>
                                </li>
                                <li><a href="{{ route('vector_items.index') }}"
                                        class="{{ Route::currentRouteName() == 'vector_items.index' ? 'selectSubMenu' : '' }}">Item</a>
                                </li>
                            </ul>
                        </li>
                    </ul>

                    {{-- Audio --}}
                    <ul class="submenu"
                        style="display: {{ Route::currentRouteName() == 'audio_cat.index' ||
                        Route::currentRouteName() == 'audio_items.index' ||
                        Route::currentRouteName() == 'show_bg_cat.index' ||
                        Route::currentRouteName() == 'show_bg_item.index' ||
                        Route::currentRouteName() == 'vector_categories.index' ||
                        Route::currentRouteName() == 'vector_items.index' ||
                        Route::currentRouteName() == 'show_sticker_cat.index' ||
                        Route::currentRouteName() == 'sticker_item.index' ||
                        Route::currentRouteName() == 'frame_categories.index' ||
                        Route::currentRouteName() == 'frame_items.index' ||
                        Route::currentRouteName() == 'video_cat.index' ||
                        Route::currentRouteName() == 'video_item.index' ||
                        Route::currentRouteName() == 'gif_categories.index' ||
                        Route::currentRouteName() == 'gif_items.index'
                            ? 'block'
                            : 'none' }}">
                        <li
                            class="dropdown {{ Route::currentRouteName() == 'audio_cat.index' || Route::currentRouteName() == 'audio_items.index'
                                ? 'show'
                                : '' }}">
                            <a href="javascript:;" class="dropdown-toggle">
                                <span class="micon"><img
                                        src="{{ asset('assets/vendors/images/menu_icon/Shape.svg') }}"
                                        alt=""></span>
                                <span class="mtext">Audio</span>
                            </a>
                            <ul class="submenu child"
                                style="display: {{ Route::currentRouteName() == 'audio_cat.index' || Route::currentRouteName() == 'audio_items.index'
                                    ? 'block'
                                    : 'none' }}">
                                <li><a href="{{ route('audio_cat.index') }}"
                                        class="{{ Route::currentRouteName() == 'audio_cat.index' ? 'selectSubMenu' : '' }}">Category</a>
                                </li>
                                <li><a href="{{ route('audio_items.index') }}"
                                        class="{{ Route::currentRouteName() == 'audio_items.index' ? 'selectSubMenu' : '' }}">Item</a>
                                </li>
                            </ul>
                        </li>
                    </ul>

                    {{-- Background --}}
                    <ul class="submenu"
                        style="display: {{ Route::currentRouteName() == 'show_bg_cat.index' ||
                        Route::currentRouteName() == 'show_bg_item.index' ||
                        Route::currentRouteName() == 'audio_cat.index' ||
                        Route::currentRouteName() == 'audio_items.index' ||
                        Route::currentRouteName() == 'vector_categories.index' ||
                        Route::currentRouteName() == 'vector_items.index' ||
                        Route::currentRouteName() == 'show_sticker_cat.index' ||
                        Route::currentRouteName() == 'sticker_item.index' ||
                        Route::currentRouteName() == 'frame_categories.index' ||
                        Route::currentRouteName() == 'frame_items.index' ||
                        Route::currentRouteName() == 'video_cat.index' ||
                        Route::currentRouteName() == 'video_item.index' ||
                        Route::currentRouteName() == 'gif_categories.index' ||
                        Route::currentRouteName() == 'gif_items.index'
                            ? 'block'
                            : 'none' }}">
                        <li
                            class="dropdown {{ Route::currentRouteName() == 'show_bg_cat.index' || Route::currentRouteName() == 'show_bg_item.index'
                                ? 'show'
                                : '' }}">
                            <a href="javascript:;" class="dropdown-toggle">
                                <span class="micon"><img
                                        src="{{ asset('assets/vendors/images/menu_icon/Background.svg') }}"
                                        alt=""></span>
                                <span class="mtext">Background</span>
                            </a>
                            <ul class="submenu child"
                                style="display: {{ Route::currentRouteName() == 'show_bg_cat.index' || Route::currentRouteName() == 'show_bg_item.index'
                                    ? 'block'
                                    : 'none' }}">
                                <li><a href="{{ route('show_bg_cat.index') }}"
                                        class="{{ Route::currentRouteName() == 'show_bg_cat.index' ? 'selectSubMenu' : '' }}">Category</a>
                                </li>
                                <li><a href="{{ route('show_bg_item.index') }}"
                                        class="{{ Route::currentRouteName() == 'show_bg_item.index' ? 'selectSubMenu' : '' }}">Item</a>
                                </li>
                            </ul>
                        </li>
                    </ul>

                    {{-- video --}}
                    <ul class="submenu"
                        style="display: {{ Route::currentRouteName() == 'video_cat.index' ||
                        Route::currentRouteName() == 'video_item.index' ||
                        Route::currentRouteName() == 'audio_cat.index' ||
                        Route::currentRouteName() == 'audio_items.index' ||
                        Route::currentRouteName() == 'vector_categories.index' ||
                        Route::currentRouteName() == 'vector_items.index' ||
                        Route::currentRouteName() == 'show_sticker_cat.index' ||
                        Route::currentRouteName() == 'sticker_item.index' ||
                        Route::currentRouteName() == 'frame_categories.index' ||
                        Route::currentRouteName() == 'frame_items.index' ||
                        Route::currentRouteName() == 'gif_categories.index' ||
                        Route::currentRouteName() == 'gif_items.index' ||
                        Route::currentRouteName() == 'show_bg_cat.index' ||
                        Route::currentRouteName() == 'show_bg_item.index'
                            ? 'block'
                            : 'none' }}">
                        <li
                            class="dropdown {{ Route::currentRouteName() == 'video_cat.index' || Route::currentRouteName() == 'video_item.index'
                                ? 'show'
                                : '' }}">
                            <a href="javascript:;" class="dropdown-toggle">
                                <span class="micon"><img
                                        src="{{ asset('assets/vendors/images/menu_icon/Background.svg') }}"
                                        alt=""></span>
                                <span class="mtext">Video</span>
                            </a>
                            <ul class="submenu child"
                                style="display: {{ Route::currentRouteName() == 'video_cat.index' || Route::currentRouteName() == 'video_item.index'
                                    ? 'block'
                                    : 'none' }}">
                                <li><a href="{{ route('video_cat.index') }}"
                                        class="{{ Route::currentRouteName() == 'video_cat.index' ? 'selectSubMenu' : '' }}">Category</a>
                                </li>
                                <li><a href="{{ route('video_item.index') }}"
                                        class="{{ Route::currentRouteName() == 'video_item.index' ? 'selectSubMenu' : '' }}">Item</a>
                                </li>
                            </ul>
                        </li>
                    </ul>

                    {{-- gif --}}
                    <ul class="submenu"
                        style="display: {{ Route::currentRouteName() == 'gif_categories.index' ||
                        Route::currentRouteName() == 'gif_items.index' ||
                        Route::currentRouteName() == 'audio_cat.index' ||
                        Route::currentRouteName() == 'audio_items.index' ||
                        Route::currentRouteName() == 'vector_categories.index' ||
                        Route::currentRouteName() == 'vector_items.index' ||
                        Route::currentRouteName() == 'show_sticker_cat.index' ||
                        Route::currentRouteName() == 'sticker_item.index' ||
                        Route::currentRouteName() == 'frame_categories.index' ||
                        Route::currentRouteName() == 'frame_items.index' ||
                        Route::currentRouteName() == 'video_cat.index' ||
                        Route::currentRouteName() == 'video_item.index' ||
                        Route::currentRouteName() == 'show_bg_cat.index' ||
                        Route::currentRouteName() == 'show_bg_item.index'
                            ? 'block'
                            : 'none' }}">
                        <li
                            class="dropdown {{ Route::currentRouteName() == 'gif_categories.index' || Route::currentRouteName() == 'gif_items.index'
                                ? 'show'
                                : '' }}">
                            <a href="javascript:;" class="dropdown-toggle">
                                <span class="micon"><img
                                        src="{{ asset('assets/vendors/images/menu_icon/Background.svg') }}"
                                        alt=""></span>
                                <span class="mtext">Gif</span>
                            </a>
                            <ul class="submenu child"
                                style="display: {{ Route::currentRouteName() == 'gif_categories.index' || Route::currentRouteName() == 'gif_items.index'
                                    ? 'block'
                                    : 'none' }}">
                                <li><a href="{{ route('gif_categories.index') }}"
                                        class="{{ Route::currentRouteName() == 'gif_categories.index' ? 'selectSubMenu' : '' }}">Category</a>
                                </li>
                                <li><a href="{{ route('gif_items.index') }}"
                                        class="{{ Route::currentRouteName() == 'gif_items.index' ? 'selectSubMenu' : '' }}">Item</a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </li>

                @if ($roleManager::isAdmin(Auth::user()->user_type))

                    <li>
                        <a href="{{route('promocode.index')}}" class="dropdown-toggle no-arrow {{ (Route::currentRouteName() == 'promocode.index') ? 'selectSubMenu' : '' }}">
                            <span class="micon bi bi-calendar4-week"></span><span class="mtext">Promo Code</span>
                        </a>
                    </li>

                     <li>
                        <a href="{{ route('templateRate.index') }}"
                            class="dropdown-toggle no-arrow {{ Route::currentRouteName() == 'templateRate.index' ? 'selectSubMenu' : '' }}">
                            <span class="micon"><img
                                    src="{{ asset('assets/vendors/images/menu_icon/Review.svg') }}"
                                    alt=""></span><span class="mtext">Template Rate</span>
                        </a>
                    </li>
                    
                    <li class="dropdown {{ ( Route::currentRouteName() == 'show_packages' || Route::currentRouteName() == 'payment_setting'  || Route::currentRouteName() == 'transcation_logs' || Route::currentRouteName() == 'template_transcation_logs' || Route::currentRouteName() == 'video_transcation_logs' ) ? 'show' : '' }}">
                        <a href="javascript:;" class="dropdown-toggle">
                            <span class="micon"><img src="{{asset('assets/vendors/images/menu_icon/SubscribeOld.svg')}}" alt=""></span><span class="mtext">Old Plan Subscription</span>
                        </a>
                        <ul class="submenu" style="display:{{ ( Route::currentRouteName() == 'show_packages' || Route::currentRouteName() == 'payment_setting'  || Route::currentRouteName() == 'transcation_logs' || Route::currentRouteName() == 'template_transcation_logs' || Route::currentRouteName() == 'video_transcation_logs' ) ? 'block' : 'none' }};">
                            <li><a href="{{route('show_packages')}}" class="{{ (Route::currentRouteName() == 'show_packages') ? 'selectSubMenu' : '' }}">Subscription Package</a></li>
                            <li><a href="{{route('payment_setting')}}" class="{{ (Route::currentRouteName() == 'payment_setting') ? 'selectSubMenu' : '' }}">Payment Setting</a></li>
                            <li><a href="{{route('transcation_logs')}}" class="{{ (Route::currentRouteName() == 'transcation_logs') ? 'selectSubMenu' : '' }}">Subscription Transaction Logs</a></li>
                            <li><a href="{{route('template_transcation_logs')}}" class="{{ (Route::currentRouteName() == 'template_transcation_logs') ? 'selectSubMenu' : '' }}">Template Transaction Logs</a></li>
                            <li><a href="{{route('video_transcation_logs')}}" class="{{ (Route::currentRouteName() == 'video_transcation_logs') ? 'selectSubMenu' : '' }}">Video Transaction Logs</a></li>
                        </ul>
                    </li>

                    <li class="dropdown {{ ( Route::currentRouteName() == 'categoryFeatures.index' || Route::currentRouteName() == 'features.index' || Route::currentRouteName() == 'plans.index' || Route::currentRouteName() == 'plans.create' ) ? 'show' : '' }}">
                        <a href="javascript:;" class="dropdown-toggle">
                            <span class="micon"><img src="{{asset('assets/vendors/images/menu_icon/SubscribeNew1.svg')}}" alt=""></span><span class="mtext">New Plan Subscription</span>
                        </a>
                         <ul class="submenu" style="display: {{ ( Route::currentRouteName() == 'categoryFeatures.index' || Route::currentRouteName() == 'features.index' || Route::currentRouteName() == 'plans.index' || Route::currentRouteName() == 'plans.create' || Route::currentRouteName() == 'plans.edit' ) ? 'block' : 'none' }}">
                            <li class="dropdown {{ ( Route::currentRouteName() == 'categoryFeatures.index' || Route::currentRouteName() == 'features.index' || Route::currentRouteName() == 'plans.index' || Route::currentRouteName() == 'plans.create' || Route::currentRouteName() == 'plans.edit'  ) ? 'show' : '' }}">
                                <a href="javascript:;" class="dropdown-toggle">
                                    <span class="micon"><img src="{{asset('assets/vendors/images/menu_icon/SubscribeNew.svg')}}" alt=""></span><span class="mtext">New Subscription Package</span>
                                </a>
                                <ul class="submenu child" style="display: {{ ( Route::currentRouteName() == 'categoryFeatures.index' || Route::currentRouteName() == 'features.index' || Route::currentRouteName() == 'plans.index' || Route::currentRouteName() == 'plans.create' || Route::currentRouteName() == 'plans.edit' ) ? 'block' : 'none' }}">
                                    <li><a href="{{route('categoryFeatures.index')}}" class="{{ (Route::currentRouteName() == 'categoryFeatures.index') ? 'selectSubMenu' : '' }}">Category Feature</a></li>
                                    <li><a href="{{route('features.index')}}" class="{{ (Route::currentRouteName() == 'features.index') ? 'selectSubMenu' : '' }}">Feature</a></li>
                                    <li><a href="{{route('plans.index')}}" class="{{ (Route::currentRouteName() == 'plans.index' || Route::currentRouteName() == 'plans.create' || Route::currentRouteName() == 'plans.edit') ? 'selectSubMenu' : '' }}">Plans</a></li>
                                </ul>
                            </li>
                        </ul>
                    @endif
                    {{-- <ul class="submenu" style="display:{{ ( Route::currentRouteName() == 'categoryFeatures.index' || Route::currentRouteName() == 'features.index' || Route::currentRouteName() == 'plans.index' || Route::currentRouteName() == 'plans.create' ) ? 'block' : 'none' }};">
                        <li><a href="{{route('categoryFeatures.index')}}" class="{{ (Route::currentRouteName() == 'categoryFeatures.index') ? 'selectSubMenu' : '' }}">Category Feature</a></li>
                        <li><a href="{{route('features.index')}}" class="{{ (Route::currentRouteName() == 'features.index') ? 'selectSubMenu' : '' }}">Feature</a></li>
                        <li><a href="{{route('plans.index')}}" class="{{ (Route::currentRouteName() == 'plans.index' || Route::currentRouteName() == 'plans.create' || Route::currentRouteName() == 'plans.edit') ? 'selectSubMenu' : '' }}">Plans</a></li>
                    </ul> --}}
                </li>

                <li>
                    <a href="{{route('import_json')}}" class="dropdown-toggle no-arrow {{ ( Route::currentRouteName() == 'import_json' ) ? 'selectSubMenu' : '' }}">
                        <span class="micon"><img src="{{asset('assets/vendors/images/menu_icon/JsonImport.svg')}}" alt=""></span><span class="mtext">Import Json</span>
                    </a>
                </li>

                @if ($roleManager::isAdmin(Auth::user()->user_type))
                    <li>
                        <a href="{{route('show_users')}}" class="dropdown-toggle no-arrow {{ ( Route::currentRouteName() == 'show_users' || Route::currentRouteName() == "manage_subscription.show" || Route::currentRouteName() == "manage_template_product.show" || Route::currentRouteName() == "manage_video_product.show" ) ? 'selectSubMenu' : '' }}">
                            <span class="micon"><img src="{{asset('assets/vendors/images/menu_icon/Users.svg')}}" alt=""></span><span class="mtext">Users</span>
                        </a>
                    </li>
                    <li>
                        <a href="{{route('notification_setting')}}" class="dropdown-toggle no-arrow {{ ( Route::currentRouteName() == 'notification_setting' ) ? 'selectSubMenu' : '' }}">
                            <span class="micon"><img src="{{asset('assets/vendors/images/menu_icon/Notifications.svg')}}" alt=""></span><span class="mtext">Notification Setting</span>
                        </a>
                    </li>
                    <li>
                        <a href="{{route('show_messages')}}" class="dropdown-toggle no-arrow {{ ( Route::currentRouteName() == 'show_messages' ) ? 'selectSubMenu' : '' }}">
                            <span class="micon"><img src="{{asset('assets/vendors/images/menu_icon/AppMessage.svg')}}" alt=""></span><span class="mtext">In App Message</span>
                        </a>
                    </li>
                    <li>
                        <a href="{{route('show_feedbacks')}}" class="dropdown-toggle no-arrow {{ ( Route::currentRouteName() == 'show_feedbacks' ) ? 'selectSubMenu' : '' }}">
                            <span class="micon"><img src="{{asset('assets/vendors/images/menu_icon/Feedback.svg')}}" alt=""></span><span class="mtext">Feedbacks</span>
                        </a>
                    </li>
                @endif

                @if ( $roleManager::onlySeoAccess(Auth::user()->user_type))

                    <li>
                        <a href="{{route('reviews.index')}}" class="dropdown-toggle no-arrow {{ (Route::currentRouteName() == 'reviews.index') ? 'selectSubMenu' : '' }}">
                            <span class="micon"><img src="{{asset('assets/vendors/images/menu_icon/Review.svg')}}" alt=""></span><span class="mtext">Reviews</span>
                        </a>
                    </li>

                    <li>
                        <a href="{{ route('p_reviews.index') }}" class="dropdown-toggle no-arrow {{ Route::currentRouteName() == 'p_reviews.index' ? 'selectSubMenu' : '' }}">
                            <span class="micon"><img src="{{ asset('assets/vendors/images/menu_icon/Review.svg') }}" alt=""></span><span class="mtext">Page Reviews</span>
                        </a>
                    </li>

                    <li>
                        <a href="{{route('show_employee')}}" class="dropdown-toggle no-arrow {{ ( Route::currentRouteName() == 'show_employee' ) ? 'selectSubMenu' : '' }}">
                            <span class="micon"><img src="{{asset('assets/vendors/images/menu_icon/Employee.svg')}}" alt=""></span><span class="mtext">Employees</span>
                        </a>
                    </li>
                @endif
                @if ($roleManager::isAdmin(Auth::user()->user_type))
                    <li>
                        <a href="{{route('show_contacts')}}" class="dropdown-toggle no-arrow {{ ( Route::currentRouteName() == 'show_contacts' ) ? 'selectSubMenu' : '' }}">
                            <span class="micon"><img src="{{asset('assets/vendors/images/menu_icon/Contacts.svg')}}" alt=""></span><span class="mtext">Contacts</span>
                        </a>
                    </li>
                @endif
            <li>
                <a href="{{ route('seo_error_list') }}"
                   class="dropdown-toggle no-arrow {{ Route::currentRouteName() == 'data_list' ? 'selectSubMenu' : '' }}">
                        <span class="micon"><img src="{{ asset('assets/vendors/images/menu_icon/Contacts.svg') }}"
                                                 alt=""></span><span class="mtext">List</span>
                </a>
            </li>
            </ul>
        </div>
    </div>
</div>
<div class="mobile-menu-overlay"></div>
<script>
    let roleKey = @json($roleManager::getUserType(Auth::user()->user_type));
</script>
