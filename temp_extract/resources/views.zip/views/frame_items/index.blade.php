
@inject('roleManager', 'App\Http\Controllers\Utils\RoleManager')

<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>Laravel</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

    <link rel="stylesheet" type="text/css" href="{{ asset('assets/vendors/styles/core.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/vendors/styles/icon-font.min.css') }}">
    <link rel="stylesheet" type="text/css"
        href="{{ asset('assets/plugins/datatables/css/dataTables.bootstrap4.min.css') }}">
    <link rel="stylesheet" type="text/css"
        href="{{ asset('assets/plugins/datatables/css/responsive.bootstrap4.min.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/vendors/styles/style.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/vendors/styles/custom.css') }}">

    <style>
        .tooltip-container {
            position: relative;
            display: inline-block;
            cursor: pointer;
        }

        .tooltip-container .tooltip-text {
            visibility: hidden;
            width: 200px;
            background-color: #555;
            color: #fff;
            text-align: center;
            border-radius: 6px;
            padding: 5px;
            position: absolute;
            z-index: 1;
            bottom: 125%;
            /* Position the tooltip above the icon */
            left: 50%;
            margin-left: -100px;
            opacity: 0;
            transition: opacity 0.3s;
        }

        .tooltip-container .tooltip-text::after {
            content: "";
            position: absolute;
            top: 100%;
            /* Arrow at the bottom of the tooltip */
            left: 50%;
            margin-left: -5px;
            border-width: 5px;
            border-style: solid;
            border-color: #555 transparent transparent transparent;
        }

        .tooltip-container:hover .tooltip-text {
            visibility: visible;
            opacity: 1;
        }

        .form-group {
            margin-top: 20px;
        }

        h6 {
            display: inline-block;
            margin-right: 5px;
        }

        .svg-icon {
            width: 16px;
            height: 16px;
            fill: currentColor;
        }

        /*Table*/

        .sort-arrow {
            margin-left: 0px;
        }

        .sort-arrow.active {
            color: #1739d1ec;
        }

        .sort-arrow {
            font-family: 'dropways';
            font-size: 14px;
            color: grey;
            /* Default color */
        }

        .sort-asc::before {
            content: "\eabb";
            /* Custom icon content for up arrow */
        }

        .sort-desc::before {
            content: "\eaba";
        }

        /* Active state with blue color */
        .sort-asc.active::before,
        .sort-desc.active::before {
            color: #1b00ff;
        }

        span.sort-arrow.sort-desc {
            margin-left: -7px;
        }

        .form-row input.form-control {
            width: 297px;
        }

        .pd-20.f-left {
            float: left;
        }

        .form-row.f-right {
            padding: 20px;
            padding-top: 0;
            float: right;
        }

        .row ul.pagination {
            margin-bottom: 10px;
            float: right;
            margin-right: 20px;
        }
    </style>
</head>

<body class="antialiased">

    @include('layouts.header')

    <div class="main-container designer-access-container">
        <div class="pd-ltr-20 xs-pd-20-10">
            <div class="min-height-200px">
                <div class="card-box mb-30">
                    <div class="row justify-content-between pb-30 pt-10">
                        <div class="col-md-3">
                            @if ($roleManager::onlyDesignerAccess(Auth::user()->user_type))
                            <button class="btn btn-primary ml-4 mt-5" role="button" data-backdrop="static"
                                id="addNewFrameItemBtn"
                                type="button">
                                + Add New Frame Item
                            </button>
                            @endif
                        </div>

                        <div class="col-md-9">
                            @include('partials.filter_form', [
                                'action' => route('frame_items.index'),
                            ])
                        </div>
                    </div>


                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Id</th>
                                <th>User</th>
                                <th class="datatable-nosort">Name</th>
                                <th>Frame Category Name</th>
                                <th class="datatable-nosort">Thumb</th>
                                <th class="datatable-nosort">File</th>
                                <th>Is Premium</th>
                                <th>Status</th>
                                <th class="datatable-nosort">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($framesItems as $framesItem)
                                <tr>
                                    <td class="table-plus">{{ $framesItem->id }}</td>
                                    <td>{{ $roleManager::getUploaderName($framesItem->emp_id) }}
                                    <td id="name">{{ $framesItem->name }}</td>
                                    <td>{{ optional($framesItem->frameCategory)->name ?? '' }}</td>

                                    <td><img src="{{\App\Http\Controllers\Utils\ContentManager::getStorageLink($framesItem->thumb)}}"
                                            style="max-width: 100px; max-height: 100px; width: auto; height: auto" />
                                    </td>
                                    <td><img src="{{\App\Http\Controllers\Utils\ContentManager::getStorageLink($framesItem->file)}}"
                                            style="max-width: 100px; max-height: 100px; width: auto; height: auto" />
                                    </td>

                                    @if ($framesItem->is_premium == '1')
                                        <td>
                                            <label id="premium_label_{{ $framesItem->id }}"
                                                style="display: none;">TRUE</label>
                                            <label class="switch-new">
                                                <input type="checkbox" checked class="hidden-checkbox"
                                                    onclick="premium_click('{{ $framesItem->id }}')">
                                                <span class="slider round"></span>
                                            </label>
                                        </td>
                                    @else
                                        <td>
                                            <label id="premium_label_{{ $framesItem->id }}"
                                                style="display: none;">FALSE</label>
                                            <label class="switch-new">
                                                <input type="checkbox" class="hidden-checkbox"
                                                    onclick="premium_click('{{ $framesItem->id }}')">
                                                <span class="slider round"></span>
                                            </label>
                                        </td>
                                    @endif

                                    @if ($framesItem->status == '1')
                                        <td>LIVE</td>
                                    @else
                                        <td>NOT LIVE</td>
                                    @endif

                                    <td>
                                        <button class="dropdown-item edit-frame-item-btn"
                                            data-id="{{ $framesItem->id }}">
                                            <i class="dw dw-edit2"></i> Edit
                                        </button>
                                        @if ($roleManager::isAdminOrDesignerManager(Auth::user()->user_type))
                                        <a class="dropdown-item" href="#"
                                            onclick="deleteFrameItem({{ $framesItem['id'] }})">
                                            <i class="dw dw-delete-3"></i> Delete
                                        </a>
                                        @endif
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                    @include('partials.pagination', ['items' => $framesItems])
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade designer-access-container" id="add_frame_item_model" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel"
        aria-hidden="false">
        <div class="modal-dialog modal-dialog-centered" style="max-width: 676px;">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modal_title">Add New Frame Item</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                </div>
                <div id="result"></div>
                <div class="modal-body">
                    <form method="post" id="add_frame_item_form" enctype="multipart/form-data">
                        @csrf
                        <input type="hidden" name="frame_item_id" id="frame_item_id" value="">

                        <div class="form-group">
                            <h6>Name</h6>
                            <input type="text" class="form-control" name="name" placeholder="Name"
                                id="itemName">
                        </div>

                        <div class="form-group category-dropbox-wrap">
                            <h6>Parent Category</h6>
                            <select class="form-control" name="frame_category_id" id="frame_category_id">
                                <option value="0">== none ==</option>
                                @foreach ($allCategories as $category)
                                    <option value="{{ $category->id }}">{{ $category->name }}</option>
                                @endforeach
                            </select>
                        </div>

                        <div class="form-group">
                            <h6>Frame Items Thumb</h6>
                            <input type="file" class="form-control dynamic-file height-auto"
                                data-accept=".jpg, .jpeg, .webp, .svg" id="thumbs" data-imgstore-id="thumb"
                                data-nameset="true">
                        </div>

                        <div class="form-group">
                            <h6>Frame Items File</h6>
                            <input type="file" class="form-control dynamic-file height-auto" data-accept=".svg"
                                data-imgstore-id="file" id="files" data-nameset="true" accept="image/*">
                        </div>

                        <div class="form-group">
                            <h6>Is Premium</h6>
                            <select id="is_premium" class="form-control"
                                data-style="btn-outline-primary" name="is_premium" accept="image/*">
                                <option value="0">FALSE</option>
                                <option value="1">TRUE</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <h6>Status</h6>
                            <select class=" form-control" data-style="btn-outline-primary" id="status"
                                name="status">
                                <option value="1">LIVE</option>
                                <option value="0">NOT LIVE</option>
                            </select>
                        </div>

                        <div>
                            <input class="btn btn-primary" type="submit" value="Submit">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        const STORAGE_URL = "{{ env('STORAGE_URL') }}";
        // *Debug
        const storageUrl = "{{ config('filesystems.storage_url') }}";
    </script>
    <script src="{{ asset('assets/vendors/scripts/core.js') }}"></script>
    <script src="{{ asset('assets/vendors/scripts/script.min.js') }}"></script>
    <script src="{{ asset('assets/vendors/scripts/process.js') }}"></script>
    <script src="{{ asset('assets/js/dynamicfile.js') }}"></script>
    <script src="{{ asset('assets/js/role_access.js') }}"></script>

    <script>
        function toggleCheckbox(button, parameter) {
            var checkbox = button.querySelector('input[ type="checkbox"]');
            checkbox.checked = !checkbox.checked;
            premium_click(parameter);
        }

        $(document).ready(function() {

            $('#addNewFrameItemBtn').on('click', function() {
                resetValue();
                $('#add_frame_item_model').modal('show');
                // $('.selectpicker').selectpicker('refresh');
            });

            $('#add_frame_item_form').on('submit', function(e) {
                e.preventDefault();

                let formData = new FormData(this);
                let frame_item_id = $('#frame_item_id').val();
                if (frame_item_id) {
                    formData.append('frame_item_id', frame_item_id);
                }

                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });

                $.ajax({
                    url: "{{ route('frame_items.store') }}", 
                    type: "POST",
                    data: formData,
                    contentType: false,
                    processData: false,
                    success: function(response) {
                        if (response.status) {
                            location.reload();
                        } else {
                            alert(response.error || 'Something went wrong.');
                        }
                    },
                    error: function(xhr) {
                        alert("Error: " + xhr.responseText);
                    }
                });
            });

            $(document).on('click', '.edit-frame-item-btn', function() {
                const id = $(this).data('id');

                $.get("{{ url('frame_items') }}/" + id + "/edit", function(data) {

                    $('#add_frame_item_model').modal('show');
                    $('#modal_title').text("Edit Frame Item");

                    const imageUrl = getStorageLink(data.thumb)
                    $('#thumbs').attr('data-value', imageUrl);
                    const imageUrlFils = getStorageLink(data.file)
                    $('#files').attr('data-value', imageUrlFils);
                    dynamicFileCmp();

                    $('#frame_item_id').val(data.id);
                    $('#itemName').val(data.name);

                    $('#frame_category_id').val(data.frame_category_id).change();

                });
            });

            $('#add_frame_item_model').on('hidden.bs.modal', function() {
                resetValue();
            });

            function resetValue(){
                $('#modal_title').text("Add New Frame Item");
                $('#add_frame_item_form')[0].reset();
                $('#frame_item_id').val('');
                $('#result').html('');
                $('#parentCategoryInput span').text('== none ==');
                resetDynamicFileValue("thumbs")
                resetDynamicFileValue("files")
            }

        });

        function deleteFrameItem(id) {
            event.preventDefault()
            if (confirm('Are you sure you want to delete this frame item?')) {
                $.ajax({
                    url: "{{ route('frame_items.destroy', ':id') }}".replace(':id', id),
                    type: 'DELETE',
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    success: function(response) {
                        if (response.success) {
                            window.location.reload();
                        } else {
                            alert(response.error);
                        }
                    },
                    error: function(xhr) {}
                });
            }
        }

        function premium_click($id) {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                }
            });
            var status = $id;
            var url = "{{ route('frameItem.premium', ': status ') }}";
            url = url.replace(":status", status);
            var formData = new FormData();
            formData.append('id', $id);
            $.ajax({
                url: url,
                type: 'POST',
                data: formData,
                success: function(data) {
                    if (data.error) {
                        window.alert(data.error);
                    } else {
                        var x = document.getElementById("premium_label_" + $id);
                        if (x.innerHTML === "TRUE") {
                            x.innerHTML = "FALSE";
                        } else {
                            x.innerHTML = "TRUE";
                        }
                    }

                },
                error: function(error) {
                    var loading_screen = document.getElementById("loading_screen");
                    loading_screen.style.display = "none";
                    window.alert(error.responseText);
                },
                cache: false,
                contentType: false,
                processData: false
            })
        }
    </script>
</body>

</html>
