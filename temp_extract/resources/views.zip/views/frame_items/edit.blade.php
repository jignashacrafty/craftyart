<div class="form-group category-dropbox-wrap">
    <h6>Shape Category</h6>
    <div class="input-subcategory-dropbox" id="parentCategoryInput"><span>
            @if (isset($frameItem->frameCategory->name) && $frameItem->frameCategory->name != '')
                {{ $frameItem->frameCategory->name }}
            @else
                {{"== none =="}}
            @endif
        </span> <i style="font-size:18px" class="fa down-arrow-dropbox">&#xf107;</i></div>
    <div class="custom-dropdown parent-category-input">
        <ul class="dropdown-menu-ul">
            <li class="category none-option">== none ==</li>
            @foreach ($allCategories as $category)
                                    @php
                                        $classBold = (!empty($category['subcategories']) && isset($category['subcategories'][0])) ? "has-children" : "has-parent";
                                        $selected = (isset($frameItem->frame_category_id) && $frameItem->frame_category_id == $category['id']) ? "selected" : "";
                                    @endphp
                                    <li class="category {{$classBold}} {{$selected}}" data-id="{{$category['id']}}"
                                        data-catname="{{$category['name']}}">
                                        <span>{{ $category['name'] }}</span>
                                        @if (!empty($category['subcategories']))
                                            <ul class="subcategories">
                                                @foreach ($category['subcategories'] as $subcategory)
                                                    @include('partials.subframecategory-optgroup', ['subcategory' => $subcategory, 'sub_category_id' => $subcategory['id'], 'sub_category_name' => $subcategory['name']])
                                                @endforeach
                                            </ul>
                                        @endif
                                    </li>
            @endforeach
        </ul>
    </div>
</div>
<input type="hidden" name="parent_category_id"
    value="{{isset($frameItem->frame_category_id) ? $frameItem->frame_category_id : '0'}}">
<div class="form-group">
    <h6>Item Thumb</h6>
    <input type="file" class="form-control-file form-control height-auto" name="thumb" id="item_thumb"><br />
    <img src="{{ config('filesystems.storage_url') }}{{$frameItem->thumb}}" width="100" />
    <input class="form-control" type="textname" id="cat_thumb_path" name="thumb" value="{{$frameItem->thumb}}"
        style="display: none">
</div>

<div class="form-group">
    <h6>Item File</h6>
    <span class="tooltip-container">
        <svg class="svg-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="currentColor">
            <path
                d="M8 1a7 7 0 1 0 0 14A7 7 0 0 0 8 1zm0 13A6 6 0 1 1 8 2a6 6 0 0 1 0 12zM8.93 6.588l-2.29.287-.082.38.45.083c.294.07.352.176.288.469l-.738 3.468c-.194.897.105 1.319.808 1.319.545 0 .884-.252 1.105-.598l-.082.38.452.083.083-.381c.294-.07.352-.176.288-.469L8.24 7.06c-.097-.46-.345-.548-.808-.473zM8 4.5a1.12 1.12 0 1 1 0-2.25A1.12 1.12 0 0 1 8 4.5z" />
        </svg>
        <span class="tooltip-text">Allow SVG Formate file for upload frame</span>
    </span>
    <input type="file" class="form-control-file form-control height-auto" id="edit_item_file" name="file"><br />
    <span class="error-item-file" style="color:red;display: block;"></span>
    <img src="{{ config('filesystems.storage_url') }}{{$frameItem->file}}" width="100" />
    <input class="form-control" type="textname" id="cat_thumb_path" name="file" value="{{$frameItem->file}}"
        style="display: none">
</div>

<div class="form-group">
    <h6>Is Preminum</h6>
    <div class="col-sm-20">
        <select id="is_premium" class="selectpicker form-control" data-style="btn-outline-primary" name="is_premium">
            <option value="0" {{ ($frameItem->is_premium == "0") ? "selected" : "" }}>FALSE</option>
            <option value="1" {{ ($frameItem->is_premium == "1") ? "selected" : "" }}>TRUE</option>
        </select>
    </div>
</div>
<div class="form-group">
    <h6>Status</h6>
    <div class="col-sm-20">
        <select class="selectpicker form-control" data-style="btn-outline-primary" name="status" id="status">
            @if($frameItem->status == 1)
                <option value="1" selected>LIVE</option>
                <option value="0">NOT LIVE</option>
            @else
                <option value="1">LIVE</option>
                <option value="0" selected>NOT LIVE</option>
            @endif
        </select>
    </div>
</div>
<div>
    <input type="hidden" name="frame_item_id" id="frameItemId" value="{{isset($frameItem->id) ? $frameItem->id : ''}}">
    <input class="btn btn-primary" type="submit" name="submit">
</div>