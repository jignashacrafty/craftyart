@inject('roleManager', 'App\Http\Controllers\Utils\RoleManager')
<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="{{ csrf_token() }}">
        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

        <link rel="stylesheet" type="text/css" href="{{asset('assets/vendors/styles/core.css')}}">
        <link rel="stylesheet" type="text/css" href="{{asset('assets/vendors/styles/icon-font.min.css')}}">
        <link rel="stylesheet" type="text/css" href="{{asset('assets/plugins/datatables/css/dataTables.bootstrap4.min.css')}}">
        <link rel="stylesheet" type="text/css" href="{{asset('assets/plugins/datatables/css/responsive.bootstrap4.min.css')}}">
        <link rel="stylesheet" type="text/css" href="{{asset('assets/vendors/styles/style.css')}}">
        <link rel="stylesheet" type="text/css" href="{{asset('assets/vendors/styles/loader.css')}}">
        <link rel="stylesheet" type="text/css" href="{{asset('assets/plugins/switchery/switchery.min.css')}}">
    </head>
    <body class="antialiased">

        @include('layouts.header')

        <div class="main-container">
            <div id="loading_screen" style="display: none;">
                <div id="loader-wrapper">
                    <div id="loader"></div>
                    <div class="loader-section section-left"></div>
                    <div class="loader-section section-right"></div>
                </div>
            </div>
            <div class="pd-ltr-20 xs-pd-20-10">
                <div class="min-height-200px">
                    <div class="card-box mb-30">
                        <div class="pb-20">

                            <div id="DataTables_Table_0_wrapper" class="dataTables_wrapper dt-bootstrap4 no-footer">

                                <div class="row">
                                    <div class="col-sm-12 col-md-3">
                                        <div class="pd-20">
                                            <Button class="btn btn-primary" onclick="appSelection()"> Add New Plans </Button>
                                        </div>
                                    </div>

                                    @php
                                        $isAdmin = Auth::user()->user_type;
                                    @endphp
                                    <input class="d-none" type="text" id="isAdmin" value="{{$isAdmin}}">
                                    @if ($isAdmin == 1)
                                        <div class="col-sm-12 col-md-3">
                                            <div class="pd-20">
                                                <button id="excel_btn" class="btn btn-secondary buttons-excel buttons-html5" type="button"><span>Excel</span></button>
                                            </div>
                                        </div>
                                    @endif

                                    @if ($roleManager::isAdmin(Auth::user()->user_type))
                                    <div class="col-sm-12 col-md-6">
                                    @else
                                    <div class="col-sm-12 col-md-6">
                                        @if (!$roleManager::isAdmin(Auth::user()->user_type))
                                            <div class="col-sm-12 col-md-9">
                                        @endif
                                    @endif
                                        <div class="pt-20">
                                            <form action="{{ route('plans.index') }}" method="GET">
                                                <div class="form-group">
                                                    <div id="DataTables_Table_0_filter" class="dataTables_filter">
                                                        <label>Search:<input type="text" class="form-control" name="query" placeholder="Search here....." value="{{ request()->input('query') }}"></label> <button type="submit" class="btn btn-primary">Search</button>
                                                    </div>
                                                </div>
                                            </form>

                                        </div>
                                    </div>
                                </div>

                                <form id="create_plans_action" action="{{route('plans.create')}}" method="GET" style="display: none;">
                                    <input type="text" id="passingAppId" name="passingAppId">
                                       @csrf
                                </form>

                                <div class="col-sm-12 table-responsive">
                                    <table id="temp_table" class="table table-striped">
                                        <thead>
                                            <tr>
                                                <th>Id</th>
                                                <th>Plan Name</th>
                                                <th>Description</th>
                                                <th>INR Monthly</th>
                                                <th>INR Yearly</th>
                                                <th>USD Monthly</th>
                                                <th>USD Yearly</th>
                                                <th>Status</th>
                                                <th class="datatable-nosort">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody id="size_table">
                                            @foreach ($plans as $plan)
                                            <tr style="background-color: #efefef;">
                                                <td class="table-plus">{{$plan->id}}</td>
                                                <td class="table-plus">{{$plan->name}}</td>
                                                <td class="table-plus">{{$plan->description}}</td>
                                                <td class="table-plus">{{$plan->inr_actual_price_monthly}}</td>
                                                <td class="table-plus">{{$plan->inr_actual_price_yearly}}</td>
                                                <td class="table-plus">{{$plan->usd_actual_price_monthly}}</td>
                                                <td class="table-plus">{{$plan->usd_actual_price_yearly}}</td>
                                                <td class="table-plus">{{ ($plan->status) ? "Active" : "InActive" }}</td>
                                                <td>
                                                    <a class="dropdown-item" href="{{route('plans.edit',$plan->id)}}"><i class="dw dw-edit2" ></i> Edit</a>
                                                    <button class="dropdown-item" onclick="delete_click('{{$plan->id}}')"><i class="dw dw-delete-3" ></i> Delete</button>
                                                </td>
                                            </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>

                                <div class="row">
                                    <div class="col-sm-12 col-md-5">
                                        <div class="dataTables_info" id="DataTables_Table_0_info" role="status" aria-live="polite">
                                        </div>
                                    </div>
                                    <div class="col-sm-12 col-md-7">
                                        <div class="dataTables_paginate paging_simple_numbers" id="DataTables_Table_0_paginate">
                                            <ul class="pagination">
                                                {{ $plans->appends(request()->input())->links('pagination::bootstrap-4') }}
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div
            class="modal fade"
            id="delete_model"
            tabindex="-1"
            role="dialog"
            aria-labelledby="myLargeModalLabel"
            aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <input type="text" id="delete_id" name="delete_id" style="display: none;">
                    <div class="modal-header">
                        <h4 class="modal-title" id="myLargeModalLabel">Delete</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    </div>
                    <div class="modal-body">
                        <p> Are you sure you want to delete? </p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">No, Cancel</button>
                        <button type="button" class="btn btn-primary" onclick="delete_click()">Yes, Delete</button>
                    </div>
                </div>
            </div>
        </div>

        <script src="{{asset('assets/vendors/scripts/core.js')}}"></script>
        <script src="{{asset('assets/vendors/scripts/script.min.js')}}"></script>
        <script src="{{asset('assets/vendors/scripts/process.js')}}"></script>
        <script src="{{asset('assets/vendors/scripts/layout-settings.js')}}"></script>
        <script src="{{asset('assets/plugins/datatables/js/jquery.dataTables.min.js')}}"></script>
        <script src="{{asset('assets/plugins/datatables/js/dataTables.bootstrap4.min.js')}}"></script>
        <script src="{{asset('assets/plugins/datatables/js/dataTables.responsive.min.js')}}"></script>
        <script src="{{asset('assets/plugins/datatables/js/responsive.bootstrap4.min.js')}}"></script>
        <!-- <script src="{{asset('assets/vendors/scripts/datatable-setting.js')}}"></script> -->
        <script src="{{asset('assets/plugins/switchery/switchery.min.js')}}"></script>
        <script src="{{asset('assets/vendors/scripts/advanced-components.js')}}"></script>
        <script src="https://unpkg.com/xlsx/dist/xlsx.full.min.js"></script>

        <script>
            function notification_click($id) {
                $("#temp_id").val($id);
            }
            function reset_click($id) {
                $("#reset_temp_id").val($id);
            }
            function reset_creation($id) {
                $("#reset_creation_id").val($id);
            }
            function premium_click($id) {
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                    }
                });

                var status = $id;
                var url ="{{route('temp.premium', ":status")}}";
                url = url.replace(":status", status);
                var formData = new FormData();
                formData.append('id',$id);
                $.ajax({
                    url: url,
                    type: 'POST',
                    data: formData,
                    beforeSend: function () {
                        var loading_screen = document.getElementById("loading_screen");
                        loading_screen.style.display = "block";
                    },
                    success: function (data) {
                        var loading_screen = document.getElementById("loading_screen");
                        loading_screen.style.display = "none";
                        if (data.error) {
                            window.alert(data.error);
                        } else {
                            var x = document.getElementById("premium_label_" + $id);
                            if (x.innerHTML === "TRUE") {
                                x.innerHTML = "FALSE";
                            } else {
                                x.innerHTML = "TRUE";
                            }
                        }
                    },
                    error: function (error) {
                        var loading_screen = document.getElementById("loading_screen");
                        loading_screen.style.display = "none";
                        window.alert(error.responseText);
                    },
                    cache: false,
                    contentType: false,
                    processData: false
                })
            }

            function status_click($id) {
            	$.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                    }
                });

                var status = $id;
                var url ="{{route('temp.status', ":status")}}";
                url = url.replace(":status", status);
                var formData = new FormData();
                formData.append('id',$id);
                $.ajax({
                    url: url,
                    type: 'POST',
                    data: formData,
                    beforeSend: function () {
                        var loading_screen = document.getElementById("loading_screen");
                        loading_screen.style.display = "block";
                    },
                    success: function (data) {
                        var loading_screen = document.getElementById("loading_screen");
                        loading_screen.style.display = "none";
                        if (data.error) {
                            window.alert(data.error);
                        } else {
                            var x = document.getElementById("status_label_" + $id);
				            if (x.innerHTML === "Live") {
				                x.innerHTML = "Not Live";
				            } else {
				                x.innerHTML = "Live";
				            }
                        }
                    },
                    error: function (error) {
                        var loading_screen = document.getElementById("loading_screen");
                        loading_screen.style.display = "none";
                        window.alert(error.responseText);
                    },
                    cache: false,
                    contentType: false,
                    processData: false
                })
            }

            $(document).on('click', '#send_notification_click', function () {
                event.preventDefault();
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                    }
                });

                var formData = new FormData(document.getElementById("notification_form"));
                var status = formData.get("temp_id");
                var url ="{{route('poster.notification', ":status")}}";
                url = url.replace(":status", status);
                $.ajax({
                    url: url,
                    type: 'POST',
                    data: formData,
                    beforeSend: function () {
                        $('#send_notification_model').modal('toggle');
                        var loading_screen = document.getElementById("loading_screen");
                        loading_screen.style.display = "block";
                    },
                    success: function (data) {
                        var loading_screen = document.getElementById("loading_screen");
                        loading_screen.style.display = "none";
                        if (data.error) {
                            window.alert(data.error);
                        } else {
                            window.alert(data.success);
                        }
                    },
                    error: function (error) {
                        var loading_screen = document.getElementById("loading_screen");
                        loading_screen.style.display = "none";
                        window.alert(error.responseText);
                    },
                    cache: false,
                    contentType: false,
                    processData: false
                })
            });

            $(document).on('click', '#reset_date_click', function () {
                event.preventDefault();
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                    }
                });

                var status = $("#reset_temp_id").val();
                var url ="{{route('reset.date', ":status")}}";
                url = url.replace(":status", status);
                var formData = new FormData();
                formData.append('id',status);
                $.ajax({
                    url: url,
                    type: 'POST',
                    data: formData,
                    beforeSend: function () {
                        $('#reset_date_model').modal('toggle');
                        var loading_screen = document.getElementById("loading_screen");
                        loading_screen.style.display = "block";
                    },
                    success: function (data) {
                        var loading_screen = document.getElementById("loading_screen");
                        loading_screen.style.display = "none";
                        if (data.error) {
                            window.alert(data.error);
                        }
                    },
                    error: function (error) {
                        var loading_screen = document.getElementById("loading_screen");
                        loading_screen.style.display = "none";
                        window.alert(error.responseText);
                    },
                    cache: false,
                    contentType: false,
                    processData: false
                })
            });

            $(document).on('click', '#reset_creation_click', function () {
                event.preventDefault();
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                    }
                });

                var status = $("#reset_creation_id").val();
                var url ="{{route('reset.creation', ":status")}}";
                url = url.replace(":status", status);
                var formData = new FormData();
                formData.append('id',status);

                $.ajax({
                    url: url,
                    type: 'POST',
                    data: formData,
                    beforeSend: function () {
                        $('#reset_creation_model').modal('toggle');
                        var loading_screen = document.getElementById("loading_screen");
                        loading_screen.style.display = "block";
                    },
                    success: function (data) {
                        var loading_screen = document.getElementById("loading_screen");
                        loading_screen.style.display = "none";
                        if (data.error) {
                            window.alert(data.error);
                        }
                    },
                    error: function (error) {
                        var loading_screen = document.getElementById("loading_screen");
                        loading_screen.style.display = "none";
                        window.alert(error.responseText);
                    },
                    cache: false,
                    contentType: false,
                    processData: false
                })
            });

            $(document).ready(function() {
                $('#application_id').change(function() {
                    $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        }
                    });

                    var value = $(this).val();
                    $.ajax({
                        url:"{{ route('item.custom_data') }}",
                        method:"POST",
                        data:{value:value, _token: '{{csrf_token()}}'},
                        success:function(result) {
                            $('#item_table').html(result);
                        },error:function(result) {
                            window.alert(result.responseText);
                        }
                    })
                });
            });

            function appSelection(){
                $('#passingAppId').val('1');
                $('#create_plans_action').submit();
            }
            function set_delete_id($id) {
                $("#delete_id").val($id);
            }
            function delete_click(id) {
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                    }
                });

                var url ="{{route('plans.destroy', ":id")}}";
                url = url.replace(":id", id);
                $.ajax({
                    url: url,
                    type: 'DELETE',
                    beforeSend: function () {
                        var loading_screen = document.getElementById("loading_screen");
                        loading_screen.style.display = "block";
                    },
                    success: function (data) {
                        var loading_screen = document.getElementById("loading_screen");
                        loading_screen.style.display = "none";
                        if (data.error) {
                            window.alert('error==>'+data.error);
                        } else {
                            location.reload();
                        }
                    },
                    error: function (error) {
                        var loading_screen = document.getElementById("loading_screen");
                        loading_screen.style.display = "none";
                        window.alert(error.responseText);
                    },
                    cache: false,
                    contentType: false,
                    processData: false
                })
            }
        </script>
    </body>
</html>
