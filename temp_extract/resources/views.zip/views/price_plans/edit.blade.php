@inject('helperController', 'App\Http\Controllers\HelperController')
<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>Laravel</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="{{asset('assets/plugins/bootstrap-tagsinput/bootstrap-tagsinput.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('assets/vendors/styles/core.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('assets/vendors/styles/icon-font.min.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('assets/vendors/styles/style.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('assets/vendors/styles/loader.css')}}">
</head>
<body class="antialiased">

@include('layouts.header')

<div class="main-container">
    <div id="loading_screen" style="display: none;">
        <div id="loader-wrapper">
            <div id="loader"></div>
            <div class="loader-section section-left"></div>
            <div class="loader-section section-right"></div>
        </div>
    </div>

    <div class="pd-ltr-20 xs-pd-20-10">
        <div class="min-height-200px">
            <div class="page-header">
                <div class="row">
                    <div class="col-md-6 col-sm-12">
                        <div class="title">
                            Plan Details
                        </div>
                    </div>
                </div>
            </div>

            <div class="pd-20 card-box mb-30">
                <form method="post" id="editPlanForm">
                    <span id="result"></span>
                    @csrf
                    <div class="row">
                        <div class="col-md-6 col-sm-12">
                            <div class="form-group">
                                <h6>Plan Name</h6>
                                <input id="planName" class="form-control-file form-control" name="name" value="{{$plan->name}}" required>
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-12">
                            <div class="form-group">
                                <h6>Plan ID</h6>
                                <input id="planID" class="form-control-file form-control" name="plan_id" value="{{$plan->plan_id}}" required>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-3 col-sm-12">
                            <div class="form-group">
                                <h6>INR Actual Monthly Price</h6>
                                <input class="form-control" id="actualPriceMonthly" type="number" name="inr_actual_price_monthly" value="{{$plan->inr_actual_price_monthly}}" required="required" step="any">
                            </div>
                        </div>

                        <div class="col-md-3 col-sm-12">
                            <div class="form-group">
                                <h6>INR Discount Monthly Price</h6>
                                <input class="form-control" id="priceMonthly" type="number" name="inr_price_monthly" value="{{$plan->inr_price_monthly}}" required="" step="any">
                            </div>
                        </div>

                        <div class="col-md-3 col-sm-12">
                            <div class="form-group">
                                <h6>INR Actual Price Yearly</h6>
                                <input class="form-control" id="actualPriceYearly" type="number" name="inr_actual_price_yearly" value="{{$plan->inr_actual_price_yearly}}" required="required" step="any">
                            </div>
                        </div>

                        <div class="col-md-3 col-sm-12">
                            <div class="form-group">
                                <h6>INR Discount Price Yearly</h6>
                                <input class="form-control" id="priceYearly" type="number" name="inr_price_yearly" value="{{$plan->inr_price_yearly}}" required="" step="any">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-3 col-sm-12">
                            <div class="form-group">
                                <h6>USD Actual Monthly Price </h6>
                                <input class="form-control" id="actualUSDPriceMonthly" type="number" name="usd_actual_price_monthly" value="{{$plan->usd_actual_price_monthly}}" required="required" step="any">
                            </div>
                        </div>

                        <div class="col-md-3 col-sm-12">
                            <div class="form-group">
                                <h6>USD Discount Monthly Price</h6>
                                <input class="form-control" name="usd_price_monthly" value="{{$plan->usd_price_monthly}}" id="priceUSDMonthly" type="number" required="" step="any">
                            </div>
                        </div>

                        <div class="col-md-3 col-sm-12">
                            <div class="form-group">
                                <h6>USD Actual Yearly Price</h6>
                                <input class="form-control" id="actualUSDPriceYearly" type="number" name="usd_actual_price_yearly" value="{{$plan->usd_actual_price_yearly}}" required="required" step="any">
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-12">
                            <div class="form-group">
                                <h6>USD Discount Yearly Price</h6>
                                <input class="form-control" name="usd_price_yearly" value="{{$plan->usd_price_yearly}}" id="priceUSDYearly" type="number" required="" step="any">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 col-sm-12">
                            <div class="form-group">
                                <h6>Description</h6>
                                <textarea class="form-control" cols="30" rows="10" name="description" id="descriptionInput">{{ $plan->description }}</textarea>
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-12">
                            <div class="form-group">
                                <h6>Status</h6>
                                <select class="form-control" name="status" id="statusSelect">
                                    <option value="1" {{ ( $plan->status == 1 ) ? "selected" : "" }}>Active</option>
                                    <option value="0" {{ ( $plan->status == 0 ) ? "selected" : "" }}>InActive</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12 col-sm-12">
                            <h6>Features</h6>
                            <div class="form-group form-container tableview">
                                <table class="feature-table">
                                    <thead>
                                        <tr>
                                        <th style="width:80px;">No</th>
                                        <th>Feature Title</th>
                                        <th style="width:100px;">Appearance</th>
                                        <th style="width:100px;">Feature Value</th>
                                        <th style="width:125px;">
                                            <input type="checkbox" class="feature-checkbox select_all">&nbsp&nbsp<span>Select All</span>
                                        </th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach ($categoryFeatures as $key => $categoryFeature)
                                        <tr><td colspan="3"><strong>{{ \Str::title($categoryFeature->name) }}</strong></td></tr>
                                            @foreach ($categoryFeature->features as $rowFeature)
                                                <tr class="{{ ( \App\Http\Controllers\HelperController::checkPlan($plan->features,$rowFeature->id)  == true) ? "selected" : "" }}">
                                                    <td>{{ $rowFeature->id }}</td>
                                                    <td>{{ $rowFeature->name }}</td>
                                                    <td class="center-column">
                                                        @php
                                                            $appearence = isset(json_decode($plan->appearance,true)[$rowFeature->id]) ? json_decode($plan->appearance,true)[$rowFeature->id] : [];
                                                        @endphp
                                                        @if ( $rowFeature->appearance_type == "switch" )
                                                           <select name="meta_data[{{$rowFeature->id}}]" id="switchMetaData" data-id="{{ $rowFeature->id }}"  class="form-control meta_data_input">
                                                               <option value="on" {{ ( isset($appearence["meta_value"]) &&  $appearence["meta_value"] == "on") ? "selected" : "" }}>ON</option>
                                                               <option value="off" {{ (isset($appearence["meta_value"]) && $appearence["meta_value"] == "off") ? "selected" : "" }}>OFF</option>
                                                           </select>
                                                        @else
                                                           <input type="text" name="meta_data[{{$rowFeature->id}}][]" data-id="{{$rowFeature->id}}" class="form-control meta_data_input" value="{{isset($appearence["meta_value"]) ? $appearence["meta_value"] : ''}}">
                                                        @endif
                                                       <input type="hidden" name="meta_appearance_type[{{$rowFeature->id}}][]" value="{{$rowFeature->appearance_type}}">

                                                   </td>

                                                   <td>
                                                        @if ( $rowFeature->appearance_type == "message" )
                                                            <input type="text" name="feature_meta_value[{{$rowFeature->id}}][]" data-id="{{$rowFeature->id}}" class="form-control feature-meta-value" value="{{ isset($rowFeature->meta_feature_value) ? $rowFeature->meta_feature_value : '' }}">
                                                        @endif
                                                    </td>
                                                    <td>
                                                    <input type="checkbox" name="features[]" value="{{ $rowFeature->id }}" {{ ( \App\Http\Controllers\HelperController::checkPlan($plan->features,$rowFeature->id)  == true) ? "checked" : "" }} class="feature-checkbox"></td>
                                                </tr>
                                            @endforeach
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div>
                        <input type="hidden" name="id" value="{{$plan->id}}">
                        <input class="btn btn-primary" type="submit" name="submit">
                    </div>
                </form>
            </div>
        </div>
    </div>

</div>
<script src="{{asset('assets/vendors/scripts/core.js')}}"></script>
<script src="{{asset('assets/vendors/scripts/script.min.js')}}"></script>
<script src="{{asset('assets/vendors/scripts/advanced-components.js')}}"></script>
<script src="{{asset('assets/plugins/bootstrap-tagsinput/bootstrap-tagsinput.js')}}"></script>
<script>
    $('.bg_type_id').change(function () {
        if ($(this).val() === '0' || $(this).val() === '1') {
            $('.back_image').attr('required', '');
            var x = document.getElementById("back_image_field");
            x.style.display = "block";
            $('.color_code').removeAttr('required');
            var x1 = document.getElementById("color_code_field");
            x1.style.display = "none";

        } else {
            $('.color_code').attr('required', '');
            var x = document.getElementById("color_code_field");
            x.style.display = "block";
            $('.back_image').removeAttr('required');
            var x1 = document.getElementById("back_image_field");
            x1.style.display = "none";

        }
    });

    $('#editPlanForm').on('submit', function (event) {
        event.preventDefault();
        count = 0;
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
            }
        });
        var formData = new FormData(this);
        formData.append('features', sessionStorage.getItem('selectedFeatures'));
        let id = $("input[name='id']").val();
        var url = "{{ route('plans.update', ['plan' => ':id']) }}".replace(':id', id);
        var meta_data = [];
        var meta_appearance_type = [];

        $(".selected").each(function() {
            var key = $(this).find('input[name="features[]"]').val();
            var meta_data_value = $(this).find('.meta_data_input').val();
            var meta_appearance_type_value = $(this).find('input[name^="meta_appearance_type"]').val();
            if (meta_data_value != null && meta_appearance_type_value != null) {
                if (!meta_data.hasOwnProperty(key)) {
                    meta_data[key] = [];
                }
                if (!meta_appearance_type.hasOwnProperty(key)) {
                    meta_appearance_type[key] = [];
                }

                meta_data[key].push(meta_data_value);
                meta_appearance_type[key].push(meta_appearance_type_value);
            }
        });
        $.ajax({
            url: url,
            type: 'PUT',
            dataType: 'json',
            data: {
                "name" : $("#planName").val(),
                "plan_id" : $("#planID").val(),

                "inr_price_monthly" : $("#priceMonthly").val(),
                "inr_price_yearly" : $("#priceYearly").val(),
                "inr_actual_price_monthly" : $("#actualPriceMonthly").val(),
                "inr_actual_price_yearly" : $("#actualPriceYearly").val(),

                "usd_actual_price_monthly" : $("#actualUSDPriceMonthly").val(),
                "usd_price_monthly" : $("#priceUSDMonthly").val(),
                "usd_actual_price_yearly" : $("#actualUSDPriceYearly").val(),
                "usd_price_yearly" : $("#priceUSDYearly").val(),

                "description" : $("#descriptionInput").val(),
                "features" : sessionStorage.getItem('selectedFeatures'),
                "meta_data" : meta_data,
                "meta_appearance_type" : meta_appearance_type,
                "status" : $("#statusSelect").val(),

            },
            beforeSend: function () {
                var loading_screen = document.getElementById("loading_screen");
                loading_screen.style.display = "block";
            },
            success: function (data) {
                if (data.error) {
                    $('#result').html('<div class="alert alert-danger">' + data.error + '</div>');
                } else {
                    $('#result').html('<div class="alert alert-success">' + data.success + '</div>');
                    location.reload();
                }
                sessionStorage.removeItem('selectedFeatures');
                hideFields();
                setTimeout(function () {
                    $('#result').html('');
                }, 3000);

            },
            error: function (error) {
                hideFields();
                window.alert(error.responseText);
            }

        })
    });

    $(document).on('click', '#remove_bg_info', function () {
        $(this).closest(".row").remove();
    });

    $(document).on('click', '#add_text_info', function () {
        dynamic_text_field();
    });

    $(document).on('click', '#remove_text_info', function () {
        $(this).closest(".row").remove();
    });

    $(document).on('click', '#add_component_info', function () {
        dynamic_component_field();
    });

    $(document).on('click', '#remove_component_info', function () {
        $(this).closest(".row").remove();
    });

    function hideFields() {
        $('#editPlanForm')[0].reset();
        var loading_screen = document.getElementById("loading_screen");
        loading_screen.style.display = "none";
    }

</script>

<script>
    $(document).ready(function() {
        let selectedFeatures = JSON.parse(sessionStorage.getItem('selectedFeatures')) || [];

        function updateSelectedFeatures() {
            selectedFeatures = selectedFeatures.filter(feature => feature !== "on");
            $('.feature-checkbox').each(function() {
                let featureValue = $(this).val();
                if ($(this).prop('checked')) {
                    if (!selectedFeatures.includes(featureValue)) {
                        selectedFeatures.push(featureValue);
                    }
                    $(this).closest('tr').addClass('selected');
                } else {
                    selectedFeatures = selectedFeatures.filter(feature => feature !== featureValue);
                    $(this).closest('tr').removeClass('selected');
                }
            });
            sessionStorage.setItem('selectedFeatures', JSON.stringify(selectedFeatures));
        }
         updateSelectedFeatures();
        selectedFeatures.forEach(feature => {
            $(`input[value='${feature}']`).prop('checked', true);
            $(`input[value='${feature}']`).closest('tr').addClass('selected');
        });

        $('.feature-checkbox').change(function() {
            updateSelectedFeatures();
        });

        $('.select_all').change(function() {
            let isChecked = $(this).prop('checked');
            $('.feature-checkbox').prop('checked', isChecked);
            updateSelectedFeatures();
        });

    });
</script>

</body>
</html>
