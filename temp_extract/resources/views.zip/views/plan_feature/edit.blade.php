<form method="post" id="edit_feature_form">
 @csrf
 <input class="form-control" type="textname" name="feature_id" value="{{$feature->id}}" style="display: none"/>
 <div class="form-group">
     <h7>Feature</h7>
     <div class="input-group custom">
         <input type="text" class="form-control" placeholder="Enter Feature" value="{{$feature->name}}" name="feature_name" required="" />
     </div>
 </div>
 <div class="form-group">
    <h7>Description</h7>
    <div class="input-group custom">
        <textarea class="form-control" name="description" id="selectedDescriptionInput" cols="30" rows="10">{{ $feature->description }}</textarea>
    </div>
</div>
 <div class="form-group">
     <h7>Feature Category</h7>
     <div class="input-group custom">
         <select id="selectedCategoryFeatureId" class="form-control">
            @foreach ($categoryFeatures as $categoryFeature)
                <option value="{{$categoryFeature->id}}" {{ ($feature->categoryFeatures->id == $categoryFeature->id ) ? "selected" : "" }}>{{ \Str::title($categoryFeature->name) }}</option>
            @endforeach
         </select>
     </div>
 </div>
 <div class="form-group">
    <h7>Appearance Type</h7>
    <div class="input-group custom">
        <select name="appearance_type" id="selectedAppearanceType" class="form-control">
            <option value="switch" {{ ($feature->appearance_type == "switch" ) ? "selected" : ""  }} >Switch</option>
            <option value="message" {{ ($feature->appearance_type == "message" ) ? "selected" : ""  }} >Message</option>
        </select>
    </div>
</div>
 <div class="row">
     <div class="col-sm-12">
         <button type="button" class="btn btn-primary btn-block" id="update_click">Update</button>
     </div>
 </div>
</form>
