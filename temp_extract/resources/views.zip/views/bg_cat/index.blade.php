@inject('roleManager', 'App\Http\Controllers\Utils\RoleManager')

<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>Laravel</title>
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

    <link rel="stylesheet" type="text/css" href="{{ asset('assets/vendors/styles/core.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/vendors/styles/icon-font.min.css') }}">
    <link rel="stylesheet" type="text/css"
        href="{{ asset('assets/plugins/datatables/css/dataTables.bootstrap4.min.css') }}">
    <link rel="stylesheet" type="text/css"
        href="{{ asset('assets/plugins/datatables/css/responsive.bootstrap4.min.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/vendors/styles/style.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/vendors/styles/custom.css') }}">
    <style>
        .sort-arrow {
            margin-left: 0px;
        }

        .sort-arrow.active {
            color: #1739d1ec;
        }

        .sort-arrow {
            font-family: 'dropways';
            font-size: 14px;
            color: grey;
            /* Default color */
        }

        .sort-asc::before {
            content: "\eabb";
            /* Custom icon content for up arrow */
        }

        .sort-desc::before {
            content: "\eaba";
        }

        /* Active state with blue color */
        .sort-asc.active::before,
        .sort-desc.active::before {
            color: #1b00ff;
        }

        span.sort-arrow.sort-desc {
            margin-left: -7px;
        }

        .form-row input.form-control {
            width: 297px;
        }

        .pd-20.f-left {
            float: left;
        }

        .form-row.f-right {
            padding: 20px;
            float: right;
        }

        .row ul.pagination {
            margin-bottom: 10px;
            float: right;
            margin-right: 20px;
        }
    </style>
</head>

<body class="antialiased">
    @include('layouts.header')
    <div class="main-container designer-access-container">
        <div class="pd-ltr-20 xs-pd-20-10">
            <div class="min-height-200px">
                <div class="card-box mb-30">
                    <div class="row justify-content-between pb-30 pt-30">
                        <div class="col-md-3">
                            @if ($roleManager::onlyDesignerAccess(Auth::user()->user_type))
                            <button type="button" class="btn btn-primary ml-4 mt-4" id="addNewbackgroundCatBtn">
                                + Add Background Category
                            </button>
                            @endif
                        </div>

                        <!-- Right: Filter Form -->
                        <div class="col-md-9">
                            @include('partials.filter_form', [
                                'action' => route('show_bg_cat.index'),
                            ])
                        </div>
                    </div>
                    <table id="shap_category_table" class="table table-striped">
                        <thead>
                            <tr>
                                <th>Id</th>
                                <th>User</th>
                                <th>Name</th>
                                <th class="datatable-nosort">Thumb</th>
                                <th>Sequence Number</th>
                                <th>Status</th>
                                <th class="datatable-nosort">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($allCategories as $backgroundCat)
                                <tr>
                                    <td class="table-plus">{{ $backgroundCat->id }}</td>
                                    <td>{{ $roleManager::getUploaderName($backgroundCat->emp_id) }}
                                    <td>{{ $backgroundCat->bg_category_name }}</td>
                                    <td><img src="{{ \App\Http\Controllers\Utils\ContentManager::getStorageLink($backgroundCat->bg_category_thumb) }}"
                                            style="max-width: 100px; max-height: 100px; width: auto; height: auto" />
                                    </td>
                                    <td>{{ $backgroundCat->sequence_number }}</td>
                                    @if ($backgroundCat->status == '1')
                                        <td>LIVE</td>
                                    @else
                                        <td>NOT LIVE</td>
                                    @endif
                                    <td>
                                        <button class="dropdown-item edit-background-category-btn"
                                            data-id="{{ $backgroundCat->id }}">
                                            <i class="dw dw-edit2"></i> Edit
                                        </button>

                                        @if ($roleManager::isAdminOrDesignerManager(Auth::user()->user_type))
                                            <a class="dropdown-item" href="#"
                                                onclick="deleteBackgroundCategory({{ $backgroundCat['id'] }})">
                                                <i class="dw dw-delete-3"></i> Delete
                                            </a>
                                        @endif
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                    @include('partials.pagination', ['items' => $allCategories])
                </div>
            </div>
        </div>
    </div>
    </div>

    <div class="modal fade designer-access-container" id="add_show_bg_category_model" tabindex="-1" role="dialog"
        aria-labelledby="myLargeModalLabel" aria-hidden="false">
        <div class="modal-dialog modal-dialog-centered" style="max-width: 676px;">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="myLargeModalLabel">Add Background Category</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                </div>

                <div class="modal-body">
                    <form method="post" id="show_bg_cate_form" enctype="multipart/form-data">
                        <div class="form-group">
                            <h6>Background Category Name</h6>
                            <input type="hidden" id="show_bg_category_id" name="id" value="">

                            <input class="form-control" type="textname" id="show_bg_category_name"
                                name="bg_category_name" required>
                        </div>
                        {{-- <input type="hidden" name="parent_category_id" value="0"> --}}
                        <div class="form-group">
                            <h6>Background Category Thumb</h6>
                            <input type="file" class="form-control-file form-control dynamic-file height-auto"
                                data-accept=".jpg, .jpeg, .webp, .svg" data-imgstore-id="bg_category_thumb"
                                id="bg_category_thumb" data-nameset="true">
                        </div>
                        <div class="form-group">
                            <h6>Sequence Number</h6>
                            <input class="form-control" type="number" id="sequence_number" name="sequence_number"
                                required>
                        </div>
                        <div class="form-group">
                            <h6>Status</h6>
                            <div class="col-sm-20">
                                <select class="selectpicker form-control" data-style="btn-outline-primary"
                                    id="status" name="status">
                                    <option value="1">LIVE</option>
                                    <option value="0">NOT LIVE</option>
                                </select>
                            </div>
                        </div>
                        <div>
                            <input class="btn btn-primary" type="submit" name="submit">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        const STORAGE_URL = "{{ env('STORAGE_URL') }}";
        // *Debug
        const storageUrl = "{{ config('filesystems.storage_url') }}";
    </script>
    <script src="{{ asset('assets/vendors/scripts/core.js') }}"></script>
    <script src="{{ asset('assets/vendors/scripts/script.min.js') }}"></script>
    <script src="{{ asset('assets/vendors/scripts/process.js') }}"></script>
    <script src="{{ asset('assets/vendors/scripts/layout-settings.js') }}"></script>
    <script src="{{ asset('assets/js/dynamicfile.js') }}"></script>
    <script src="{{ asset('assets/js/role_access.js') }}"></script>
    <script>
        function deleteBackgroundCategory(id) {
            event.preventDefault();
            if (confirm('Are you sure you want to delete this Background Category?')) {
                $.ajax({
                    url: "{{ route('show_bg_cat.destroy', ':id') }}".replace(':id', id),
                    type: 'DELETE',
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    success: function(response) {
                        if (response.success) {
                            window.location.reload();
                        } else {
                            alert(response.error);
                        }
                    },
                    error: function(xhr) {

                    }
                });
            }
        }
        

        $(document).ready(function() {
            $('#addNewbackgroundCatBtn').on('click', function() {
                resetForm();
                $('#add_show_bg_category_model').modal('show');
            });

            $(document).on('click', '.edit-background-category-btn', function() {
                const id = $(this).data('id');

                $.get(`{{ url('show_bg_cat') }}/${id}/edit`, function(res) {
                    if (res.status) {
                        const data = res.data;
                        $('#add_show_bg_category_model').modal('show');
                        $('#show_bg_category_id').val(data.id);
                        $('#show_bg_category_name').val(data.bg_category_name);
                        $('#parent_category_id').val(data.parent_category_id);
                        $('#sequence_number').val(data.sequence_number);
                        $('#status').val(data.status);

                        if (data.bg_category_thumb) {
                            const imageUrl = getStorageLink(data.bg_category_thumb);
                            $('#bg_category_thumb').attr('data-value', imageUrl);
                            dynamicFileCmp();
                        }
                    }
                });
            });

            $('#show_bg_cate_form').on('submit', function(e) {
                e.preventDefault();

                const formData = new FormData(this);

                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });

                $.ajax({
                    url: `{{ route('show_bg_cat.store') }}`,
                    type: 'POST',
                    data: formData,
                    contentType: false,
                    processData: false,
                    success: function(data) {
                        if (data.status) {
                            location.reload();
                        } else {
                            alert(data.error || 'Error occurred!');
                        }
                    },
                    error: function(xhr) {
                        alert(xhr.responseText);
                    }
                });
            });

            function resetForm() {
                $('#show_bg_cate_form')[0].reset();
                $('#show_bg_category_id').val('');
                resetDynamicFileValue('thumb_files')
                $('#result').html('');
            }
        });
    </script>
</body>

</html>
