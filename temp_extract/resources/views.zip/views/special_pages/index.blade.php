@inject('roleManager', 'App\Http\Controllers\Utils\RoleManager')

<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>Laravel</title>
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/vendors/styles/core.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/vendors/styles/icon-font.min.css') }}">
    <link rel="stylesheet" type="text/css"
        href="{{ asset('assets/plugins/datatables/css/dataTables.bootstrap4.min.css') }}">
    <link rel="stylesheet" type="text/css"
        href="{{ asset('assets/plugins/datatables/css/responsive.bootstrap4.min.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/vendors/styles/style.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/plugins/switchery/switchery.min.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/vendors/styles/loader.css') }}">
    <style>
    </style>
</head>

<body class="antialiased">
    @include('layouts.header')
    <div class="main-container">
        <div id="loading_screen" style="display: none;">
            <div id="loader-wrapper">
                <div id="loader"></div>
                <div class="loader-section section-left"></div>
                <div class="loader-section section-right"></div>
            </div>
        </div>
        <div class="pd-ltr-20 xs-pd-20-10">
            <div class="min-height-200px">
                <div class="card-box mb-30">
                    <div class="row-header">
                        <div class="pd-20">
                            <div class="pd-20">
                                @if ($roleManager::onlySeoAccess(Auth::user()->user_type) && !$roleManager::isSeoManager(Auth::user()->user_type))
                                    <a class="btn btn-primary" href="create_pages" role="button"> Add </a>
                                @endif
                            </div>
                        </div>
                        <div class="col-sm-12 col-md-6">
                            <div class="pt-20">
                                <form action="{{ route('special_page.index') }}" method="GET">
                                    <div class="form-row f-right">
                                        <div class="col">
                                            <input type="text" name="query" class="form-control"
                                                placeholder="Search..." value="{{ request()->input('query') }}">
                                        </div>
                                        <div class="col">
                                            <select name="per_page" class="form-control">
                                                <option value="10"
                                                    {{ request('per_page') == '10' ? 'selected' : '' }}>10
                                                </option>
                                                <option value="20"
                                                    {{ request('per_page') == '20' ? 'selected' : '' }}>20
                                                </option>
                                                <option value="50"
                                                    {{ request('per_page') == '50' ? 'selected' : '' }}>50
                                                </option>
                                                <option value="100"
                                                    {{ request('per_page') == '100' ? 'selected' : '' }}>
                                                    100</option>
                                                <option value="500"
                                                    {{ request('per_page') == '500' ? 'selected' : '' }}>
                                                    500</option>
                                                <option value="all"
                                                    {{ request('per_page') == 'all' ? 'selected' : '' }}>
                                                    All</option>
                                            </select>

                                        </div>
                                        <div class="col">
                                            <select name="status" class="form-control">
                                                <option value="all"
                                                    {{ request('status') == 'all' ? 'selected' : '' }}>All</option>
                                                <option value="0"
                                                    {{ request('status') == '0' ? 'selected' : '' }}>Draft</option>
                                                <option value="1"
                                                    {{ request('status') == '1' ? 'selected' : '' }}>Publish</option>
                                            </select>
                                        </div>
                                        <div class="col">
                                            <button type="submit" class="btn btn-primary"
                                                style="margin-top: 0;">Apply</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <table id="shap_category_table" class="table table-striped">

                        <thead>
                            <tr>
                                <th class="datatable-nosort">Id</th>
                                <th class="datatable-nosort">Created Record</th>
                                <th class="datatable-nosort">Updated Record</th>
                                <th class="datatable-nosort">User</th>
                                <th class="datatable-nosort">Title</th>
                                <th>Description</th>
                                <th>Meta title</th>
                                <th>Meta Description</th>
                                <th>No Index</th>
                                <th>Status</th>
                                <th class="datatable-nosort">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($specialPages as $specialPage)
                                <tr>
                                    <td class="table-plus">{{ $specialPage->id }}</td>
                                    <td class="table-plus">{{ $specialPage->created_at }}</td>
                                    <td class="table-plus">{{ $specialPage->updated_at }}</td>
                                    <td>{{ $roleManager::getUploaderName($specialPage->emp_id) }}</td>
                                    <td class="table-plus">{{ $specialPage->title }}</td>
                                    <td class="table-plus">{{ $specialPage->description }}</td>
                                    <td class="table-plus">{{ $specialPage->meta_title }}</td>
                                    <td class="table-plus">{{ $specialPage->meta_desc }}</td>
                                    @if ($roleManager::isAdminOrSeoManager(Auth::user()->user_type))
                                        @if ($specialPage->no_index == '1')
                                            <td><label id="noindex_label_{{ $specialPage->id }}"
                                                    style="display: none;">TRUE</label><Button style="border: none"
                                                    onclick="noindex_click(this, '{{ $specialPage->id }}')"><input
                                                        type="checkbox" checked class="switch-btn" data-size="small"
                                                        data-color="#0059b2" /></Button></td>
                                        @else
                                            <td><label id="noindex_label_{{ $specialPage->id }}"
                                                    style="display: none;">FALSE</label><Button style="border: none"
                                                    onclick="noindex_click(this, '{{ $specialPage->id }}')"><input
                                                        type="checkbox" class="switch-btn" data-size="small"
                                                        data-color="#0059b2" /></Button></td>
                                        @endif
                                    @else
                                        @if ($specialPage->no_index == '1')
                                            <td>True</td>
                                        @else
                                            <td>False</td>
                                        @endif
                                    @endif
                                    <td class="table-plus">{{ $specialPage->status == 0 ? 'Draft' : 'Publish' }}</td>
                                    <td>
                                        <button class="dropdown-item"><a
                                                href="{{ route('edit_pages', ['id' => $specialPage->id]) }}"><i
                                                    class="dw dw-edit2"></i>
                                                Edit</a></button>
                                        @if ($roleManager::isAdminOrSeoManager(Auth::user()->user_type))
                                            <a class="dropdown-item" href="#"
                                                onclick="event.preventDefault(); deletePages({{ $specialPage->id }})">
                                                <i class="dw dw-delete-3"></i> Delete
                                            </a>
                                        @endif
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                    <div class="row">
                        <div class="col-sm-12 col-md-7">
                            <div class="dataTables_info" role="status" aria-live="polite">
                                Showing {{ $specialPages->firstItem() }} to {{ $specialPages->lastItem() }} of
                                {{ $specialPages->total() }} entries
                            </div>
                        </div>
                        <div class="col-sm-12 col-md-5">
                            <div class="dataTables_paginate paging_simple_numbers">
                                {{ $specialPages->appends(request()->input())->links('pagination::bootstrap-4') }}
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>



    <script src="{{ asset('assets/vendors/scripts/core.js') }}"></script>
    <script src="{{ asset('assets/vendors/scripts/script.min.js') }}"></script>
    <script src="{{ asset('assets/vendors/scripts/process.js') }}"></script>
    <script src="{{ asset('assets/vendors/scripts/layout-settings.js') }}"></script>
    <script src="{{ asset('assets/plugins/datatables/js/jquery.dataTables.min.js') }}"></script>
    <script src="{{ asset('assets/plugins/datatables/js/dataTables.bootstrap4.min.js') }}"></script>
    <script src="{{ asset('assets/plugins/datatables/js/dataTables.responsive.min.js') }}"></script>
    <script src="{{ asset('assets/plugins/datatables/js/responsive.bootstrap4.min.js') }}"></script>
    <script src="{{ asset('assets/plugins/switchery/switchery.min.js') }}"></script>
    <script src="{{ asset('assets/vendors/scripts/advanced-components.js') }}"></script>
    <!-- Datatable Setting js -->
    <script src="{{ asset('assets/vendors/scripts/datatable-setting.js') }}"></script>

    <script>
        function deletePages(id) {
            if (confirm('Are you sure you want to delete this page')) {
                $.ajax({
                    url: "{{ route('special_page.destroy', ':id') }}".replace(':id', id),
                    type: 'DELETE',
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    success: function(response) {
                        if (response.success) {
                            window.location.reload();
                        } else {
                            alert(response.error);
                        }
                    },
                    error: function(xhr) {}
                });
            }
        }

        function noindex_click(parentElement, $id) {
            let element = parentElement.firstElementChild;
            const originalChecked = element.checked;
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                }
            });

            var status = $id;
            var url = "{{ route('check_n_i') }}";
            var formData = new FormData();
            formData.append('id', $id);
            formData.append('type', 's_page');
            $.ajax({
                url: url,
                type: 'POST',
                data: formData,
                beforeSend: function() {
                    var loading_screen = document.getElementById("loading_screen");
                    loading_screen.style.display = "block";
                },
                success: function(data) {
                    var loading_screen = document.getElementById("loading_screen");
                    loading_screen.style.display = "none";
                    if (data.error) {
                        alert(data.error);
                        element.checked = !originalChecked;
                        element.dispatchEvent(new Event('change', {
                            bubbles: true
                        }));
                    } else {
                        var x = document.getElementById("noindex_label_" + $id);
                        if (x.innerHTML === "TRUE") {
                            x.innerHTML = "FALSE";
                        } else {
                            x.innerHTML = "TRUE";
                        }
                    }

                },
                error: function(error) {
                    var loading_screen = document.getElementById("loading_screen");
                    loading_screen.style.display = "none";
                    window.alert(error.responseText);
                },
                cache: false,
                contentType: false,
                processData: false
            })
        }
    </script>
    <script>
        const sortTable = (event, column, sortType) => {
            event.preventDefault();
            let url = new URL(window.location.href);
            url.searchParams.set('sort_by', column);
            url.searchParams.set('sort_order', sortType);
            window.location.href = url.toString();
        }
    </script>
</body>

</html>
