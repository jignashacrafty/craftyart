@inject('helperController', 'App\Http\Controllers\HelperController')
@inject('roleManager', 'App\Http\Controllers\Utils\RoleManager')

<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>Laravel</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="{{asset('assets/vendors/styles/core.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('assets/vendors/styles/icon-font.min.css')}}">
    <link rel="stylesheet" type="text/css"
          href="{{asset('assets/plugins/datatables/css/dataTables.bootstrap4.min.css')}}">
    <link rel="stylesheet" type="text/css"
          href="{{asset('assets/plugins/datatables/css/responsive.bootstrap4.min.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('assets/vendors/styles/style.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('assets/plugins/switchery/switchery.min.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('assets/vendors/styles/loader.css')}}">

    <style>
        .sort-arrow {
            margin-left: 0px;
        }

        .sort-arrow.active {
            color: #1739d1ec;
        }

        .sort-arrow {
            font-family: 'dropways';
            font-size: 14px;
            color: grey;
            /* Default color */
        }

        .sort-asc::before {
            content: "\eabb";
            /* Custom icon content for up arrow */
        }

        .sort-desc::before {
            content: "\eaba";
        }

        /* Active state with blue color */
        .sort-asc.active::before,
        .sort-desc.active::before {
            color: #1b00ff;
        }

        span.sort-arrow.sort-desc {
            margin-left: -7px;
        }

        .dataTables_paginate.paging_simple_numbers ul.pagination {
            float: right;
            margin-right: 10px;
            margin-bottom: 10px;
        }

        .form-row input.form-control {
            width: 297px;
        }

        .pd-20.f-left {
            float: left;
        }

        .form-row.f-right {
            padding: 20px;
            float: right;
        }
    </style>
</head>

<body class="antialiased">

@include('layouts.header')

<div class="main-container">
    <div id="loading_screen" style="display: none;">
        <div id="loader-wrapper">
            <div id="loader"></div>
            <div class="loader-section section-left"></div>
            <div class="loader-section section-right"></div>
        </div>
    </div>
    <div class="pd-ltr-20 xs-pd-20-10">
        <div class="min-height-200px">
            <div class="card-box mb-30">
                <div class="pb-20">

                    <div class="pd-20 f-left">
                        @if ($roleManager::onlySeoAccess(Auth::user()->user_type) && !$roleManager::isSeoManager(Auth::user()->user_type))
                        <a class="btn btn-primary" href="create_virtual_cat" role="button"> Add New Category </a>
                        @endif
                    </div>

                    <table class="table table-striped mt-2">
                        <form method="GET" action="{{ route('show_new_cat') }}" id="filter-form">
                            <div class="form-row f-right">
                                <div class="col">
                                    <input type="text" name="query" class="form-control" placeholder="Search..."
                                           value="{{ request('query') }}">
                                </div>
                                <div class="col">
                                    <select name="per_page" class="form-control">
                                        <option value="10" {{ request(
                                        'per_page') == '10' ? 'selected' : '' }}>10
                                        </option>
                                        <option value="20" {{ request(
                                        'per_page') == '20' ? 'selected' : '' }}>20
                                        </option>
                                        <option value="50" {{ request(
                                        'per_page') == '50' ? 'selected' : '' }}>50
                                        </option>
                                        <option value="100" {{ request(
                                        'per_page') == '100' ? 'selected' : '' }}>100
                                        </option>
                                        <option value="500" {{ request(
                                        'per_page') == '500' ? 'selected' : '' }}>500
                                        </option>
                                        <option value="All" {{ request(
                                        'per_page') == 'All' ? 'selected' : '' }}>All
                                        </option>
                                    </select>
                                </div>
                                <div class="col">
                                    <button type="submit" class="btn btn-primary">Apply</button>
                                </div>
                            </div>
                        </form>
                        <thead>
                        <tr>
                            <th><a href="javascript:void(0);">Category Id
                                    @php
                                    $sortOrderById = "desc";
                                    if (request('sort_by') == 'id' || request('sort_by') == null) {
                                    $sortOrderById = request('sort_order', 'desc') == 'asc' ? 'asc' : 'desc';
                                    }
                                    if (request('sort_by') != null && request('sort_by') != 'id') {
                                    $sortOrderById = "";
                                    }
                                    @endphp
                                    <span class="sort-arrow sort-asc {{ $sortOrderById == 'asc' ? 'active' : '' }}"
                                          onclick="sortTable(event,'id','asc')"></span>
                                    <span class="sort-arrow sort-desc {{ $sortOrderById == 'desc' ? 'active' : '' }}"
                                          onclick="sortTable(event,'id','desc')"></span>
                                </a>
                            </th>
                            <th>App Name</th>
                            <th>User</th>
                            <th>
                                <a href="javascript:void(0);">
                                    Category Name
                                    @php
                                    $sortOrderByName = "";
                                    if (request('sort_by') == 'category_name') {
                                    $sortOrderByName = request('sort_order', 'desc') == 'asc' ? 'asc' : 'desc';
                                    }
                                    @endphp
                                    <span class="sort-arrow sort-asc {{ $sortOrderByName == 'asc' ? 'active' : '' }}"
                                          onclick="sortTable(event,'category_name','asc')"></span>
                                    <span class="sort-arrow sort-desc {{ $sortOrderByName == 'desc' ? 'active' : '' }}"
                                          onclick="sortTable(event,'category_name','desc')"></span>
                                </a>
                            </th>
                            <th>
                                <a href="javascript:void(0);">
                                    Parent Category Name
                                    @php
                                    $sortOrderByParentCatID = "";
                                    if (request('sort_by') == 'parent_category_id') {
                                    $sortOrderByParentCatID = request('sort_order', 'desc') == 'asc' ? 'asc' : 'desc';
                                    }
                                    @endphp
                                    <span class="sort-arrow sort-asc {{ $sortOrderByParentCatID == 'asc' ? 'active' : '' }}"
                                          onclick="sortTable(event,'parent_category_id','asc')"></span>
                                    <span class="sort-arrow sort-desc {{ $sortOrderByParentCatID == 'desc' ? 'active' : '' }}"
                                          onclick="sortTable(event,'parent_category_id','desc')"></span>
                                </a>
                            </th>
                            <th>ID Name</th>
                            <th class="datatable-nosort">Category Thumb</th>
                            <th class="datatable-nosort">Mockup</th>
                            <th>No Index</th>
                            <th>Sequence Number</th>
                            @if ($roleManager::isAdminOrManager(Auth::user()->id))
                            <th>IMP</th>
                            @endif
                            <th>Status</th>
                            <th class="datatable-nosort">Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach ($catArray as $cat)
                        <tr>
                            <td class="table-plus">{{$cat->id}}</td>

                            <td>{{ $helperController::getAppName($cat->app_id) }}</td>

                            <td>{{ $roleManager::getUploaderName($cat->emp_id) }}</td>

                            <td><a target="_blank" href="show_item?new_cat={{$cat->id}}">{{$cat->category_name}}</a>
                            </td>
                            <td style="position: relative;">
                                <label>{{ $helperController::getParentNewCatName($cat->parent_category_id, true)
                                    }}</label>
                            </td>

                            <td>{{$cat->id_name}}</td>

                            <td><img src="{{ config('filesystems.storage_url') }}{{$cat->category_thumb}}"
                                     style="max-width: 100px; max-height: 100px; width: auto; height: auto"/>
                            </td>
                            <td><img src="{{ config('filesystems.storage_url') }}{{$cat->mockup}}"
                                     style="max-width: 100px; max-height: 100px; width: auto; height: auto"/>
                            </td>

                            @if ($roleManager::isAdminOrSeoManager(Auth::user()->user_type))
                                @if($cat->no_index == '1')
                                    <td><label id="noindex_label_{{$cat->id}}"
                                            style="display: none;">TRUE</label><Button style="border: none"
                                            onclick="noindex_click(this, '{{$cat->id}}')"><input type="checkbox"
                                                checked class="switch-btn" data-size="small"
                                                data-color="#0059b2" /></Button></td>
                                @else
                                    <td><label id="noindex_label_{{$cat->id}}"
                                            style="display: none;">FALSE</label><Button style="border: none"
                                            onclick="noindex_click(this, '{{$cat->id}}')"><input type="checkbox"
                                                class="switch-btn" data-size="small"
                                                data-color="#0059b2" /></Button></td>
                                @endif
                            @else 
                                @if($cat->no_index == '1')
                                    <td>True</td>
                                @else
                                    <td>False</td>
                                @endif
                            @endif

                            <td>{{$cat->sequence_number}}</td>

                            @if ($roleManager::isAdminOrManager(Auth::user()->id))
                            @if ($cat->parent_category_id == 0)
                            @if($cat->imp == '1')
                            <td><label id="imp_label_{{$cat->id}}" style="display: none;">TRUE</label>
                                <Button style="border: none"
                                        onclick="imp_click('{{$cat->id}}')"><input type="checkbox" checked
                                                                                   class="switch-btn"
                                                                                   data-size="small"
                                                                                   data-color="#0059b2"/></Button>
                            </td>
                            @else
                            <td><label id="imp_label_{{$cat->id}}" style="display: none;">FALSE</label>
                                <Button
                                        style="border: none" onclick="imp_click('{{$cat->id}}')"><input type="checkbox"
                                                                                                        class="switch-btn"
                                                                                                        data-size="small"
                                                                                                        data-color="#0059b2"/>
                                </Button>
                            </td>
                            @endif
                            @else
                            <td> N/A</td>
                            @endif
                            @endif

                            @if($cat->status == '1')
                            <td>LIVE</td>
                            @else
                            <td>NOT LIVE</td>
                            @endif

                            <td>
                                <div class="dropdown">
                                    <a class="btn btn-link font-24 p-0 line-height-1 no-arrow dropdown-toggle" href="#"
                                       role="button"
                                       data-toggle="dropdown">
                                        <i class="dw dw-more"></i>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-right dropdown-menu-icon-list">
                                        <Button class="dropdown-item" onclick="notification_click('{{$cat->id}}')"
                                                data-backdrop="static" data-toggle="modal"
                                                data-target="#send_notification_model"><i
                                                    class="dw dw-notification1"></i>Send Notification
                                        </Button>
                                        <a class="dropdown-item" href="edit_virtual_cat/{{$cat->id}}"><i
                                                    class="dw dw-edit2"></i>
                                            Edit</a>
                                        @if ($roleManager::isAdminOrManager(Auth::user()->id))
                                        <a class="dropdown-item" href="delete_new_cat/{{$cat->id}}"><i
                                                    class="dw dw-delete-3"></i>
                                            Delete</a>
                                        @endif
                                    </div>
                                </div>
                            </td>

                            <div class="modal fade" id="Medium-modal" tabindex="-1" role="dialog"
                                 aria-labelledby="myLargeModalLabel" aria-hidden="true">
                                <div class="modal-dialog modal-dialog-centered">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h4 class="modal-title" id="myLargeModalLabel">Delete</h4>
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                                                ×
                                            </button>
                                        </div>
                                        <div class="modal-body">
                                            <p>Are you sure you want to delete?</p>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">No
                                            </button>
                                            <a href="delete_cat/{{$cat->id}}">
                                                <button type="button" class="btn btn-primary">Yes,
                                                    Delete
                                                </button>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
                <div class="row">
                    <div class="col-sm-12 col-md-7">
                        <div class="dataTables_info" role="status" aria-live="polite">
                            Showing {{ $catArray->firstItem() }} to {{ $catArray->lastItem() }} of
                            {{ $catArray->total() }} entries
                        </div>
                    </div>
                    <div class="col-sm-12 col-md-5">
                        <div class="dataTables_paginate paging_simple_numbers">
                            {{ $catArray->appends(request()->input())->links('pagination::bootstrap-4') }}
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<div class="modal fade" id="send_notification_model" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel"
     aria-hidden="false">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="myLargeModalLabel">Send Notification</h5>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            </div>

            <div class="modal-body" id="notification_model">
            </div>

        </div>
    </div>
</div>

<script src="{{asset('assets/vendors/scripts/core.js')}}"></script>
<script src="{{asset('assets/vendors/scripts/script.min.js')}}"></script>
<script src="{{asset('assets/vendors/scripts/process.js')}}"></script>
<script src="{{asset('assets/vendors/scripts/layout-settings.js')}}"></script>
<script src="{{asset('assets/plugins/datatables/js/jquery.dataTables.min.js')}}"></script>
<script src="{{asset('assets/plugins/datatables/js/dataTables.bootstrap4.min.js')}}"></script>
<script src="{{asset('assets/plugins/datatables/js/dataTables.responsive.min.js')}}"></script>
<script src="{{asset('assets/plugins/datatables/js/responsive.bootstrap4.min.js')}}"></script>
<script src="{{asset('assets/plugins/switchery/switchery.min.js')}}"></script>
<script src="{{asset('assets/vendors/scripts/advanced-components.js')}}"></script>
<!-- Datatable Setting js -->
<script src="{{asset('assets/vendors/scripts/datatable-setting.js')}}"></script>

<script>
    function notification_click($id) {
        $("#notification_model").empty();
        html =
            '<form method="post" id="notification_form" enctype="multipart/form-data"> @csrf <input class="form-control" type="textname" name="temp_id" value="' +
            $id +
            '" style="display: none"/> <div class="form-group"> <h7>Title</h7> <div class="input-group custom"><input type="text" class="form-control" placeholder="Title" name="title" required="" /> </div> </div> <div class="form-group"> <h7>Description</h7> <div class="input-group custom"><input type="text" class="form-control" placeholder="Description" name="description" required="" /> </div> </div> <div class="form-group"> <h7>Large Icon</h7> <div class="input-group custom"> <input type="file" class="form-control" name="large_icon" /> </div> </div> <div class="form-group"> <h7>Big Picture</h7> <div class="input-group custom"> <input type="file" class="form-control" name="big_picture" /> </div> </div> <div class="row"> <div class="col-sm-12"> <button type="button" class="btn btn-primary btn-block" id="send_click">Send</button> </div> </div> </form>';
        $("#notification_model").append(html);
    }

    $(document).on('click', '#send_click', function () {
        event.preventDefault();

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
            }
        });

        var formData = new FormData(document.getElementById("notification_form"));
        var status = formData.get("temp_id");


        var url = "{{route('cat.notification', "
    :
        status
        ")}}";
        url = url.replace(":status", status);

        $.ajax({
            url: url,
            type: 'POST',
            data: formData,
            beforeSend: function () {
                $('#send_notification_model').modal('toggle');
                var loading_screen = document.getElementById("loading_screen");
                loading_screen.style.display = "block";
            },
            success: function (data) {
                var loading_screen = document.getElementById("loading_screen");
                loading_screen.style.display = "none";
                if (data.error) {
                    window.alert(data.error);
                } else {
                    window.alert(data.success);
                }

            },
            error: function (error) {
                var loading_screen = document.getElementById("loading_screen");
                loading_screen.style.display = "none";
                window.alert(error.responseText);
            },
            cache: false,
            contentType: false,
            processData: false
        })
    });

    function noindex_click(parentElement, $id) {
        let element = parentElement.firstElementChild;
        const originalChecked = element.checked;
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
            }
        });

        var status = $id;
        var url = "{{route('check_n_i')}}";
        var formData = new FormData();
        formData.append('id', $id);
        formData.append('type', 'virtual_cat');
        $.ajax({
            url: url,
            type: 'POST',
            data: formData,
            beforeSend: function () {
                var loading_screen = document.getElementById("loading_screen");
                loading_screen.style.display = "block";
            },
            success: function (data) {
                var loading_screen = document.getElementById("loading_screen");
                loading_screen.style.display = "none";
                if (data.error) {
                    alert(data.error);
                    element.checked = !originalChecked;
                    element.dispatchEvent(new Event('change', { bubbles: true }));
                } else {
                    var x = document.getElementById("noindex_label_" + $id);
                    if (x.innerHTML === "TRUE") {
                        x.innerHTML = "FALSE";
                    } else {
                        x.innerHTML = "TRUE";
                    }
                }

            },
            error: function (error) {
                var loading_screen = document.getElementById("loading_screen");
                loading_screen.style.display = "none";
                window.alert(error.responseText);
            },
            cache: false,
            contentType: false,
            processData: false
        })
    }

    function imp_click($id) {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
            }
        });

        var status = $id;
        var url = "{{route('cat.imp', "
    :
        status
        ")}}";
        url = url.replace(":status", status);
        var formData = new FormData();
        formData.append('id', $id);
        formData.append('isNew', '1');
        $.ajax({
            url: url,
            type: 'POST',
            data: formData,
            beforeSend: function () {
                var loading_screen = document.getElementById("loading_screen");
                loading_screen.style.display = "block";
            },
            success: function (data) {
                var loading_screen = document.getElementById("loading_screen");
                loading_screen.style.display = "none";
                if (data.error) {
                    window.alert(data.error);
                } else {
                    var x = document.getElementById("imp_label_" + $id);
                    if (x.innerHTML === "TRUE") {
                        x.innerHTML = "FALSE";
                    } else {
                        x.innerHTML = "TRUE";
                    }
                }

            },
            error: function (error) {
                var loading_screen = document.getElementById("loading_screen");
                loading_screen.style.display = "none";
                window.alert(error.responseText);
            },
            cache: false,
            contentType: false,
            processData: false
        })
    }
</script>
<script>
    const sortTable = (event, column, sortType) => {
        event.preventDefault();
        let url = new URL(window.location.href);
        url.searchParams.set('sort_by', column);
        url.searchParams.set('sort_order', sortType);
        window.location.href = url.toString();
    }
</script>
</body>

</html>
