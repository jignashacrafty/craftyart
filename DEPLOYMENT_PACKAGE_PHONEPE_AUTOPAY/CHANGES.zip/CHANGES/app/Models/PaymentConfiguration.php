---------------------------check and
------------------------------------------------------add--------------------------------------


class PaymentConfiguration extends Model
{
protected $table = 'payment_configurations';
protected $connection = 'mysql';
use HasFactory;

protected $fillable = [
'payment_scope',
'gateway',
'credentials',
'payment_types',
'is_active'
];

protected $casts = [
'credentials' => 'array',
'payment_types' => 'array',
'is_active' => 'boolean',
];
}