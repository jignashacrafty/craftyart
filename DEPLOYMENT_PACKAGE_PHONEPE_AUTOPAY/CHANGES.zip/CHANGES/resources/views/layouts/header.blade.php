---------------------------add------------------------------




<!-- PhonePe AutoPay Management -->
<li
    class="dropdown {{ in_array(Route::currentRouteName(), ['phonepe.dashboard', 'phonepe.transactions.index', 'phonepe.transactions.show', 'phonepe.notifications.index', 'phonepe.notifications.show']) ? 'show' : '' }}">
    <a href="javascript:;" class="dropdown-toggle">
        <span class="micon">
            <i class="icon-copy fa fa-mobile" style="font-size: 22px; color: #1abc9c;"></i>
        </span>
        <span class="mtext">PhonePe AutoPay</span>
    </a>
    <ul class="submenu"
        style="display: {{ in_array(Route::currentRouteName(), ['phonepe.dashboard', 'phonepe.transactions.index', 'phonepe.transactions.show', 'phonepe.notifications.index', 'phonepe.notifications.show']) ? 'block' : 'none' }};">
        <li>
            <a href="{{ route('phonepe.dashboard') }}"
                class="{{ Route::currentRouteName() == 'phonepe.dashboard' ? 'selectSubMenu' : '' }}">
                <i class="icon-copy fa fa-dashboard" style="margin-right: 8px;"></i> Dashboard
            </a>
        </li>
        <li>
            <a href="{{ route('phonepe.transactions.index') }}"
                class="{{ in_array(Route::currentRouteName(), ['phonepe.transactions.index', 'phonepe.transactions.show']) ? 'selectSubMenu' : '' }}">
                <i class="icon-copy fa fa-exchange" style="margin-right: 8px;"></i> Transactions
            </a>
        </li>
        <li>
            <a href="{{ route('phonepe.notifications.index') }}"
                class="{{ in_array(Route::currentRouteName(), ['phonepe.notifications.index', 'phonepe.notifications.show']) ? 'selectSubMenu' : '' }}">
                <i class="icon-copy fa fa-bell" style="margin-right: 8px;"></i> Notifications
            </a>
        </li>
    </ul>
</li>