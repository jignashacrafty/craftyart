<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\NewCategory;
use App\Models\VirtualCategory;
use App\Models\SpecialKeyword;
use App\Models\SpecialPage;
use App\Models\Design;
use Illuminate\Http\Request;
use Carbon\Carbon;

class NoIndexController extends AppBaseController
{
    function checkNoindex(Request $request)
    {
        $type = $request->get('type');

        $res = null;

        if ($type == 'template') {
            $res = Design::find($request->id);
        } else if ($type == 'cat') {
            $res = Category::find($request->id);
        } else if ($type == 'new_cat') {
            $res = NewCategory::find($request->id);
        } else if ($type == 'virtual_cat') {
            $res = VirtualCategory::find($request->id);
        }else if ($type == 'k_page') {
            $res = SpecialKeyword::find($request->id);
        } else if ($type == 's_page') {
            $res = SpecialPage::find($request->id);
        }

        if ($res) {
            if ($res->no_index == 1) {
                $res->no_index = 0;
            } else {
                $res->no_index = 1;
            }

            if ($type == 'template') {
                if($res->no_index == 0) {
                if(!isset($res->h2_tag) || !isset($res->description) || !isset($res->meta_description)){
                        return response()->json([
                            'error' => 'Page is index please add H2, Description and Meta Description '
                        ]);
                    }
                } else {
                    if(isset($res->h2_tag) || isset($res->description) || isset($res->meta_description)){
                        if(!isset($res->h2_tag)){
                            return response()->json([
                                'error' => 'Description or meta description available so H2 is Required'
                            ]);
                        }
                        if(!isset($res->description)){
                            return response()->json([
                                'error' => 'H2 or meta description available so description is Required'
                            ]);
                        }
                        if(!isset($res->meta_description)){
                            return response()->json([
                                'error' => 'Description or h2 available so Meta Description is Required'
                            ]);
                        }
                    }
                }
            }

            $res->save();
            return response()->json([
                'success' => "done"
            ]);
        } else {
            return response()->json([
                'error' => "Error"
            ]);
        }

    }
}

