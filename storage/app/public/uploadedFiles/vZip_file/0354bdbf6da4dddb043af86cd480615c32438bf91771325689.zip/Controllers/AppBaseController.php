<?php

namespace App\Http\Controllers;
use App\Http\Controllers\Utils\RoleManager;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Http\Request;
use Illuminate\Http\Response;

class AppBaseController extends Controller
{

    public $filters = [];

    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Send a success response.
     *
     * @param  string|array $message
     * @param  array|null $data
     * @param  int $code
     * @return \Illuminate\Http\Response
     */
    protected function sendSuccessResponse($message, $data = null, $code = Response::HTTP_OK): Response
    {
        return response()->json([
            'status' => true,
            'success' => $message,
            'data' => $data,
        ], $code);
    }

    /**
     * Send an error response.
     *
     * @param  string|array $message
     * @param  int $code
     * @return \Illuminate\Http\Response
     */
    protected function sendErrorResponse($message): Response
    {
        return response()->json([
            'status' => false,
            'error' => $message,
        ]);
    }

    /**
     * Apply dynamic filters to the query based on the specified columns and values.
     *
     * @param Illuminate\Database\Eloquent\Builder $query The Eloquent query builder
     * @param array $filters An array of columns to filter by
     * @param array $values An array of values to filter with
     * @return Illuminate\Database\Eloquent\Builder The modified query builder
     */
    // protected function applyFilters($query,$filters, $values)
    // {
    //     if ($values !== '') {
    //         foreach ($filters as $column) {
    //             $query->orWhere($column, 'like', "%$values%");
    //         }
    //     }
    //     return $query;
    // }

    protected function applyFilters($query, $filters, $values): Illuminate\Database\Eloquent\Builder
    {
        if ($values !== '') {
            foreach ($filters as $column) {
                if (str_contains($column, '.')) {
                    // Split the column to get the relationship and the column name
                    [$relation, $relationColumn] = explode('.', $column);

                    // Apply the filter to the relation
                    $query->orWhereHas($relation, function ($subQuery) use ($relationColumn, $values) {
                        $subQuery->where($relationColumn, 'like', "%$values%");
                    });
                } else {
                    // Apply the filter to the main query
                    $query->orWhere($column, 'like', "%$values%");
                }
            }
        }
        return $query;
    }

    /*public function applyFiltersAndPagination(Request $request, Builder $query, array $searchableFields = ['name']): Collection|LengthAwarePaginator|array
    {
        if ($request->filled('query')) {
            $searchTerm = $request->input('query');
            $query->where(function ($q) use ($searchableFields, $searchTerm) {
                foreach ($searchableFields as $field) {
                    $q->orWhere($field, 'like', '%' . $searchTerm . '%');
                }
            });
        }
        $sortBy = $request->input('sort_by', 'id');
        $sortOrder = in_array($request->input('sort_order'), ['asc', 'desc']) ? $request->input('sort_order') : 'desc';
        $query->orderBy($sortBy, $sortOrder);
        $perPage = $request->input('per_page', 10);
        dd($perPage);
        if ($perPage === 'all') {
            return $query->get();
        }
        return $query->paginate((int) $perPage);
    }*/

    public function applyFiltersAndPagination(Request $request, Builder $query, array $searchableFields = ['id'],array $relationSearchConfig = [],$default = "desc"): \Illuminate\Contracts\Pagination\LengthAwarePaginator|LengthAwarePaginator
    {
        if ($request->filled('query')) {
            $searchTerm = $request->input('query');
            $query->where(function ($q) use ($searchableFields, $searchTerm) {
                foreach ($searchableFields as $field) {
                    $q->orWhere($field['id'], 'like', '%' . $searchTerm . '%');
                }
            });
            if (!empty($relationSearchConfig)) {
                $parentQuery = $relationSearchConfig['parent_query'] ?? null;
                $relatedColumn = $relationSearchConfig['related_column'] ?? null;
                $columnValue = $relationSearchConfig['column_value'] ?? null;
                $returnField = $relationSearchConfig['return_field'] ?? 'id';

                if(isset($parentQuery) && $relatedColumn && $columnValue){
                    $data = $parentQuery->where($relatedColumn,$searchTerm)->get();
                    if ($data->isNotEmpty()) {
                        $ids = $data->pluck($returnField)->toArray(); // Get matching IDs from parent table
                        $query->orWhereIn($columnValue, $ids);
                    }
                }

            }
        }
        $sortBy = $request->input('sort_by', 'id');
        $sortOrder = in_array($request->input('sort_order'), ['asc', 'desc']) ? $request->input('sort_order') : $default;
        $query->orderBy($sortBy, $sortOrder);
        $perPage = $request->input('per_page', 10);
        if ($perPage === 'all') {
            $results = $query->get();
            return new LengthAwarePaginator($results,$results->count(),$results->count(),1,['path' => request()->url(), 'query' => request()->query()]
            );
        }
        return $query->paginate((int) $perPage)->appends($request->all());
    }

    protected function isAccessByRole($role, $id = null, $empId = null): ?string
    {
        $user = auth()->user();
        $userType = $user->user_type;
        if (str_starts_with($role,"seo")) {
            if (
                !RoleManager::onlySeoAccess($userType)
            ) {
                return 'You have no permission.';
            } else if ($id && $empId && $empId !== $user->id && !RoleManager::isAdmin($userType)) {

                return 'Access denied. You are not allowed to edit others\' data.';
            } else if(!$id){
                if(RoleManager::isSeoManager($userType)  && $role !== "seo_all"){
                    return 'Manager cannot add page';
                }
            }
        } else {
            if (!RoleManager::onlyDesignerAccess($userType)) {
                return 'You have no permission';
            } else if ($id && $empId && $empId !== $user->id && !RoleManager::isAdmin($userType)) {
                return 'Access denied. You are not allowed to edit others\' data.';
            }
        }
        return null;
    }



}