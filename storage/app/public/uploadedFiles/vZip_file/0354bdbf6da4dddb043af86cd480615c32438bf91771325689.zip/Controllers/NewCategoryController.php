<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Utils\ContentManager;
use App\Http\Controllers\Utils\RoleManager;
use App\Http\Controllers\Utils\StorageUtils;
use App\Models\AppCategory;
use App\Models\Design;
use App\Models\NewCategory;
use App\Models\Category;
use App\Models\SpecialKeyword;
use App\Models\SpecialPage;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Auth;
use Cache;

class NewCategoryController extends AppBaseController
{

    public function create()
    {
        $allCategories = NewCategory::getAllCategoriesWithSubcategories();
        $appArray = AppCategory::all();
        return view('main_new_cat/create_new_cat', compact('appArray', 'allCategories'));
    }

    public function store(Request $request)
    {

        // $data = NewCategory::where("category_name", $request->input('category_name'))->where('parent_category_id', $request->input('parent_category_id'))->first();
        // if ($data != null) {
        //     return response()->json([
        //         'error' => 'Category Already exist.'
        //     ]);
        // }

        // $data = NewCategory::where("id_name", $request->input('id_name'))->where('parent_category_id', $request->input('parent_category_id'))->first();
        // if ($data != null) {
        //     return response()->json([
        //         'error' => 'ID Name Already exist.'
        //     ]);
        // }

        $accessCheck = $this->isAccessByRole("seo");
        if ($accessCheck) {
            return response()->json([
                'error' => $accessCheck,
            ]);
        }

        if(HelperController::checkCategoryAvail(0,$request->input('category_name'),$request->input('id_name'), $request->input('parent_category_id'))){
            return response()->json([
                'error' => 'Category Name or Id Name Already exist.'
            ]);
        }

        $cat = NewCategory::find($request->input('parent_category_id'));
        if ($cat && $cat->parent_category_id != 0) {
            return response()->json([
                'error' => 'Use Parent Category.'
            ]);
        }

        $contentError = ContentManager::validateContent($request->contents,$request->long_desc,$request->h2_tag);
        if ($contentError){
            return response()->json([
                'error' => $contentError
            ]);
        }

        $base64Images =[ ...ContentManager::getBase64Contents($request->contents),['img'=> $request->category_thumb,'name' => "Category Thumb",'required'=>true],['img'=> $request->banner,'name' => "Banner",'required'=>false],['img'=>$request->mockup,'name' => "Mockup",'required'=>true]];
        $validationError = ContentManager::validateBase64Images($base64Images);
        if ($validationError) {
            return response()->json([
                'error' => $validationError
            ]);
        }

        if(isset($request->faqs) && str_replace(['[', ']'], '', $request->faqs) != '') {
            if(!isset($request->faqs_title)){
                return response()->json([
                    'error' => "Please Add Faq Title"
                ]);
            }
        }

        // $validationError = ContentManager::validateMultipleImageFiles(
        //     [
        //         ["file" => $request->file('category_thumb'), "name" => "Category Thumb", "required" => true],
        //         ["file" => $request->file('mockup'), "name" => "Mockup", "required" => true],
        //         ["file" => $request->file('banner'), "name" => "Banner", "required" => false],
        //     ]
        // );

        $keywordNames = $request->input('keyword_name');
        $keywordLinks = $request->input('keyword_link');
        $keywordTargets = $request->input('keyword_target');
        $keywordRels = $request->input('keyword_rel');

        $topKeywords = [];
        for ($i = 0; $i < count($keywordNames); $i++) {
            $keyword['value'] = $keywordNames[$i];
            $keyword['link'] = $keywordLinks[$i];
            $keyword['openinnewtab'] = $keywordTargets[$i];
            $keyword['nofollow'] = $keywordRels[$i];
            $topKeywords[] = $keyword;
        }

        $slug = '';
        if($request->input('parent_category_id') != null && $request->input('parent_category_id') != 0){
            $idName = NewCategory::where('id', $request->input('parent_category_id'))->value('id_name') ?? '';
            if(isset($idName)) $slug = $idName."/".$request->input('id_name');
        } else {
            $slug = $request->input('id_name');
        }

        $canonical_link = $request->input('canonical_link');
        $canonicalError = ContentManager::validateCanonicalLink($canonical_link, 1, $slug);
        if ($canonicalError) {
            return response()->json([
                'error' => $canonicalError
            ]);
        }

        $res = new NewCategory;
        $res->string_id = $this->generateId();
        $res->canonical_link = $canonical_link;
        $res->cat_link = $slug;
        $res->category_name = $request->input('category_name');
        $res->primary_keyword = $request->input('primary_keyword');
        $res->id_name = $request->input('id_name');
        $res->tag_line = $request->input('tag_line');
        $res->meta_title = $request->input('meta_title');
        $res->h1_tag = $request->input('h1_tag');
        $res->h2_tag = $request->input('h2_tag');
        $res->meta_desc = $request->input('meta_desc');
        $res->short_desc = $request->input('short_desc');
        $res->long_desc = $request->input('long_desc');

        $res->category_thumb = ContentManager::saveImageToPath($request->category_thumb,'uploadedFiles/thumb_file/' . bin2hex(random_bytes(20)) . Carbon::now()->timestamp);
        $res->banner = ContentManager::saveImageToPath($request->banner,'uploadedFiles/banner_file/' . bin2hex(random_bytes(20)) . Carbon::now()->timestamp);
        $res->mockup = ContentManager::saveImageToPath($request->mockup,'uploadedFiles/thumb_file/' . bin2hex(random_bytes(20)) . Carbon::now()->timestamp);

        // $banner = $request->file('banner');
        // if ($banner) {
        //     $bytes = random_bytes(20);
        //     $new_name = bin2hex($bytes) . Carbon::now()->timestamp . '.' . $banner->getClientOriginalExtension();
        //     StorageUtils::storeAs($banner, 'uploadedFiles/thumb_file', $new_name);
        //     $res->banner = 'uploadedFiles/thumb_file/' . $new_name;
        // }


        // $res->size = $request->input('size');
        // $image = $request->file('category_thumb');
        // $bytes = random_bytes(20);
        // $new_name = bin2hex($bytes) . Carbon::now()->timestamp . '.' . $image->getClientOriginalExtension();
        // StorageUtils::storeAs($image, 'uploadedFiles/thumb_file', $new_name);
        // $res->category_thumb = 'uploadedFiles/thumb_file/' . $new_name;

        // $mockup = $request->file('mockup');
        // $bytes = random_bytes(20);
        // $new_name = bin2hex($bytes) . Carbon::now()->timestamp . '.' . $mockup->getClientOriginalExtension();
        // StorageUtils::storeAs($mockup, 'uploadedFiles/thumb_file', $new_name);
        // $res->mockup = 'uploadedFiles/thumb_file/' . $new_name;

        $res->app_id = $request->input('app_id');
        $res->top_keywords = json_encode($topKeywords);
        $res->cta = json_encode(HelperController::processCTA($request));
        $res->sequence_number = $request->input('sequence_number');
        $res->status = !RoleManager::isSeoIntern(Auth::user()->user_type) ? $request->input('status') : 0;
        $res->parent_category_id = $request->input('parent_category_id');

        $res->emp_id = auth()->user()->id;

        $fldrStr = HelperController::generateFolderID('');
        while (NewCategory::where('fldr_str', $fldrStr)->exists()) {
            $fldrStr = HelperController::generateFolderID('');
        }

        $res->fldr_str = $fldrStr;

        if ($request->input('contents')) {
            $contents = ContentManager::getContents($request->input('contents'), $fldrStr);
            $contentPath = 'ct/' . $fldrStr . '/jn/' . StorageUtils::getNewName() . ".json";
            StorageUtils::put($contentPath, $contents);
            $res->contents = $contentPath; 
        }

//        if ($request->input('faqs')) {
//            $faqPath = 'ct/' . $fldrStr . '/fq/' . StorageUtils::getNewName() . ".json";
//            StorageUtils::put($faqPath, $request->input('faqs'));
//            $res->faqs = $faqPath;
//        }
        if (isset($request->faqs)) {
            $faqPath =  'ct/' . $fldrStr . '/fq/' . StorageUtils::getNewName() . ".json";
            $faqs = [];
            $faqs['title'] = $request->faqs_title;
            $faqs['faqs'] = json_decode($request->faqs);
            StorageUtils::put($faqPath, json_encode($faqs));
            $res->faqs = $faqPath;
        }

        $res->child_updated_at = HelperController::newCatChildUpdatedAt($res->parent_category_id);
        $res->save();

        self::updateParentChildRelation($res->id, $res->parent_category_id);

        // if ($image != null) {
        //     try {
        //         unlink(storage_path("app/public/" . $request->input('cat_thumb_path')));
        //     } catch (\Exception $e) {
        //     }
        // }

        Cache::tags(["category_$slug"])->flush();
        Cache::tags(["category_$res->id"])->flush();
        Cache::tags(["category_$res->id_name"])->flush();
        Cache::tags(['categories'])->flush();

        return response()->json([
            'success' => "done"
        ]);
    }

    public function show(Request $request)
    {
        $query = $request->input('query', '');
        $perPage = $request->input('per_page', 20);
        $sortBy = $request->input('sort_by', 'id');
        $sortOrder = $request->input('sort_order', 'asc');

        if (!in_array($sortOrder, ['asc', 'desc'])) {
            $sortOrder = 'asc';
        }

        // Filter and paginate results
        $query = $request->get('query', '');

        $catArray = NewCategory::with('parentCategory')
            ->where('category_name', 'like', '%' . $query . '%')
            ->orWhereHas('parentCategory', function ($subQuery) use ($query) {
                $subQuery->where('category_name', 'like', '%' . $query . '%');
            })
            ->orderBy($sortBy, $sortOrder)
            ->paginate($perPage);


        return view('main_new_cat/show_new_cat')->with('catArray', $catArray);
    }

    public function edit(NewCategory $mainCategory, $id)
    {
        $res = NewCategory::find($id);
        if (!$res) {
            abort(404);
        }

        if (isset($res->top_keywords)) {
            $res->top_keywords = json_decode($res->top_keywords);
        } else {
            $res->top_keywords = [];
        }

        $allCategories = NewCategory::getAllCategoriesWithSubcategories();
        $datas['app'] = AppCategory::all();
        $res->contents = isset($res->contents) ? StorageUtils::get($res->contents) : "";
        $res->faqs = isset($res->faqs) ? StorageUtils::get($res->faqs) : "";

        $datas['cat'] = $res;
        $datas['allCategories'] = $allCategories;
        $datas['parent_category'] = NewCategory::where('id', $datas['cat']->parent_category_id)->first();
        return view('main_new_cat/edit_new_cat')->with('datas', $datas);
    }

    public function update(Request $request, NewCategory $mainCategory)
    {

        $currentuserid = Auth::user()->id;
        $idAdmin = roleManager::isAdmin($currentuserid);
        // $data = NewCategory::where('id', "!=", $request->id)->where("category_name", $request->input('category_name'))->where('parent_category_id', $request->input('parent_category_id'))->first();
        // if ($data != null) {
        //     return response()->json([
        //         'error' => 'Category Already exist.'
        //     ]);
        // }

        // $data = NewCategory::where('id', "!=", $request->id)->where("id_name", $request->input('id_name'))->where('parent_category_id', $request->input('parent_category_id'))->first();
        // if ($data != null) {
        //     return response()->json([
        //         'error' => 'ID Name Already exist.'
        //     ]);
        // }

        $res = NewCategory::find($request->id);
        if (!$res) {
            return response()->json(['error' => 'Page not found']);
        }

        $slug = '';
        if($request->input('parent_category_id') != null && $request->input('parent_category_id') != 0){
            $idName = NewCategory::where('id', $request->input('parent_category_id'))->value('id_name') ?? '';
            if(isset($idName)) $slug = $idName."/".$request->input('id_name');
        } else {
            $slug = $request->input('id_name');
        }
        $canonical_link = $request->input('canonical_link');
        if (!roleManager::isAdmin(Auth::user()->user_type) && $currentuserid != $res->emp_id) {
            if (roleManager::isAdminOrSeoManager($currentuserid)) {
                $canonicalError = ContentManager::validateCanonicalLink($canonical_link, 1, $slug);
                if ($canonicalError) {
                    return response()->json([
                        'error' => $canonicalError
                    ]);
                } else {
                    $res->canonical_link = $request->canonical_link;
                    if ($request->has('status')) {
                        $res->status = $request->status;
                    }
                    $res->save();
                    return response()->json([
                        'success' => 'done',
                    ]);
                }

            }
            return response()->json([
                'error' => 'You don\'t have rights to change this page',
            ]);
        }

        $accessCheck = $this->isAccessByRole("seo", $request->id, $res->emp_id ?? $currentuserid);
        if ($accessCheck) {
            return response()->json([
                'error' => $accessCheck,
            ]);
        }

        if(HelperController::checkCategoryAvail($request->id,$request->input('category_name'),$request->input('id_name'), $request->input('parent_category_id'))){
            return response()->json([
                'error' => 'Category Name or Id Name Already exist.'
            ]);
        }

        $cat = NewCategory::find($request->input('parent_category_id'));
        if ($cat && $cat->parent_category_id != 0) {
            return response()->json([
                'error' => 'Use Parent Category.'
            ]);
        }

        $contentError = ContentManager::validateContent($request->contents,$request->long_desc,$request->h2_tag);
        if ($contentError){
            return response()->json([
                'error' => $contentError
            ]);
        }

        if(isset($request->faqs) && str_replace(['[', ']'], '', $request->faqs) != '') {
            if(!isset($request->faqs_title)){
                return response()->json([
                    'error' => "Please Add Faq Title"
                ]);
            }
        }

        $checkStatusError = HelperController::checkStatusCondition($request->id,$request->input('status'),1,$request->parent_category_id);
        if($checkStatusError){
            return response()->json([
                'error' => $checkStatusError
            ]);
        }

        $base64Images =[ ...ContentManager::getBase64Contents($request->contents),['img'=> $request->category_thumb,'name' => "Category Thumb",'required'=>true],['img'=> $request->banner,'name' => "Banner",'required'=>false],['img'=>$request->mockup,'name' => "Mockup",'required'=>true]];

        $validationError = ContentManager::validateBase64Images($base64Images);
        if ($validationError) {
            return response()->json([
                'error' => $validationError
            ]);
        }

        // $validationError = ContentManager::validateMultipleImageFiles(
        //     [
        //         ["file" => $request->file('category_thumb'), "name" => "Category Thumb", "required" => true],
        //         ["file" => $request->file('mockup'), "name" => "Mockup", "required" => true],
        //         ["file" => $request->file('banner'), "name" => "Banner", "required" => false],
        //     ]
        // );

        $keywordNames = $request->input('keyword_name');
        $keywordLinks = $request->input('keyword_link');
        $keywordTargets = $request->input('keyword_target');
        $keywordRels = $request->input('keyword_rel');

        $topKeywords = [];
        for ($i = 0; $i < count($keywordNames); $i++) {
            $keyword['value'] = $keywordNames[$i];
            $keyword['link'] = $keywordLinks[$i];
            $keyword['openinnewtab'] = $keywordTargets[$i];
            $keyword['nofollow'] = $keywordRels[$i];
            $topKeywords[] = $keyword;
        }


//        $canonicalError = ContentManager::validateCanonicalLink($canonical_link, 1, $slug);
//        if ($canonicalError) {
//            return response()->json([
//                'error' => $canonicalError
//            ]);
//        }



        Cache::tags(["category_$res->cat_link"])->flush();
        Cache::tags(["category_$res->id_name"])->flush();

        if ($idAdmin) {
            $res->id_name = $request->input('id_name');
        }

        if ($canonical_link && $idAdmin) {
            $res->canonical_link = $canonical_link;
        }

        $oldCategoryID = $res->parent_category_id;

        $res->cat_link = $slug;
        $res->tag_line = $request->input('tag_line');
        $res->category_name = $request->input('category_name');
        $res->meta_title = $request->input('meta_title');
        $res->primary_keyword = $request->input('primary_keyword');
        $res->h1_tag = $request->input('h1_tag');
        $res->h2_tag = $request->input('h2_tag');
        $res->meta_desc = $request->input('meta_desc');
        $res->short_desc = $request->input('short_desc');
        $res->long_desc = $request->input('long_desc');

        /* Set Restriction for Parent Category Its Do Not Swipe On Its Own Child Category */

        $parentCategoryId = NewCategory::select('parent_category_id as value')->where('id', $request->input('parent_category_id'))->first();
        $res->parent_category_id = (isset($parentCategoryId->value) && $parentCategoryId->value == $request->id) ? $res->parent_category_id : $request->input('parent_category_id');
        $res->size = $request->input('size');

        $res->category_thumb = ContentManager::saveImageToPath($request->category_thumb,'uploadedFiles/thumb_file/' . bin2hex(random_bytes(20)) . Carbon::now()->timestamp);
        $res->banner = ContentManager::saveImageToPath($request->banner,'uploadedFiles/banner_file/' . bin2hex(random_bytes(20)) . Carbon::now()->timestamp);
        $res->mockup = ContentManager::saveImageToPath($request->mockup,'uploadedFiles/thumb_file/' . bin2hex(random_bytes(20)) . Carbon::now()->timestamp);


        // $image = $request->file('category_thumb');
        // if ($image != null) {
        //     $this->validate($request, ['category_thumb' => 'required|mimes:jpg,png,gif,webp,svg|max:100']);
        //     $bytes = random_bytes(20);
        //     $new_name = bin2hex($bytes) . Carbon::now()->timestamp . '.' . $image->getClientOriginalExtension();
        //     StorageUtils::storeAs($image, 'uploadedFiles/thumb_file', $new_name);
        //     $res->category_thumb = 'uploadedFiles/thumb_file/' . $new_name;
        // }

        // $mockup = $request->file('mockup');
        // if ($mockup != null) {
        //     $this->validate($request, ['mockup' => 'required|mimes:jpg,png,gif,webp,svg|max:100']);
        //     $bytes = random_bytes(20);
        //     $new_name = bin2hex($bytes) . Carbon::now()->timestamp . '.' . $mockup->getClientOriginalExtension();
        //     StorageUtils::storeAs($mockup, 'uploadedFiles/thumb_file', $new_name);
        //     $res->mockup = 'uploadedFiles/thumb_file/' . $new_name;
        // }

        // $banner = $request->file('banner');
        // if ($banner != null) {
        //     $this->validate($request, ['banner' => 'required|mimes:jpg,png,gif,webp,svg|max:100']);
        //     $bytes = random_bytes(20);
        //     $new_name = bin2hex($bytes) . Carbon::now()->timestamp . '.' . $banner->getClientOriginalExtension();
        //     StorageUtils::storeAs($banner, 'uploadedFiles/thumb_file', $new_name);
        //     StorageUtils::delete($res->banner);
        //     $res->banner = 'uploadedFiles/thumb_file/' . $new_name;
        // }  

        $res->app_id = $request->input('app_id');
        $res->top_keywords = json_encode($topKeywords);
        $res->cta = json_encode(HelperController::processCTA($request));
        $res->sequence_number = $request->input('sequence_number');
        if(!RoleManager::isSeoIntern(Auth::user()->user_type)) {
            $res->status = $request->input('status');
        }
        $res->parent_category_id = $request->input('parent_category_id');

        $res->emp_id = auth()->user()->id;

        $fldrStr = HelperController::generateFolderID('');
        while (NewCategory::where('fldr_str', $fldrStr)->exists()) {
            $fldrStr = HelperController::generateFolderID('');
        }

        $res->fldr_str = $fldrStr;

        $oldContentPath = $res->contents;
        $oldFaqPath = $res->faqs;

        $contentPath = null;
        if ($request->input('contents')) {
            $contents = ContentManager::getContents($request->input('contents'), $fldrStr);
            $contentPath = 'ct/' . $fldrStr . '/jn/' . StorageUtils::getNewName() . ".json";
            StorageUtils::put($contentPath, $contents);
        }
        $res->contents = $contentPath; 

        $faqPath = null;
//        if ($request->input('faqs')) {
//            $faqPath = 'ct/' . $fldrStr . '/fq/' . StorageUtils::getNewName() . ".json";
//            StorageUtils::put($faqPath, $request->input('faqs'));
//        }
        if (isset($request->faqs)) {
            $faqPath =  'ct/' . $fldrStr . '/fq/' . StorageUtils::getNewName() . ".json";
            $faqs = [];
            $faqs['title'] = $request->faqs_title;
            $faqs['faqs'] = json_decode($request->faqs);
            StorageUtils::put($faqPath, json_encode($faqs));
        }
        $res->faqs = $faqPath;
        $res->child_updated_at = HelperController::newCatChildUpdatedAt($res->parent_category_id);
        $res->save();

        self::updateParentChildRelation($res->id, $res->parent_category_id, $oldCategoryID, true);
        self::updateDesignCount($res->parent_category_id, $oldCategoryID, $res->total_templates);

        StorageUtils::delete($oldContentPath);
        StorageUtils::delete($oldFaqPath);

        // if ($image != null) {
        //     try {
        //         unlink(storage_path("app/public/" . $request->input('cat_thumb_path')));
        //     } catch (\Exception $e) {
        //     }
        // }

        // if ($mockup != null) {
        //     try {
        //         unlink(storage_path("app/public/" . $request->input('mockup_path')));
        //     } catch (\Exception $e) {
        //     }
        // }

        Cache::tags(["category_$slug"])->flush();
        Cache::tags(["category_$res->id"])->flush();
        Cache::tags(["category_$res->id_name"])->flush();
        Cache::tags(['categories'])->flush();

        return response()->json([
            'success' => "done"
        ]);
    }

    public function imp_update(Request $request)
    {

        $currentuserid = Auth::user()->id;
        $idAdmin = roleManager::isAdminOrManager($currentuserid);

        if ($idAdmin) {

            if ($request->isNew == "1") {
                $res = NewCategory::find($request->id);
            } else {
                $res = Category::find($request->id);
            }

            if ($res->imp == 1) {
                $res->imp = 0;
            } else {
                $res->imp = 1;
            }

            $res->save();

            return response()->json([
                'success' => "done"
            ]);
        } else {
            return response()->json([
                'error' => "Ask admin or manager for changes"
            ]);
        }
    }

    public function destroy(NewCategory $mainCategory, $id)
    {
        // $res=NewCategory::find($id);
        // $category_thumb = $res->category_thumb;
        // $contains = Str::contains($category_thumb, 'no_image');

        // if(!$contains) {
        //     try {
        //         unlink(storage_path("app/public/".$category_thumb));
        //     } catch (\Exception $e) {}
        // }

        // NewCategory::destroy(array('id', $id));
        return redirect('show_new_cat');
    }

    public function generateId($length = 8)
    {
        $pool = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        do {
            $string_id = substr(str_shuffle(str_repeat($pool, $length)), 0, $length);
        } while (NewCategory::where('string_id', $string_id)->exists());
        return $string_id;
    }

    public static function updateParentChildRelation($childId, $newParentId, $oldParentId = null, $isUpdate = false): void
    {
        if ($isUpdate && $oldParentId !== null && $oldParentId != $newParentId) {
            $oldParent = NewCategory::where('id', $oldParentId)
                ->where('parent_category_id', 0)
                ->where('child_cat_ids', 'like', '%'.$childId.'%')
                ->first();

            if ($oldParent) {
                $childIds = json_decode($oldParent->child_cat_ids, true) ?? [];

                if (($key = array_search($childId, $childIds)) !== false) {
                    unset($childIds[$key]);
                    $oldParent->child_cat_ids = json_encode(array_values($childIds)); // Reindex
                    $oldParent->save();
                }
            }
        }

        if (!empty($newParentId) && $newParentId != 0) {
            $newParent = NewCategory::find($newParentId);
            if ($newParent) {
                $childIds = json_decode($newParent->child_cat_ids, true) ?? [];
                if (!in_array($childId, $childIds)) {
                    $childIds[] = $childId;
                    $newParent->child_cat_ids = json_encode($childIds);
                    $newParent->save();
                }
            }
        }
    }

    public static function updateDesignCount($newParentCatId,$oldParentCatID,$totalTemplates): void
    {
        if($newParentCatId !== $oldParentCatID) {
            if($oldParentCatID !== 0){
                $oldParent = NewCategory::where('id',$oldParentCatID)->first();
                if ($oldParent) {
                    $oldParent->total_templates = $oldParent->total_templates - $totalTemplates;
                    $oldParent->save();
                }
     
            }
            if($newParentCatId !== 0){
                $newParent = NewCategory::where('id',$newParentCatId)->first();
                if ($newParent) {
                    $newParent->total_templates = $newParent->total_templates + $totalTemplates;
                    $newParent->save();
                }
            }
        }
    }

}
