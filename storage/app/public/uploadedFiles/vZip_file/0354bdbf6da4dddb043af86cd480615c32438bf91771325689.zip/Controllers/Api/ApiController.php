<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\UserData;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ApiController extends Controller
{
    public array|null|string $authKey;
    public array|null|string $uid = "48vNvOa7qYPZwRTnS4sqkEdUTGv1";
    public string $testingUid = "YTC1UOvR05hSKSkJSXFnb6LUFAi1";
    public string $aesPassword = 'E@7r1K7!6v#KZx^m';
    public bool $isTester = false;


    public function isFakeRequest(Request $request): bool
    {
        return false;
    }

    public function isFakeRequestAndUser(Request $request): bool
    {
        return false;
    }

    public function isFakeRequestAndCreator(Request $request): bool
    {
        return false;
    }


}