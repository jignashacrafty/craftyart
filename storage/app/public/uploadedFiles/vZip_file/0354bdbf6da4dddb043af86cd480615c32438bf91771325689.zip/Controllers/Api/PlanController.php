<?php

namespace App\Http\Controllers\Api;

use Carbon\Carbon;
use App\Models\Plan;
use App\Models\Draft;
use App\Models\SubPlan;
use App\Models\UserData;
use App\Models\PlanFeature;
use App\Models\PlanDuration;
use Illuminate\Http\Request;
use App\Models\TransactionLog;
use App\Http\Controllers\Utils\ContentManager;

class PlanController extends ApiController
{

    public function getPlanData(Request $request): array|string
    {
        $PlanDuration = PlanDuration::select('id', 'name','duration_type')->get();

        $plans = Plan::where('status', 1)->get();

        $plansData = $plans->map(function ($plan) {
            // Decode appearance JSON
            $appearanceData = json_decode($plan->appearance, true);
            $appearance = [];
            if (is_array($appearanceData)) {
                foreach ($appearanceData as $item) {
                    $featureName = null;
                    if (isset($item['features_id'])) {
                        $feature = PlanFeature::find($item['features_id']);
                        $featureName = $feature?->name;
                    }

                    $appearance[] = [
                        'meta_appearance' => $item['meta_appearance'] ? $item['meta_appearance'] : $featureName,
                        'meta_value' => $item['meta_value'] ?? null,
                    ];
                }
            }

            // Load subplans
            $subPlans = SubPlan::where('plan_id', $plan->string_id)->where('status', 1)->get();
            $subPlanData = $subPlans->map(function ($subPlan) {
                $planDetails = json_decode($subPlan->plan_details, true);
                $duration = PlanDuration::find($subPlan->duration_id);
                $durationValue = $duration?->duration;
                $planDetails['duration'] = $durationValue;
                return [
                    'id' => $subPlan->id,
                    'string_id' => $subPlan->string_id,
                    'plan_id' => $subPlan->plan_id,
                    'duration_id' => (int) $subPlan->duration_id,
                    'details' => $planDetails,
                ];
            });

            return [
                'id' => $plan->id,
                'name' => $plan->name,
                'string_id' => $plan->string_id,
                'icon' => ContentManager::getStorageLink($plan->icon),
                'description' => $plan->description,
                'appearance' => $appearance,
                'sub_plan' => $subPlanData,
            ];
        });

        $response = [
            'duration' => $PlanDuration,
            'plans' => $plansData,
        ];

        return ResponseHandler::sendResponse(
            $request,
            new ResponseInterface(200, true, 'Plan data loaded successfully.', $response)
        );
    }


    // is_template 
    public function plan(Request $request): array|string
    {
        $user = UserData::where('uid', $request->uid)->first();
        if (!$user) {
            return $this->finalResponse($request, 404, 'User not found');
        }

        $log = TransactionLog::where('user_id', $user->uid)->latest()->first();
        if (!$log) {
            return $this->finalResponse($request, 404, 'No transaction found');
        }

        $subPlan = SubPlan::where('string_id', $log->plan_id)->first();
        if (!$subPlan) {
            return $this->finalResponse($request, 404, 'Subplan not found');
        }

        $plan = Plan::where('string_id', $subPlan->plan_id)->first();
        if (!$plan) {
            return $this->finalResponse($request, 404, 'Plan not found');
        }

        if ($log->expired_at && now()->gt($log->expired_at)) {
            return $this->finalResponse($request, 200, 'Plan is expired', false);
        }

        $appearance = json_decode($plan->appearance, true);
        $templateConfig = collect($appearance)->firstWhere('slug', 'is_template');
        if (!$templateConfig) {
            return $this->finalResponse($request, 200, 'Template config not found', true);
        }

        $values = $templateConfig['meta_feature_value'] ?? [];
        $limit = (int) ($values[0] ?? 0);
        $type = strtolower($values[1] ?? '');

        if ($limit === -1) {
            return $this->finalResponse($request, 200, 'Unlimited access', true);
        }

        if ($type === 'daily') {
            $used = Draft::where('user_id', $user->uid)
                ->whereBetween('created_at', [now()->startOfDay(), now()->endOfDay()])
                ->count();

            return $this->limitResponse($request, $limit, $type, $used);
        }

        // monthly or other time-bound
        $start = Carbon::parse($log->created_at);
        $end = Carbon::parse($log->expired_at ?? now());

        while ($start < $end) {
            $next = match ($type) {
                'monthly' => $start->copy()->addMonth(),
                default => null,
            };

            if (!$next || $next > $end)
                $next = $end;

            if (now()->between($start, $next)) {
                $used = Draft::where('user_id', $user->uid)
                    ->whereBetween('created_at', [$start, $next])
                    ->count();

                return $this->limitResponse($request, $limit, $type, $used, $start, $next);
            }

            $start = $next->copy();
        }

        return $this->finalResponse($request, 200, 'Access allowed', true, $limit, $type);
    }

    private function finalResponse($req, $code, $msg, $access = false, $limit = null, $type = null, $extra = []): array|string
    {
        return ResponseHandler::sendResponse($req, new ResponseInterface($code, $code === 200, $msg, array_merge([
            'isAccessTemplate' => $access,
            'limit' => $limit,
            'type' => $type
        ], $extra)));
    }

    private function limitResponse($req, $limit, $type, $used, $current = null, $next = null): array|string
    {
        $canAccess = $used < $limit;
        $msg = $canAccess ? 'Access allowed' : "Your $type limit is expired";
        return $this->finalResponse($req, 200, $msg, $canAccess, $limit, $type, [
            'used' => $used,
            'current' => $current,
            'next' => $next
        ]);
    }
}
