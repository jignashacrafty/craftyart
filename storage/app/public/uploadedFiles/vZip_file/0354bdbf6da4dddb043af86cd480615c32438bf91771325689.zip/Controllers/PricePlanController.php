<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Validator;
use App\Models\CategoryFeature;
use Illuminate\Http\Request;
use App\Models\Plan;
use Exception;

class PricePlanController extends AppBaseController
{
    /**  Display a listing of the resource.*/
    public function index(Request $request)
    {
        $filters = ["name","inr_actual_price_monthly","inr_price_monthly","inr_actual_price_yearly","inr_price_yearly","usd_actual_price_monthly","usd_price_monthly","usd_actual_price_yearly","usd_price_yearly"];
        $query = Plan::query();
        if( isset($request->query) && $request->input('query') != '' ){
            $query = $this->applyFilters($query, $filters,$request->input('query'));
        }
        $plans = $query->paginate(10);
        return view("price_plans.index",compact('plans'));
    }

    /*** Show the form for creating a new resource.*/
    public function create()
    {
        $categoryFeatures = CategoryFeature::with('features')->get();
        return view("price_plans.create",compact('categoryFeatures'));
    }

    /** Store a newly created resource in storage.*/
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string',
            'plan_id' => 'required|string',
            'inr_actual_price_monthly' => 'required',
            'inr_price_monthly' => 'required',
            'inr_actual_price_yearly' => 'required',
            'inr_price_yearly' => 'required',
            'usd_actual_price_monthly' => 'required',
            'usd_price_monthly' => 'required',
            'usd_actual_price_yearly' => 'required',
            'usd_price_yearly' => 'required',
            'features' => 'required',
        ]);

        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator)->withInput();
        }

        $featuresArray = json_decode($request['features'], true);
        $filteredFeatures = array_filter($featuresArray, function($value) {
            return $value !== "on";
        });
        $appearance = [];
        foreach ($request->meta_data as $key => $value) {
            if (in_array($key, $filteredFeatures)) {
                if (array_key_exists($key, $request->meta_appearance_type )) {
                    $appearance[$key] = [
                        "meta_type" => $request->meta_appearance_type[$key][0],
                        "meta_value" => is_array($value) ? $value[0] : $value,
                        "meta_feature_value" => isset( $request->feature_meta_value[$key][0] ) ? $request->feature_meta_value[$key][0] : ""
                    ];
                }
            }
        }

        try {
            $inputs = [
                "name" => $request->name,
                "plan_id" => $request->plan_id,
                "inr_price_monthly" => $request->inr_price_monthly,
                "inr_price_yearly" => $request->inr_price_yearly,
                "inr_actual_price_monthly" => $request->inr_actual_price_monthly,
                "inr_actual_price_yearly" => $request->inr_actual_price_yearly,
                "usd_actual_price_monthly" => $request->usd_actual_price_monthly,
                "usd_price_monthly" => $request->usd_price_monthly,
                "usd_actual_price_yearly" => $request->usd_actual_price_yearly,
                "usd_price_yearly" => $request->usd_price_yearly,
                "description" => $request->description,
                "appearance" => json_encode($appearance),
                "status" => 1,
            ];

            $plan = Plan::create($inputs);
            $inputFeatures = array_values($filteredFeatures);
            $plan->features()->sync($inputFeatures);

            return response()->json([
                'status' => true,
                'success' => "Plan has been added successfully.",
            ]);
        } catch (Exception $e) {
            return response()->json([
                'status' => false,
                'error' => $e->getMessage(),
            ]);
        }
    }

    /** Show the form for editing the specified resource.*/
    public function edit(Plan $plan)
    {
        $plan = $plan->load('features');
        $categoryFeatures = CategoryFeature::with('features')->get();
        return view("price_plans.edit",compact('plan','categoryFeatures'));
    }

    /*** Update the specified resource in storage.*/
    public function update(Request $request, Plan $plan)
    {
        $inputs = $request->except(['features', 'meta_data', 'meta_appearance_type']);
        $featuresArray = json_decode($request['features'], true);
        $metaData = array_filter($request["meta_data"]);
        $metaAppearanceType = array_filter($request["meta_appearance_type"]);
        $appearance = [];
        foreach ($metaData as $key => $value) {
            if (array_key_exists($key, $metaAppearanceType )) {
                $appearance[$key] = [
                    "meta_type" => $metaAppearanceType[$key][0],
                    "meta_value" => is_array($value) ? $value[0] : $value,
                    "meta_feature_value" => isset( $request->feature_meta_value[$key][0] ) ? $request->feature_meta_value[$key][0] : ""
                ];
            }
        }

        $inputs["appearance"] = json_encode($appearance);
        try {

            $inputs["status"] = (int)$inputs["status"];
            $plan->update($inputs);
            $filteredFeatures = array_filter($featuresArray, function($value) {
                return $value !== "on";
            });
            $inputFeatures = array_values($filteredFeatures);
            $plan->features()->sync($inputFeatures);
            return response()->json([
                'status' => true,
                'success' => "Plan has been updated successfully.",
            ]);
        } catch (Exception $e) {
            return response()->json([
                'status' => false,
                'error' => $e->getMessage(),
            ]);
        }
    }

    /*** Remove the specified resource from storage. */
    public function destroy(Plan $plan)
    {
        try {
            $plan->delete();
            return response()->json([
                'status' => true,
                'success' => "Plan has been deleted successfully.",
            ]);
        } catch (Exception $e) {
            return response()->json([
                'status' => false,
                'error' => $e->getMessage(),
            ]);
        }
    }
}
