<?php

namespace App\Http\Controllers;

use App\Models\CategoryFeature;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class CategoryFeatureController extends AppBaseController
{
    /** Display a listing of the resource.*/
    public function index(Request $request)
    {
        $filters = ["name"];
        $query = CategoryFeature::query();
        if( isset($request->query) && $request->input('query') != '' ){
            $query = $this->applyFilters($query, $filters,$request->input('query'));
        }
        $categoryFeatues = $query->paginate(10);
        return view("category_feature.index")->with('categoryFeatues',$categoryFeatues);
    }

    /*** Show the form for creating a new resource.*/
    public function create()
    {
    }

    /*** Store a newly created resource in storage.  */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string',
        ]);
        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator)->withInput();
        }
        try {
            CategoryFeature::create($request->only('name'));
            return $this->sendSuccessResponse("Category Feature has been added successfully.");
        } catch (Exception $e) {
            return $this->sendErrorResponse($e->getMessage());
        }
    }

    /*** Display the specified resource.*/
    public function show($id)
    {
        //
    }

    /*** Show the form for editing the specified resource. */
    public function edit($id)
    {
        //
    }

    /** * Update the specified resource in storage.*/
    public function update(Request $request, CategoryFeature $categoryFeature)
    {
        try {
            $categoryFeature->update(['name' => $request->category_feature_name]);
            return $this->sendSuccessResponse("Category Feature has been updated successfully.");
       } catch (Exception $e) {
            return $this->sendErrorResponse($e->getMessage());
        }
    }

    /*** Remove the specified resource from storage.  */
    public function destroy($id)
    {
        //
    }
}
