<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Utils\ContentManager;
use App\Http\Controllers\Utils\StorageUtils;
use App\Models\AppCategory;
use App\Models\NewCategory;
use App\Models\Category;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;

class NewCategoryControllerBackup extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }


    public function create()
    {
        $allCategories = NewCategory::getAllCategoriesWithSubcategories();
        $appArray = AppCategory::all();
        return view('main_new_cat/create_new_cat', compact('appArray', 'allCategories'));
    }

    public function store(Request $request)
    {

//        $data = NewCategory::where("category_name", $request->input('category_name'))->where('parent_category_id', $request->input('parent_category_id'))->first();
//        if ($data != null) {
//            return response()->json([
//                'error' => 'Category Already exist.'
//            ]);
//        }
//
//        $data = NewCategory::where("id_name", $request->input('id_name'))->where('parent_category_id', $request->input('parent_category_id'))->first();
//        if ($data != null) {
//            return response()->json([
//                'error' => 'ID Name Already exist.'
//            ]);
//        }

        if(HelperController::checkCategoryAvail(0,$request->input('category_name'),$request->input('id_name'),$request->input('parent_category_id') ?? 0)){
            return response()->json([
                'error' => 'Category Name or Id Name Already exist.'
            ]);
        }

        $contentError = ContentManager::validateContent($request->contents,$request->long_desc,$request->h2_tag);
        if ($contentError){
            return response()->json([
                'error' => $contentError
            ]);
        }

        $base64Images =[ ...ContentManager::getBase64Contents($request->contents),['img'=> $request->category_thumb,'name' => "Category Thumb",'required'=>true],['img'=> $request->banner,'name' => "Banner",'required'=>false],['img'=>$request->mockup,'name' => "Mockup",'required'=>true]];
        $validationError = ContentManager::validateBase64Images($base64Images);
        if ($validationError) {
            return response()->json([
                'error' => $validationError
            ]);
        }

        $slug = '';
        if($request->input('parent_category_id') != null && $request->input('parent_category_id') != 0){
            $idName = NewCategory::where('id', $request->input('parent_category_id'))->value('id_name') ?? '';
            if(isset($idName)) $slug = $idName."/".$request->input('id_name');
        } else {
            $slug = $request->input('id_name');
        }

        $validationError = ContentManager::validateCanonicalLink($request->canonical_link,1,$slug);
        if ($validationError) {
            return response()->json([
                'error' => $validationError
            ]);
        }

//        $validationError = ContentManager::validateCanonicalLink($request->canonical_link,1,$request->page_slug);
//        if ($validationError) {
//            return response()->json([
//                'error' => $validationError
//            ]);
//        }

        // $validationError = ContentManager::validateMultipleImageFiles([$request->file('category_thumb'), $request->file('mockup'), $request->file('banner')]);
        // if ($validationError) {
        //     return response()->json([
        //         'error' => $validationError
        //     ]);
        // }




        $keywordNames = $request->input('keyword_name');
        $keywordLinks = $request->input('keyword_link');
        $keywordTargets = $request->input('keyword_target');
        $keywordRels = $request->input('keyword_rel');

        $topKeywords = [];
        for ($i = 0; $i < count($keywordNames); $i++) {
            $keyword['value'] = $keywordNames[$i];
            $keyword['link'] = $keywordLinks[$i];
            $keyword['openinnewtab'] = $keywordTargets[$i];
            $keyword['nofollow'] = $keywordRels[$i];
            $topKeywords[] = $keyword;
        }

        $res = new NewCategory;
        $fldrStr = HelperController::generateFolderID('', 10);
        $res->fldr_str = $fldrStr;
        $contentPath = null;
        if(!empty($request->input('contents'))){
            $contents = ContentManager::getContents($request->input('contents'), $fldrStr, [], []);
            $contentPath = 'ct/' . uniqid() . ".json";
            StorageUtils::put($contentPath, $contents);
        }
        $res->contents = $contentPath;
        $faqsPath = null;
        if (!empty($request->input('faqs'))) {
            $faqsPath = 'faqs/' . uniqid() . ".json";
            StorageUtils::put($faqsPath, $request->input('faqs'));
        }
        $res->faqs = $faqsPath;
        $res->string_id = $this->generateId();
        $res->category_name = $request->input('category_name');
        $res->id_name = $request->input('id_name');

        $res->meta_title = $request->input('meta_title');
        $res->tag_line = $request->input('tag_line');
        $res->h1_tag = $request->input('h1_tag');
        $res->h2_tag = $request->input('h2_tag');
        $res->primary_keyword = $request->input('primary_keyword');
        $res->canonical_link = $request->input('canonical_link');
        $res->meta_desc = $request->input('meta_desc');
        $res->short_desc = $request->input('short_desc');
        $res->long_desc = $request->input('long_desc');

        $res->size = $request->input('size');
        $res->category_thumb = ContentManager::saveImageToPath($request->category_thumb,'uploadedFiles/thumb_file/' . bin2hex(random_bytes(20)) . Carbon::now()->timestamp);
        $res->banner = ContentManager::saveImageToPath($request->banner,'uploadedFiles/banner_file/' . bin2hex(random_bytes(20)) . Carbon::now()->timestamp);
        $res->mockup = ContentManager::saveImageToPath($request->mockup,'uploadedFiles/thumb_file/' . bin2hex(random_bytes(20)) . Carbon::now()->timestamp);
        // $image = $request->file('category_thumb');
        // if ($image != null) {
        //     $bytes = random_bytes(20);
        //     $new_name = bin2hex($bytes) . Carbon::now()->timestamp . '.' . $image->getClientOriginalExtension();
        //     StorageUtils::storeAs($image, 'uploadedFiles/thumb_file', $new_name);
        //     $res->category_thumb = 'uploadedFiles/thumb_file/' . $new_name;
        // } else {
        //     $res->category_thumb = 'uploadedFiles/thumb_file/no_image.png';
        // }

        // $mockup = $request->file('mockup');
        // if ($mockup != null) {
        //     $bytes = random_bytes(20);
        //     $new_name = bin2hex($bytes) . Carbon::now()->timestamp . '.' . $mockup->getClientOriginalExtension();
        //     StorageUtils::storeAs($mockup, 'uploadedFiles/thumb_file', $new_name);
        //     $res->mockup = 'uploadedFiles/thumb_file/' . $new_name;
        // } else {
        //     $res->mockup = 'uploadedFiles/thumb_file/no_image.png';
        // }
        // $banner = $request->file('banner');
        // if ($banner != null) {
        //     $bytes = random_bytes(20);
        //     $new_name = bin2hex($bytes) . Carbon::now()->timestamp . '.' . $banner->getClientOriginalExtension();
        //     StorageUtils::storeAs($banner, 'uploadedFiles/banner_file', $new_name);
        //     $res->banner = 'uploadedFiles/banner_file/' . $new_name;
        // }

        $res->app_id = $request->input('app_id');
        $res->top_keywords = json_encode($topKeywords);
        $res->sequence_number = $request->input('sequence_number');
        $res->status = $request->input('status');
        $res->parent_category_id = $request->input('parent_category_id');
        $res->save();

        // if ($image != null) {
        //     try {
        //         StorageUtils::delete($request->input('cat_thumb_path'));
        //     } catch (\Exception $e) {
        //     }
        // }

        return response()->json([
            'success' => "done"
        ]);
    }

    public function show(Request $request)
    {

        $query = $request->input('query', '');
        $perPage = $request->input('per_page', 20);
        $sortBy = $request->input('sort_by', 'id');
        $sortOrder = $request->input('sort_order', 'asc');

        if (!in_array($sortOrder, ['asc', 'desc'])) {
            $sortOrder = 'asc';
        }
        $query = $request->get('query', '');

        $catArray = NewCategory::with('parentCategory')
            ->where('category_name', 'like', '%' . $query . '%')
            ->orWhereHas('parentCategory', function ($subQuery) use ($query) {
                $subQuery->where('category_name', 'like', '%' . $query . '%');
            })
            ->orderBy($sortBy, $sortOrder)
            ->paginate($perPage);


        return view('main_new_cat/show_new_cat')->with('catArray', $catArray);
    }

    public function edit(NewCategory $mainCategory, $id)
    {
        $res = NewCategory::find($id);
        if (!$res) {
            abort(404);
        }

        if (isset($res->top_keywords)) {
            $res->top_keywords = json_decode($res->top_keywords);
        } else {
            $res->top_keywords = [];
        }

        $allCategories = NewCategory::getAllCategoriesWithSubcategories();
        $datas['app'] = AppCategory::all();
        // $res->contents = isset($res->contents) ? json_encode(json_decode(file_get_contents(StorageUtils::get($res->contents)), false)) : "";
        $res->contents = StorageUtils::exists($res->contents) ? file_get_contents(StorageUtils::get($res->contents)) : "";
        $res->faqs = StorageUtils::exists($res->faqs) ? file_get_contents(StorageUtils::get($res->faqs)) : "";
        $datas['cat'] = $res;
        $datas['allCategories'] = $allCategories;
        $datas['parent_category'] = NewCategory::where('id', $datas['cat']->parent_category_id)->first();
        return view('main_new_cat/edit_new_cat')->with('datas', $datas);
    }

    public function update(Request $request, NewCategory $mainCategory)
    {

        $currentuserid = Auth::user()->id;
        $idAdmin = HelperController::isAdmin($currentuserid);

//        $data = NewCategory::where('id', "!=", $request->id)->where("category_name", $request->input('category_name'))->where('parent_category_id', $request->input('parent_category_id'))->first();
//        if ($data != null) {
//            return response()->json([
//                'error' => 'Category Already exist.'
//            ]);
//        }
//
//        $data = NewCategory::where('id', "!=", $request->id)->where("id_name", $request->input('id_name'))->where('parent_category_id', $request->input('parent_category_id'))->first();
//        if ($data != null) {
//            return response()->json([
//                'error' => 'ID Name Already exist.'
//            ]);
//        }

        if(HelperController::checkCategoryAvail($request->id,$request->input('category_name'),$request->input('id_name'),$request->input('parent_category_id') ?? 0)){
            return response()->json([
                'error' => 'Category Name or Id Name Already exist.'
            ]);
        }

        $contentError = ContentManager::validateContent($request->contents,$request->long_desc,$request->h2_tag);
        if ($contentError){
            return response()->json([
                'error' => $contentError
            ]);
        }



        $base64Images =[ ...ContentManager::getBase64Contents($request->contents),['img'=> $request->category_thumb,'name' => "Category Thumb",'required'=>true],['img'=> $request->banner,'name' => "Banner",'required'=>false],['img'=>$request->mockup,'name' => "Mockup",'required'=>true]];
        // $base64Images = [...ContentManager::getBase64Contents($request->contents),$request->category_thumb,$request->banner, $request->mockup];
        $validationError = ContentManager::validateBase64Images($base64Images);
        if ($validationError) {
            return response()->json([
                'error' => $validationError
            ]);
        }

        $slug = '';
        if($request->input('parent_category_id') != null && $request->input('parent_category_id') != 0){
            $idName = NewCategory::where('id', $request->input('parent_category_id'))->value('id_name') ?? '';
            if(isset($idName)) $slug = $idName."/".$request->input('id_name');
        } else {
            $slug = $request->input('id_name');
        }

        $validationError = ContentManager::validateCanonicalLink($request->canonical_link,1,$slug);
        if ($validationError) {
            return response()->json([
                'error' => $validationError
            ]);
        }

        // $validationError = ContentManager::validateMultipleImageFiles([$request->file('category_thumb'), $request->file('mockup'), $request->file('banner')]);
        // if ($validationError) {
        //     return response()->json([
        //         'error' => $validationError
        //     ]);
        // }

        $keywordNames = $request->input('keyword_name');
        $keywordLinks = $request->input('keyword_link');
        $keywordTargets = $request->input('keyword_target');
        $keywordRels = $request->input('keyword_rel');

        $topKeywords = [];
        for ($i = 0; $i < count($keywordNames); $i++) {
            $keyword['value'] = $keywordNames[$i];
            $keyword['link'] = $keywordLinks[$i];
            $keyword['openinnewtab'] = $keywordTargets[$i];
            $keyword['nofollow'] = $keywordRels[$i];
            $topKeywords[] = $keyword;
        }

        $res = NewCategory::find($request->id);

        if ($idAdmin) {
            $res->id_name = $request->input('id_name');
        }

        $res->category_name = $request->input('category_name');
        $res->meta_title = $request->input('meta_title');
        $res->tag_line = $request->input('tag_line');
        $res->primary_keyword = $request->input('primary_keyword');
        $res->h1_tag = $request->input('h1_tag');
        $res->h2_tag = $request->input('h2_tag');
        $res->canonical_link = $request->input('canonical_link');
        $res->meta_desc = $request->input('meta_desc');
        $res->short_desc = $request->input('short_desc');
        $res->long_desc = $request->input('long_desc');

        $availableImage = [];
        $availableVideo = [];
        $availableContent = NewCategory::where('id', $request->id)->value('contents');
        $contentsArray = json_decode($availableContent, true);

        if (!empty($contentsArray)) {
            foreach ($contentsArray as $content) {
                if ($content['type'] == 'content') {
                    foreach ($content['value'] as $key => $item) {
                        if (isset($key) && $key == 'video') {
                            $availableVideo[] = $item['link'];
                        }
                        if (isset($key) && $key == 'images') {
                            $availableImage[] = $item['link'];
                        }
                    }
                } else if ($content['type'] == 'ads') {
                    if (isset($content['value']['image'])) {
                        $availableImage[] = $content['value']['image'];
                    }
                }
            }
        }
        $fldrStr = NewCategory::where('id', $request->id)->value('fldr_str');
        if ($fldrStr == null || $fldrStr == "") {
            $fldrStr = HelperController::generateFolderID('', 10);
        }
        $contentPath = $res->contents;
        if (isset($request->contents)) {
            $contents = ContentManager::getContents($request->contents, $fldrStr, $availableImage, $availableVideo);

            if (!isset($contentPath)) {
                $contentPath = 'ct/' . uniqid() . ".json";
            }
            StorageUtils::put($contentPath, $contents);
            $res->contents = $contentPath;
        }
        $faqsPath = $res->faqs;
        if (isset($request->faqs)) {
            if (!isset($faqsPath)) {
                $faqsPath = 'faqs/' . uniqid() . ".json";
            }
            StorageUtils::put($faqsPath, $request->input('faqs'));
            $res->faqs = $faqsPath;
        }
        if ($fldrStr != "") {
            $res->fldr_str = $fldrStr;
        }
        // $res->faqs = $request->input('faqs');
        $parentCategoryId = NewCategory::select('parent_category_id as value')->where('id', $request->input('parent_category_id'))->first();
        $res->parent_category_id = (isset($parentCategoryId->value) && $parentCategoryId->value == $request->id) ? $res->parent_category_id : $request->input('parent_category_id');
        $res->size = $request->input('size');

        // $image = $request->file('category_thumb');
        // if ($image != null) {
        //     $bytes = random_bytes(20);
        //     $new_name = bin2hex($bytes) . Carbon::now()->timestamp . '.' . $image->getClientOriginalExtension();
        //     StorageUtils::storeAs($image, 'uploadedFiles/thumb_file', $new_name);
        //     $res->category_thumb = 'uploadedFiles/thumb_file/' . $new_name;
        // }

        // $mockup = $request->file('mockup');
        // if ($mockup != null) {
        //     $bytes = random_bytes(20);
        //     $new_name = bin2hex($bytes) . Carbon::now()->timestamp . '.' . $mockup->getClientOriginalExtension();
        //     StorageUtils::storeAs($mockup, 'uploadedFiles/thumb_file', $new_name);
        //     $res->mockup = 'uploadedFiles/thumb_file/' . $new_name;
        // }

        // $banner = $request->file('banner');
        // if ($banner != null) {
        //     $bytes = random_bytes(20);
        //     $new_name = bin2hex($bytes) . Carbon::now()->timestamp . '.' . $banner->getClientOriginalExtension();
        //     StorageUtils::storeAs($banner, 'uploadedFiles/banner_file', $new_name);
        //     $res->banner = 'uploadedFiles/banner_file/' . $new_name;
        // }
        $res->category_thumb = ContentManager::saveImageToPath($request->category_thumb,'uploadedFiles/thumb_file/' . bin2hex(random_bytes(20)) . Carbon::now()->timestamp);
        $res->banner = ContentManager::saveImageToPath($request->banner,'uploadedFiles/banner_file/' . bin2hex(random_bytes(20)) . Carbon::now()->timestamp);
        $res->mockup = ContentManager::saveImageToPath($request->mockup,'uploadedFiles/thumb_file/' . bin2hex(random_bytes(20)) . Carbon::now()->timestamp);

        $res->app_id = $request->input('app_id');
        $res->top_keywords = json_encode($topKeywords);
        $res->sequence_number = $request->input('sequence_number');
        $res->status = $request->input('status');
        $res->parent_category_id = $request->input('parent_category_id');

        $res->emp_id = auth()->user()->id;
        $res->save();

        // if ($image != null) {
        //     try {
        //         StorageUtils::delete($request->input('cat_thumb_path'));
        //     } catch (\Exception $e) {
        //     }
        // }

        // if ($mockup != null) {
        //     try {
        //         StorageUtils::delete($request->input('mockup_path'));
        //     } catch (\Exception $e) {
        //     }
        // }

        // if ($banner != null) {
        //     try {
        //         StorageUtils::delete($request->input('banner_path'));
        //     } catch (\Exception $e) {
        //     }
        // }

        return response()->json([
            'success' => "done"
        ]);
    }

    public function imp_update(Request $request)
    {

        $currentuserid = Auth::user()->id;
        $idAdmin = HelperController::isAdminOrManger($currentuserid);

        if ($idAdmin) {

            if ($request->isNew == "1") {
                $res = NewCategory::find($request->id);
            } else {
                $res = Category::find($request->id);
            }

            if ($res->imp == 1) {
                $res->imp = 0;
            } else {
                $res->imp = 1;
            }

            $res->save();

            return response()->json([
                'success' => "done"
            ]);
        } else {
            return response()->json([
                'error' => "Ask admin or manager for changes"
            ]);
        }
    }

    public function destroy(NewCategory $mainCategory, $id)
    {
        // $res=NewCategory::find($id);
        // $category_thumb = $res->category_thumb;
        // $contains = Str::contains($category_thumb, 'no_image');

        // if(!$contains) {
        //     try {
        //         unlink(storage_path("app/public/".$category_thumb));
        //     } catch (\Exception $e) {}
        // }

        // NewCategory::destroy(array('id', $id));
        return redirect('show_new_cat');
    }

    public function generateId($length = 8)
    {
        $pool = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        do {
            $string_id = substr(str_shuffle(str_repeat($pool, $length)), 0, $length);
        } while (NewCategory::where('string_id', $string_id)->exists());
        return $string_id;
    }
}