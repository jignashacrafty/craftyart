<?php

namespace App\Http\Controllers;

use App\Models\PlanCategory;
use App\Models\PlanDuration;
use App\Models\SpecialKeyword;
use Illuminate\Contracts\Foundation\Application;
use Illuminate\Contracts\View\Factory;
use Illuminate\Contracts\View\View;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class PlanDurationController extends AppBaseController
{

    public function index(Request $request): Factory|View|Application
    {
        $query = PlanDuration::query();

        if ($request->has('query')) {
            $search = $request->input('query');
            $query->where('name', 'LIKE', "%{$search}%")
                ->orWhere('duration_type', 'LIKE', "%{$search}%");
        }

        $getPlanCategorys = $query->paginate(10);

        return view("plan_duration.index", compact('getPlanCategorys'));
    }

    public function store(Request $request): JsonResponse
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'duration_type' => 'required|numeric',
        ]);
        PlanDuration::create([
            'name' => $request->name,
            'string_id' => $this->generateId(),
            'duration_type' => $request->duration_type,
        ]);

        return response()->json(['success' => 'Plan Category added successfully!']);
    }

    public function edit($id): JsonResponse
    {
        $planCategory = PlanDuration::findOrFail($id);

        return response()->json([
            'view' => view('plan_duration.edit', compact('planCategory'))->render()
        ]);
    }

    public function update(Request $request, $id): JsonResponse
    {
        $request->validate([
            'feature_name' => 'required|string|max:255',
            'duration_type' => 'required|numeric',
        ]);

        try {
            $planCategory = PlanDuration::findOrFail($id);

            $planCategory->update([
                'name' => $request->input('feature_name'),
                'duration_type' => $request->input('duration_type'),
            ]);

            return response()->json(['success' => 'Plan Category updated successfully!']);

        } catch (\Exception $e) {
            return response()->json(['error' => 'Failed to update: ' . $e->getMessage()], 500);
        }
    }

    public function generateId($length = 8): string
    {
        $pool = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        do {
            $string_id = substr(str_shuffle(str_repeat($pool, $length)), 0, $length);
        } while (SpecialKeyword::where('string_id', $string_id)->exists());
        return $string_id;
    }
}