<?php

namespace App\Http\Controllers;

use App\Models\PlanCategory;
use App\Models\planTitals;
use Illuminate\Support\Facades\Validator;
use App\Models\CategoryFeature;
use Illuminate\Http\Request;
use App\Models\SpecialKeyword;
use App\Models\Plan;
use Exception;

class PlanCategoryController extends AppBaseController
{


  public function index(Request $request)
  {
    $query = PlanCategory::query(); // Start query builder

    if ($request->has('query')) {
      $search = $request->input('query');
      $query->where('name', 'LIKE', "%{$search}%")
        ->orWhere('duration_type', 'LIKE', "%{$search}%");
    }

    $getPlanCategorys = $query->paginate(10); 

    return view("plan_duration.index", compact('getPlanCategorys'));
  }



  public function store(Request $request)
  {
    $request->validate([
      'name' => 'required|string|max:255',
      'duration_type' => 'required|numeric', 
  ]);

    // Save data using create()
    $planCategory = PlanCategory::create([
      'name' => $request->name,
      'string_id' => $this->generateId(),
      'duration_type' => $request->duration_type,
    ]);

    return response()->json(['success' => 'Plan Category added successfully!']);
  }

  public function edit($id)
  {
    $planCategory = PlanCategory::findOrFail($id);

    return response()->json([
      'view' => view('plan_duration.edit', compact('planCategory'))->render()
    ]);
  }

  public function update(Request $request, $id)
  {
    $request->validate([
      'feature_name' => 'required|string|max:255',
      'duration_type' => 'required|numeric', 
    ]);

    try {
      $planCategory = PlanCategory::findOrFail($id);

      $planCategory->update([
        'name' => $request->input('feature_name'),
        'duration_type' => $request->input('duration_type'), // Store as JSON
      ]);

      return response()->json(['success' => 'Plan Category updated successfully!']);

    } catch (\Exception $e) {
      return response()->json(['error' => 'Failed to update: ' . $e->getMessage()], 500);
    }
  }

  public function generateId($length = 8)
    {
        $pool = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        do {
            $string_id = substr(str_shuffle(str_repeat($pool, $length)), 0, $length);
        } while (SpecialKeyword::where('string_id', $string_id)->exists());
        return $string_id;
    }

}