<?php

namespace App\Http\Controllers;
use Illuminate\Contracts\Foundation\Application;
use Illuminate\Contracts\View\Factory;
use Illuminate\Contracts\View\View;
use Illuminate\Http\JsonResponse;
use App\Models\NewCategory;
use App\Models\NewSearchTag;
use Exception;
use Illuminate\Support\Facades\Auth;

use Illuminate\Http\Request;

class NewSearchTagController extends AppBaseController
{

    public function index(): Factory|View|Application
    {
        $allNewCategories = NewCategory::getAllCategoriesWithSubcategories();
        // $newSearchTags = NewSearchTag::with('newCategories')->orderBy('id', 'desc')->get();
        $newSearchTags = NewSearchTag::all();
        return view('filters/new_search_tag', compact('allNewCategories', 'newSearchTags'));
    }


    public function store(Request $request): JsonResponse
    {
        try {

            $accessCheck = $this->isAccessByRole("seo_all");
            if ($accessCheck) {
                return response()->json([
                    'error' => $accessCheck,
                ]);
            }

            $inputs = [
                "name" => $request->name,
                "id_name" => $request->id_name,
                "new_category_id" => json_encode(array_filter(explode(",", str_replace(' ', '', $request->new_category_id)))),
                "status" => $request->status,
                "emp_id" => auth()->user()->id,
            ];

            NewSearchTag::create($inputs);

            return response()->json([
                'status' => true,
                'success' => "New Search Tag has been added successfully.",
            ]);
        } catch (Exception $e) {
            return response()->json([
                'status' => false,
                'error' => $e->getMessage(),
            ]);
        }
    }

    public function update(Request $request, NewSearchTag $newSearchTag)
    {
        try {
            $user = auth()->user();

            $accessCheck = $this->isAccessByRole("seo_all", $newSearchTag->id, $newSearchTag->emp_id);
            if ($accessCheck) {
                return response()->json([
                    'error' => $accessCheck,
                ]);
            }

            $rawIds = str_replace('', '', $request->new_category_id); // "1,2,3"
            $categoryIds = $rawIds === "0" || empty($rawIds)
                ? []
                : array_filter(explode(",", $rawIds));

            $newSearchTag->update([
                'new_category_id' => json_encode($categoryIds),
                'name' => $request->name,
                'id_name' => $request->id_name,
                'status' => $request->status,
            ]);

            return response()->json([
                'status' => true,
                'success' => "New Search Tag has been updated successfully.",
            ]);
        } catch (Exception $e) {
            return response()->json([
                'status' => false,
                'error' => $e->getMessage(),
            ]);
        }
    }

    public function edit(NewSearchTag $newSearchTag)
    {
        // Decode category IDs safely as array
        $ids = json_decode($newSearchTag->new_category_id, true);
        $ids = is_array($ids) ? $ids : [];

        // Build category names
        $catNames = [];
        foreach ($ids as $id) {
            $catNames[] = HelperController::getNewCatName($id);
        }

        return response()->json([
            "status" => true,
            "data" => [
                "id" => $newSearchTag->id,
                "name" => $newSearchTag->name,
                "id_name" => $newSearchTag->id_name,
                "status" => $newSearchTag->status,
                "new_category_id" => $ids,
                "catNames" => $catNames,
            ]
        ]);
    }




    public function destroy(NewSearchTag $newSearchTag)
    {
        try {
            $newSearchTag->delete();
            return response()->json([
                'status' => true,
                'success' => "New Search Tag has been deleted successfully.",
            ]);
        } catch (Exception $e) {
            return response()->json([
                'status' => false,
                'error' => $e->getMessage(),
            ]);
        }
    }
}
