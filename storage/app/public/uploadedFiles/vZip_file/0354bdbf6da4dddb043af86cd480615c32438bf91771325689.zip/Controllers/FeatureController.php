<?php

namespace App\Http\Controllers;

use App\Models\CategoryFeature;
use App\Models\Feature;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class FeatureController extends AppBaseController
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $filters = ["name"];
        $query = Feature::query()->with('categoryFeatures');
        if( isset($request->query) && $request->input('query') != '' ){
            $query = $this->applyFilters($query, $filters,$request->input('query'));
        }
        $features = $query->paginate(10);
        $categoryFeatures = CategoryFeature::all();

        return view("plan_feature.index",['features'=>$features,'categoryFeatures'=>$categoryFeatures]);
    }

    /** * Store a newly created resource in storage.*/
    public function store(Request $request)
    {
        $inputs  = $request->except('_token');

        $postData = [];
        $postData["name"] = isset($inputs["name"]) ? $inputs["name"] : "";
        $postData["description"] = isset($inputs["description"]) ? $inputs["description"] : "";
        $postData["category_feature_id"] = isset($inputs["category_feature_id"]) ? $inputs["category_feature_id"] : "";
        $postData["appearance_type"] = isset($inputs["appearance_type"]) ? $inputs["appearance_type"] : "";

        try {
            Feature::create($postData);
            return $this->sendSuccessResponse("Feature has been added successfully.");
        } catch (Exception $e) {
            return $this->sendErrorResponse($e->getMessage());
        }
    }


    /** Show the form for editing the specified resource.*/
    public function edit(Feature $feature)
    {
        $categoryFeatures = CategoryFeature::all();
        return response()->json([
            'view'=> view('plan_feature.edit',compact('feature','categoryFeatures'))->render()
        ]);
    }

    /** Update the specified resource in storage. */

    public function update(Request $request, Feature $feature)
    {
        $inputs = $request->except('_token');
        try {
            $feature->update($inputs);
            return $this->sendSuccessResponse("Feature has been updated successfully.");
       } catch (Exception $e) {
            return $this->sendErrorResponse($e->getMessage());
        }
    }

    /*** Remove the specified resource from storage.*/
    public function destroy(Feature $feature)
    {
        try {
            $feature->delete();
            return $this->sendSuccessResponse("Feature has been deleted successfully.");
        } catch (Exception $e) {
            return $this->sendErrorResponse($e->getMessage());
        }
    }
}
