<?php

namespace App\Http\Controllers;

use App\Models\CategoryFeature;
use App\Models\PlanCategoryFeature;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class PlanCategoryFeatureController extends AppBaseController
{
    /** Display a listing of the resource.*/
    public function index(Request $request)
    {
        $filters = ["name"];
        $query = PlanCategoryFeature::query();
        if( isset($request->query) && $request->input('query') != '' ){
            $query = $this->applyFilters($query, $filters,$request->input('query'));
        }
        $categoryFeatues = $query->paginate(10);
        return view("category_feature.index")->with('categoryFeatues',$categoryFeatues);
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string',
        ]);
        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator)->withInput();
        }
        try {
            PlanCategoryFeature::create($request->only('name'));
            return $this->sendSuccessResponse("Category Feature has been added successfully.");
        } catch (Exception $e) {
            return $this->sendErrorResponse($e->getMessage());
        }
    }

    public function update(Request $request, PlanCategoryFeature $categoryFeatures)
    {
        try {
            $categoryFeatures->update(['name' => $request->category_feature_name]);
            return $this->sendSuccessResponse("Category Feature has been updated successfully.");
       } catch (Exception $e) {
            return $this->sendErrorResponse($e->getMessage());
        }
    }

}
