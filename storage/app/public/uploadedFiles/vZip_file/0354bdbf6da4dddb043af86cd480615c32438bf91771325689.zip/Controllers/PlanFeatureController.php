<?php

namespace App\Http\Controllers;

use App\Models\PlanCategoryFeature;
use App\Models\PlanFeature;
use Exception;
use Illuminate\Http\Request;

class PlanFeatureController extends AppBaseController
{
    public function index(Request $request)
    {
        $filters = ["name"];
        $query = PlanFeature::query()->with('categoryFeatures');
        if (isset($request->query) && $request->input('query') != '') {
            $query = $this->applyFilters($query, $filters, $request->input('query'));
        }
        $features = $query->paginate(10);
        $categoryFeatures = PlanCategoryFeature::all();

        return view("plan_feature.index", ['features' => $features, 'categoryFeatures' => $categoryFeatures]);
    }

    public function store(Request $request)
    {
        $inputs = $request->except('_token');

        $postData = [];
        $postData["name"] = isset($inputs["name"]) ? $inputs["name"] : "";
        $postData["slug"] = isset($inputs["slug"]) ? $inputs["slug"] : "";
        $postData["description"] = isset($inputs["description"]) ? $inputs["description"] : "";
        $postData["category_feature_id"] = isset($inputs["category_feature_id"]) ? $inputs["category_feature_id"] : "";

        try {
            PlanFeature::create($postData);
            return $this->sendSuccessResponse("Feature has been added successfully.");
        } catch (Exception $e) {
            return $this->sendErrorResponse($e->getMessage());
        }
    }

    public function edit(PlanFeature $feature)
    {
        $categoryFeatures = PlanCategoryFeature::all();
        return response()->json([
            'view' => view('plan_feature.edit', compact('feature', 'categoryFeatures'))->render()
        ]);
    }

    public function update(Request $request, PlanFeature $feature)
    {
        $inputs = $request->except('_token', 'slug');

        try {
            $feature->update($inputs);
            return $this->sendSuccessResponse("Feature has been updated successfully.");
        } catch (Exception $e) {
            return $this->sendErrorResponse($e->getMessage());
        }
    }

    public function destroy(PlanFeature $feature)
    {
        try {
            $feature->delete();
            return $this->sendSuccessResponse("Feature has been deleted successfully.");
        } catch (Exception $e) {
            return $this->sendErrorResponse($e->getMessage());
        }
    }
}
