<?php
namespace App\Http\Controllers;
use App\Models\UserData;
use Illuminate\Contracts\Foundation\Application;
use Illuminate\Contracts\View\Factory;
use Illuminate\Contracts\View\View;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class EmailTemplate extends AppBaseController
{
    public function index(Request $request): Factory|View|Application
    {
        return view('email_template.index');
    }
    public function store(Request $request): JsonResponse
    {
        set_time_limit(600);
        $request->validate([
            'email_template' => 'required',
            'subject' => 'required',
            'template_type' => 'required',
            'select_users_type' => 'required'
        ]);
        $select_users_type = $request->input('select_users_type');
        $subject = $request->input('subject');
        $email_template = $request->input('email_template');
        $callback = function ($users) use ($subject, $email_template) {
            $emails = $users->pluck('email')
                ->filter(fn($email) => !empty($email) && filter_var($email, FILTER_VALIDATE_EMAIL))
                ->unique()
                ->values()
                ->toArray();
            if (!empty($emails)) {
                Mail::send([], [], function ($message) use ($emails, $subject, $email_template) {
                    $message->from(env("MAIL_FROM_ADDRESS"),env("MAIL_FROM_NAME"))
                        ->to($emails)
                        ->subject($subject)
                        ->setBody($email_template, 'text/html');
                });
            }
        };
        if ($select_users_type == '1') {
            UserData::select('email')->chunk(10000, $callback);
        } elseif ($select_users_type == '2') {
            UserData::where('is_Premium', 1)->select('email')->chunk(10000, $callback);
        } elseif ($select_users_type == '3') {
            $user_ids = $request->input('user_id', []);
            UserData::whereIn('uid', $user_ids)->select('email')->chunk(10000, $callback);
        } else {
            return response()->json(['message' => 'Invalid user type selected.'], 400);
        }
        return response()->json(['status' => true, 'msg' => 'Email sent successfully!']);
    }

    public function getEmailTmp(Request $request): JsonResponse
    {
        $query = $request->input('q');
        $users = UserData::where(function ($q) use ($query) {
            $q->where('email', 'like', "%{$query}%")
                ->orWhere('id', 'like', "%{$query}%");
        })
            ->limit(100)
            ->get(['id', 'uid', 'email']);
        return response()->json(
            $users->map(fn($user) => ['id' => $user->uid, 'text' => "{$user->id} - {$user->email}"])
        );
    }
}