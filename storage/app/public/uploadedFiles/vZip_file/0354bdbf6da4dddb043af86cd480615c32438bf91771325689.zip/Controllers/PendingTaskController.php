<?php
namespace App\Http\Controllers;
use App\Http\Controllers\Controller;
use App\Http\Controllers\HelperController;
use App\Models\PendingTask;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class PendingTaskController extends AppBaseController
{

  public static function store($data, $tableName, $title, $desc, $route, $content, $action = 'add', $recordId = null)
  {
    if (HelperController::isSeo(auth()->user()->user_type)) {
      PendingTask::create([
        'string_id' => HelperController::generateId(),
        'table_name' => $tableName,
        'record_id' => $action === 'update' || $action === 'delete' ? $recordId : null,
        'action' => $action,
        'changes_title' => $title,
        'changes_desc' => $desc,
        'preview_route' => $route,
        'content' => $content,
        'data' => json_encode($data),
        'group_leader_id' => auth()->user()->group_leader_id,
        'emp_id' => auth()->user()->id,
      ]);
      return response()->json(['success' => 'Change submitted for approval.']);
    }
    return self::applyChange($tableName, $action, $data, $recordId);
  }

  public static function applyChange($tableName, $action, $data, $recordId = null)
  {
    $modelClass = '\\App\\Models\\' . ucfirst(Str::singular($tableName));
    if (!class_exists($modelClass)) {
      return response()->json(['error' => 'Model for table ' . $tableName . ' not found.']);
    }
    switch ($action) {
      case 'add':
        $modelClass::create($data);
        break;

      case 'update':
        if ($recordId) {
          $modelClass::where('id', $recordId)->update($data);
        }
        break;

      case 'delete':
        if ($recordId) {
          $modelClass::where('id', $recordId)->delete();
        }
        break;

      default:
        return response()->json(['error' => 'Invalid action']);
    }

    return response()->json(['success' => ucfirst($action) . ' applied successfully.']);
  }

  public function show(Request $request)
  {
    if (HelperController::isGroupLeader(auth()->user()->user_type)) {
      $datas = PendingTask::where('group_leader_id', auth()->user()->id)->get();
    } else {
      $datas = PendingTask::all();
    }
    return view('pending_item/show_pending_item')->with('datas', $datas);
  }
}