<?php

namespace App\Jobs;

use App\Enums\MailSendType;
use App\Http\Controllers\EmailTemplateController;
use App\Http\Controllers\HelperController;
use App\Http\Controllers\Utils\AutomationUtils;
use App\Models\Config;
use App\Models\Design;
use App\Models\EmailTemplate;
use App\Models\MailSendDetail;
use App\Models\MailSendLog;
use App\Models\OrderUser;
use App\Models\SubPlan;
use App\Models\Subscription;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Carbon\Carbon;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\View;

class ProcessCheckoutDropJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public function handle(): void
    {
        Log::info("Job Started");

        $config = Config::where('name', MailSendType::from(3)->label())->first();
        if (!$config) {
            Log::warning("CheckoutDropJob: Config not found!");
            return;
        }

        $configData = $config->value;
        if (!isset($configData['frequencies'])) {
            Log::warning("CheckoutDropJob: No frequencies found!");
            return;
        }

        $now = Carbon::now();

        foreach ($configData['frequencies'] as $frequency) {
            Log::info("Processing frequency: " . json_encode($frequency));

            $days = (int)$frequency['days'];
            $targetDate = $now->copy()->subDays($days)->toDateString();
            Log::info("Target date for frequency {$days} days ago: {$targetDate}");

            $allUsers = OrderUser::with(['user.transactionLogs' => function ($q) {
                $q->latest('id')->limit(1);
            }])
                ->whereDate('created_at', $targetDate)
                ->where('status', 'failed')
                ->whereHas('user')
                ->where(function ($q) {
                    $q->whereDoesntHave('user.transactionLogs')
                        ->orWhereHas('user.transactionLogs', function ($q2) {
                            $q2->where('expired_at', '<', now());
                        });
                })
                ->get();

            if ($allUsers->isEmpty()) {
                Log::info("No users found for frequency '{$frequency['subject']}' on {$targetDate}");
                continue;
            }

            Log::info("Total users found: " . $allUsers->count());

            $userIds = $allUsers->pluck('user.id')->toArray();

            $mailSendLog = MailSendLog::create([
                'subject' => $frequency['subject'] ?? "Checkout Drop {$targetDate}",
                'email_template_id' => $frequency['template'] ?? null,
                'user_ids' => json_encode($userIds),
                'select_users_type' => 3,
                'total' => count($userIds),
                'sent' => 0,
                'failed' => 0,
                'status' => 'processing',
                'send_type' => 3
            ]);
            Log::info("MailSendLog created with ID {$mailSendLog->id}");

            $emailTemplate = null;
            if (!empty($frequency['template'])) {
                $emailTemplate = EmailTemplate::find($frequency['template']);
            }
            if (!$emailTemplate) {
                Log::error("EmailTemplate not found for frequency '{$frequency['subject']}'");
                MailSendLog::where('id', $mailSendLog->id)->update(['status' => 'failed']);
                continue;
            }

            Log::info("Using EmailTemplate ID: {$emailTemplate->id}");

            $newSubIds = $allUsers->where('type', 'new_sub')->pluck('plan_id')->toArray();
            $oldSubIds = $allUsers->where('type', 'old_sub')->pluck('plan_id')->toArray();
            Log::info("New Sub IDs: " . json_encode($newSubIds));
            Log::info("Old Sub IDs: " . json_encode($oldSubIds));

            $subPlans = SubPlan::whereIn('id', $newSubIds)
                ->orWhereIn('string_id', $newSubIds)
                ->get()
                ->keyBy(fn($plan) => $plan->string_id ?? $plan->id);

            $subscriptions = Subscription::whereIn('id', $oldSubIds)
                ->get()
                ->keyBy('id');

            $allUsers->chunk(100)->each(function ($chunk) use ($frequency, $mailSendLog, $subPlans, $subscriptions, $emailTemplate) {
                Log::info("Processing chunk of users: " . $chunk->count());

                $logFailedMail = function ($userId, $email, $error, $mailSendLog) {
                    Log::error("Failed mail for UserID {$userId}, Email {$email}, Error: {$error}");
                    MailSendDetail::create([
                        'log_id' => $mailSendLog->id,
                        'user_id' => $userId,
                        'send_type' => MailSendType::EMAIL_CHECKOUT_DROP_AUTOMATION,
                        'email' => $email,
                        'status' => 'failed',
                        'error_message' => $error,
                    ]);
                    MailSendLog::where('id', $mailSendLog->id)->increment('failed');
                };

                foreach ($chunk as $offerUser) {
                    $user = $offerUser->user;
                    if (!$user) {
                        Log::warning("Skipping OrderUser ID {$offerUser->id} due to missing user relation");
                        $logFailedMail(null, null, "Missing user for OrderUser {$offerUser->id}", $mailSendLog);
                        continue;
                    }

                    Log::info("Preparing email for User ID {$user->id}, Email {$user->email}, PlanType {$offerUser->type}");

                    $currency = $offerUser->currency;
                    $planType = $offerUser->type;
                    $planId = $offerUser->plan_id;

                    $response['userData'] = [
                        'name' => $user->name,
                        'email' => $user->email,
                    ];

                    if ($planType === 'new_sub') {
                        $plan = $subPlans[$planId] ?? null;
                        if (!$plan) {
                            $logFailedMail($user->id, $user->email, "Plan not found for new_sub", $mailSendLog);
                            continue;
                        }
                        Log::info("User {$user->id} -> new_sub plan found");

                        $response['type'] = "plan";
                        $response['data'] = AutomationUtils::formatNewPlanData($plan, $currency);
                        $response['link'] = "https://www.craftyartapp.com/offer-package";

                    } elseif ($planType === 'old_sub') {
                        $plan = $subscriptions[$planId] ?? null;
                        if (!$plan) {
                            $logFailedMail($user->id, $user->email, "Subscription not found for old_sub", $mailSendLog);
                            continue;
                        }
                        Log::info("User {$user->id} -> old_sub subscription found");

                        $response['type'] = "plan";
                        $response['data'] = AutomationUtils::formatOldPlanData($plan, $currency);
                        $response['link'] = "https://www.craftyartapp.com/offer-package";

                    } elseif (in_array($planType, ['template', 'video'])) {
                        Log::info("User {$user->id} -> processing {$planType}");

                        $templateData = json_decode($planId, true);
                        $ids = collect($templateData)->pluck('id')->toArray();

                        $designs = Design::whereIn('string_id', $ids)->get()->keyBy('string_id');
                        $newArray = [];

                        foreach ($templateData as $item) {
                            if (isset($designs[$item['id']])) {
                                $design = $designs[$item['id']];
                                $newArray[] = [
                                    "title" => $design->post_name,
                                    "image" => HelperController::generatePublicUrl($design->post_thumb),
                                    "width" => $design->width,
                                    "height" => $design->height,
                                    "amount" => $currency == "INR" ? $item['inrAmount'] : $item['usdAmount'],
                                    "link" => HelperController::getFrontendPageUrl(0, $design->id_name),
                                ];
                            }
                        }

                        if (empty($newArray)) {
                            $logFailedMail($user->id, $user->email, "No designs found for template/video", $mailSendLog);
                            continue;
                        }

                        Log::info("User {$user->id} -> found " . count($newArray) . " designs");

                        $response['type'] = "template";
                        $response['data'] = [
                            "templates" => $newArray,
                            "amount" => ($currency == "INR" ? "₹" : "$") . $offerUser->amount,
                        ];
                        $response['link'] = "https://www.craftyartapp.com/offer-package";
                    }

                    // build email
                    $htmlBody = View::make($emailTemplate->email_template, [
                        'data' => $response,
                    ])->render();
                    Log::info("Email body rendered for User {$user->id}");

                    $result = EmailTemplateController::sendEmail(
                        $user->email,
                        $frequency['subject'] ?? '',
                        $htmlBody
                    );

                    if (!str_contains($result, "successfully")) {
                        $logFailedMail($user->id, $user->email, $result, $mailSendLog);
                    } else {
                        Log::info("Email sent successfully to {$user->email}");
                        MailSendLog::where('id', $mailSendLog->id)->increment('sent');
                    }

                    sleep(5);
                }
            });

            MailSendLog::where('id', $mailSendLog->id)->update(['status' => 'completed']);
            Log::info("MailSendLog ID {$mailSendLog->id} marked as completed");
        }

        Log::info("Job Finished");
    }

//    public function handle(): void
//    {
//        Log::info("Job Started");
//
//        $config = Config::where('name', MailSendType::from(3)->label())->first();
//        if (!$config) {
//            Log::info("CheckoutDropJob: Config not found!");
//            return;
//        }
//
//        $configData = $config->value;
//        if (!isset($configData['frequencies'])) {
//            Log::info("CheckoutDropJob: No frequencies found!");
//            return;
//        }
//
//        $now = Carbon::now();
//
//        foreach ($configData['frequencies'] as $frequency) {
//            $days = (int) $frequency['days'];
//            $targetDate = $now->copy()->subDays($days)->toDateString();
//
//            $allUsers = OrderUser::with(['user.transactionLogs' => function ($q) {
//                $q->latest('id')->limit(1);
//            }])
//                ->whereDate('created_at', $targetDate)
//                ->where('status', 'failed')
//                ->whereHas('user')
//                ->where(function ($q) {
//                    $q->whereDoesntHave('user.transactionLogs')
//                        ->orWhereHas('user.transactionLogs', function ($q2) {
//                            $q2->where('expired_at', '<', now());
//                        });
//                })
//                ->get();
//
//            if ($allUsers->isEmpty()) {
//                Log::info("No users for frequency {$frequency['subject']} on {$targetDate}");
//                continue;
//            }
//
//            $userIds = $allUsers->pluck('user.id')->toArray();
//
//            $mailSendLog = MailSendLog::create([
//                'subject'          => $frequency['subject'] ?? "Checkout Drop {$targetDate}",
//                'email_template_id'=> $frequency['template'] ?? null,
//                'user_ids'         => json_encode($userIds),
//                'select_users_type'=> 3,
//                'total'            => count($userIds),
//                'sent'             => 0,
//                'failed'           => 0,
//                'status'           => 'processing',
//                'send_type'        => 3
//            ]);
//
//            $emailTemplate = null;
//            if (!empty($frequency['template'])) {
//                $emailTemplate = EmailTemplate::find($frequency['template']);
//            }
//            if (!$emailTemplate) {
//                Log::warning("EmailTemplate not found for frequency {$frequency['subject']}");
//                MailSendLog::where('id', $mailSendLog->id)->update(['status' => 'failed']);
//                continue;
//            }
//
//            $newSubIds = $allUsers->where('type', 'new_sub')->pluck('plan_id')->toArray();
//            $oldSubIds = $allUsers->where('type', 'old_sub')->pluck('plan_id')->toArray();
//
//            $subPlans = SubPlan::whereIn('id', $newSubIds)
//                ->orWhereIn('string_id', $newSubIds)
//                ->get()
//                ->keyBy(fn($plan) => $plan->string_id ?? $plan->id);
//
//            $subscriptions = Subscription::whereIn('id', $oldSubIds)
//                ->get()
//                ->keyBy('id');
//
//            $allUsers->chunk(100)->each(function ($chunk) use ($frequency, $mailSendLog, $subPlans, $subscriptions, $emailTemplate) {
//
//                $logFailedMail = function ($userId, $email, $error, $mailSendLog) {
//                    MailSendDetail::create([
//                        'log_id'        => $mailSendLog->id,
//                        'user_id'       => $userId,
//                        'send_type'     => MailSendType::EMAIL_CHECKOUT_DROP_AUTOMATION,
//                        'email'         => $email,
//                        'status'        => 'failed',
//                        'error_message' => $error,
//                    ]);
//                    MailSendLog::where('id', $mailSendLog->id)->increment('failed');
//                };
//
//                foreach ($chunk as $offerUser) {
//                    $user = $offerUser->user;
//                    if (!$user) {
//                        Log::warning("Skipping user {$offerUser->id} due to missing user");
//                        $logFailedMail(null, null, "Missing user for OrderUser {$offerUser->id}", $mailSendLog);
//                        continue;
//                    }
//
//                    $currency = $offerUser->currency;
//                    $planType = $offerUser->type;
//                    $planId   = $offerUser->plan_id;
//
//                    $response['userData'] = [
//                        'name'  => $user->name,
//                        'email' => $user->email,
//                    ];
//
//                    if ($planType === 'new_sub') {
//                        $plan = $subPlans[$planId] ?? null;
//                        if (!$plan) {
//                            $logFailedMail($user->id, $user->email, "Plan not found for new_sub", $mailSendLog);
//                            continue;
//                        }
//
//                        $response['type'] = "plan";
//                        $response['data'] = AutomationUtils::formatNewPlanData($plan, $currency);
//                        $response['link'] = "https://www.craftyartapp.com/offer-package";
//
//                    } elseif ($planType === 'old_sub') {
//                        $plan = $subscriptions[$planId] ?? null;
//                        if (!$plan) {
//                            $logFailedMail($user->id, $user->email, "Subscription not found for old_sub", $mailSendLog);
//                            continue;
//                        }
//
//                        $response['type'] = "plan";
//                        $response['data'] = AutomationUtils::formatOldPlanData($plan, $currency);
//                        $response['link'] = "https://www.craftyartapp.com/offer-package";
//
//                    } elseif (in_array($planType, ['template', 'video'])) {
//                        $templateData = json_decode($planId, true);
//                        $ids = collect($templateData)->pluck('id')->toArray();
//
//                        $designs = Design::whereIn('string_id', $ids)->get()->keyBy('string_id');
//                        $newArray = [];
//
//                        foreach ($templateData as $item) {
//                            if (isset($designs[$item['id']])) {
//                                $design = $designs[$item['id']];
//                                $newArray[] = [
//                                    "title"  => $design->post_name,
//                                    "image"  => HelperController::generatePublicUrl($design->post_thumb),
//                                    "width"  => $design->width,
//                                    "height" => $design->height,
//                                    "amount" => $currency == "INR" ? $item['inrAmount'] : $item['usdAmount'],
//                                    "link"   => HelperController::getFrontendPageUrl(0, $design->id_name),
//                                ];
//                            }
//                        }
//
//                        if (empty($newArray)) {
//                            $logFailedMail($user->id, $user->email, "No designs found for template/video", $mailSendLog);
//                            continue;
//                        }
//
//                        $response['type'] = "template";
//                        $response['data'] = [
//                            "templates" => $newArray,
//                            "amount"    => ($currency == "INR" ? "₹" : "$").$offerUser->amount,
//                        ];
//                        $response['link'] = "https://www.craftyartapp.com/offer-package";
//                    }
//
//                    // build email
//                    $htmlBody = View::make($emailTemplate->email_template, [
//                        'data' => $response,
//                    ])->render();
//
//                    $result = EmailTemplateController::sendEmail(
//                        $user->email,
//                        $frequency['subject'] ?? '',
//                        $htmlBody
//                    );
//
//                    if (!str_contains($result, "successfully")) {
//                        $logFailedMail($user->id, $user->email, $result, $mailSendLog);
//                    } else {
//                        MailSendLog::where('id', $mailSendLog->id)->increment('sent');
//                    }
//
//                    sleep(5);
//                }
//            });
//
//            MailSendLog::where('id', $mailSendLog->id)->update(['status' => 'completed']);
//        }
//    }

}