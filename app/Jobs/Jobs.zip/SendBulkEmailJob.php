<?php

namespace App\Jobs;

use App\Enums\MailSendType;
use App\Http\Controllers\EmailTemplateController;
use App\Models\EmailTemplate;
use App\Models\MailSendDetail;
use App\Models\MailSendLog;
use App\Models\UserData;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\View;

class SendBulkEmailJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    protected int $logId;

    public function __construct(int $logId)
    {
        $this->logId = $logId;
    }

    public function handle(): void
    {
        $log = MailSendLog::find($this->logId);
        if (!$log || $log->stopped) {
            Log::info("BulkEmailJob: Log not found or stopped.");
            return;
        }

        if (in_array($log->status, ['paused', 'completed', 'failed'])) {
            Log::info("BulkEmailJob: Job {$log->id} is {$log->status}, skipping...");
            return;
        }

        $log->update(['status' => 'processing']);

        $baseQuery = UserData::select('id', 'email', 'uid', 'name', 'email_preferance')->whereNotNull('email');

        if ($log->select_users_type == '2') {
            $baseQuery->where('is_Premium', 1);
        } elseif ($log->select_users_type == '3' && !empty($log->user_ids)) {
            $baseQuery->whereIn('uid', $log->user_ids);
        }


        if (!empty($log->last_processed_user_id)) {
            $baseQuery->where('id', '>', $log->last_processed_user_id);
        }

        try {
            $baseQuery->chunk(500, function ($users) use ($log) {
                foreach ($users as $user) {
                    $log->refresh();

                    // Manual pause
                    if ($log->status === 'paused') {
                        Log::info("BulkEmailJob: Manually paused at user {$user->id}");
                        return false;
                    }

                    if ($log->stopped) {
                        Log::info("BulkEmailJob: Stopped at user {$user->id}");
                        return false;
                    }

                    $email = $user->email;
                    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
                        $log->increment('failed');
                        MailSendDetail::create([
                            'log_id' => $log->id,
                            'user_id' => $user->id,
                            'send_type' => MailSendType::CAMPAIGN,
                            'email' => $email ?? 'invalid',
                            'status' => 'failed',
                            'error_message' => 'Invalid or missing email address',
                        ]);
                        continue;
                    }

                    $subRaw = $user->email_preferance;
                    if (!empty($subRaw)) {
                        $sub = json_decode($subRaw, true);
                        if (is_array($sub) && isset($sub['offer']) && (int)$sub['offer'] === 0) {
                            $log->increment('failed');
                            MailSendDetail::create([
                                'log_id' => $log->id,
                                'user_id' => $user->id,
                                'send_type' => MailSendType::CAMPAIGN,
                                'email' => $email,
                                'status' => 'failed',
                                'error_message' => 'Unsubscribe user',
                            ]);
                            continue;
                        }
                    }
                    try {
                        $emailTemplate = EmailTemplate::find($log->email_template_id);
                        $response['userData'] = [
                            'name' => $user->name,
                            'email' => $user->email,
                        ];
                        $htmlBody = View::make($emailTemplate->email_template, [
                            'data' => $response,
                        ])->render();

                        $result = EmailTemplateController::sendEmail($email, $log->subject, $htmlBody, 'text');

                        if (str_contains($result, "successfully")) {
                            $log->increment('sent');
                        } else {
                            $log->increment('failed');
                            MailSendDetail::create([
                                'log_id' => $log->id,
                                'user_id' => $user->id,
                                'send_type' => MailSendType::CAMPAIGN,
                                'email' => $email,
                                'status' => 'failed',
                                'error_message' => $result,
                            ]);
                        }
                    } catch (\Exception $e) {
                        $log->increment('failed');
                        Log::error("Exception sending email to {$email}: " . $e->getMessage());
                        MailSendDetail::create([
                            'log_id' => $log->id,
                            'user_id' => $user->id,
                            'send_type' => MailSendType::CAMPAIGN,
                            'email' => $email,
                            'status' => 'failed',
                            'error_message' => $e->getMessage(),
                        ]);
                    }

                    $log->last_processed_user_id = $user->id;
                    $log->save();

                    // Auto-pause based on total attempts (sent + failed)
                    $totalSinceLastPause = ($log->sent + $log->failed) - ($log->emails_sent_since_last_pause ?? 0);

                    if ($totalSinceLastPause >= $log->auto_pause_count) {
                        $log->update([
                            'status' => 'paused',
                            'pause_type' => 'auto',
                            'emails_sent_since_last_pause' => $log->sent + $log->failed
                        ]);
                        Log::info("BulkEmailJob: Auto-paused after {$totalSinceLastPause} total attempts.");
                        return false;
                    }
                }
            });

            $log->refresh();
            if ($log->status !== 'paused' && !$log->stopped) {
                $log->update(['status' => 'completed']);
            }
        } catch (\Exception $e) {
            Log::error("Error in bulk job for log #{$log->id}: " . $e->getMessage());
            $log->update(['status' => 'failed']);
        }
    }

}
